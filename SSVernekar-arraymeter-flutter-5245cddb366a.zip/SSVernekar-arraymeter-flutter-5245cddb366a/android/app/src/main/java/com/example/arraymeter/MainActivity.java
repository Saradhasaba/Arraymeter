package com.example.arraymeter;

//import android.app.ActivityManager;
//import android.app.NotificationChannel;
//import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
//    Intent mServiceIntent;
//    private YourService mYourService;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {




//        mYourService = new YourService();
//        mServiceIntent = new Intent(this, mYourService.getClass());
//        if (!isMyServiceRunning(mYourService.getClass())) {
//            startService(mServiceIntent);
//        }
        super.onCreate(savedInstanceState);
    }


//    private boolean isMyServiceRunning(Class<?> serviceClass) {
//
//
//
//        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
//        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
//            if (serviceClass.getName().equals(service.service.getClassName())) {
//                Log.i ("Service status", "Running");
//                return true;
//            }
//        }
//        Log.i ("Service status", "Not running");
//        return false;
//    }

//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        Intent broadcastIntent = new Intent();
//        broadcastIntent.setAction("restartservice");
//        broadcastIntent.setClass(this, Restarter.class);
//        this.sendBroadcast(broadcastIntent);
//    }
}
