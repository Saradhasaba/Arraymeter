import 'package:arraymeter/services/constants.dart';
import 'package:intl/intl.dart';

class NotificationData {
  String id, title, message, image;

  NotificationData({this.id, this.title, this.message, this.image});

  factory NotificationData.fromJson(Map<String, dynamic> json) {
    String _title, _message, _imagePath;
    DateTime _dateTime = DateTime.now();
    // if (json["lastCommunicated"] != null) {
    DateTime _lastCDate = DateTime.fromMillisecondsSinceEpoch(
        int.parse(json['lastCommunicated']) * 1000);

    switch (json["Status"]) {
      case "Online":
        _title =
            "Plant status: Online";
        _imagePath = Images.fleetOverViewImages.online;

        _message = json["PlantName"] +
            "(${json["Capacity"]} kW)-- Your solar production on ${DateFormat("MM-dd-yyyy").format(DateTime(_dateTime.year, _dateTime.month, _dateTime.day - 1))} is ${json["lastDayEnergy"] ?? "0"} kWh.\nLast communicated  ${DateFormat("MM-dd-yyyy").format(_lastCDate)},${_lastCDate.hour.toString().padLeft(2,"0")}:${_lastCDate.minute.toString().padLeft(2,"0")}";
        break;
      case "No Production":
        _title = "No Production";
        _message = json["PlantName"] +
            "(${json["Capacity"]} kW)-- Your solar plant has no production since  ${DateFormat("MM-dd-yyyy").format(_lastCDate)}";
        _imagePath = Images.fleetOverViewImages.noProduction;

        break;
      case "No Communication":
        _title = "Connection Error";
        _message = json["PlantName"] +
            "(${json["Capacity"]} kW)-- Your solar plant has No Communication since  ${DateFormat("MM-dd-yyyy").format(_lastCDate)},${_lastCDate.hour.toString().padLeft(2,"0")}:${_lastCDate.minute.toString().padLeft(2,"0")}";
        _imagePath = Images.fleetOverViewImages.noCommunication;

        break;
    }
    // }

    return NotificationData(
        id: json["meterId"],
        title: _title,
        message: _message,
        image: _imagePath);
  }
}
