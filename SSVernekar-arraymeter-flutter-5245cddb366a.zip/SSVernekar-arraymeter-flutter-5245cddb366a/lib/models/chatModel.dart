import 'dart:convert';

ChatMessageModel chatMessageModelFromJson(String str) =>
    ChatMessageModel.fromJson(json.decode(str));

String chatMessageModelToJson(ChatMessageModel data) =>
    json.encode(data.toJson());

class ChatMessageModel {
  String chatId;
  String ticketId;
  String from;
  String message, status;
  List<dynamic> docPath = List<dynamic>();
  List<dynamic> docName = List<dynamic>();
  List<dynamic> imagePath = List<dynamic>();
  DateTime timeStamp;

  bool deletable;
  String fName;

  ChatMessageModel(
      {this.chatId,
      this.ticketId,
      this.status,
      this.imagePath,
      this.docPath,
      this.docName,
      this.deletable = false,
      this.from,
      this.fName,
      this.message,
      this.timeStamp});

  factory ChatMessageModel.fromJson(Map<String, dynamic> json) {
    print(json.toString());
    return ChatMessageModel(
      chatId: json["id"],
      ticketId: json["TicketId"],
      from: json["fromId"],
      fName: json["userName"],
      message: json["body"],
      status: json["statusName"],
      imagePath: json["imagePath"],
      docPath: json["docPath"],
      docName: json["doc"],
      deletable: false,
      timeStamp: json["timestamp"] != null
          ? DateTime.tryParse(json["timestamp"])
          : DateTime.tryParse(
              "2012-12-12 12:12:12.120"), //dummy Date or Else Ui error occures
    );
  }
  Map<String, dynamic> toJson() => {
        "chat_id": chatId,
        "ticketId": ticketId,
        "from": from,
        "message": message,
      };
}
