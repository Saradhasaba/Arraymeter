import 'package:arraymeter/services/service.dart';

class User {
  String id, name, email, password, phoneNumber;
  List plantIds;
  Role role;
  bool management, ticketManagement;

  User({this.id,
    this.name,
    this.role,
    this.email,
    this.password,
    this.phoneNumber, this.ticketManagement, this.management,
    this.plantIds});

  factory User.fromJson(Map<String, dynamic> json) =>
      User(
        id: json['sl_no'],
        name: json['name'],
        role: Services.textTORole(json['role']),
        plantIds: json['plants'],
        phoneNumber: json['phone'],
        password: json['password'],
        email: json['email'],
        management:json['management']=="true"?true:false,

        ticketManagement:json['ticket']=="true"?true:false,

      );
}
