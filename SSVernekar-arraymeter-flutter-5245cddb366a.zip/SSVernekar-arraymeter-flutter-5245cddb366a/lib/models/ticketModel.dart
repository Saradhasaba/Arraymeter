class Ticket {
  Ticket(
      {this.id,
      this.title,
      this.description,
      this.actualProblem,
      this.status,
      this.statusId,
      this.category,
      this.address,
      this.capacity,
      this.catId,
      this.meterId,
      this.imagesList,
      this.openedDate,
      this.ownerName,
      this.ticketNo,
      this.outageEnd,
      this.outageStart,
      this.plantName,
      this.lastUpdate,
      this.email,
      this.contactNumber,
      this.deleteReason,
      this.city,
      this.caroselImage,
      this.plantId});
  String city;
  String id;
  String ticketNo;
  String title;
  String description, actualProblem;
  String status;
  String statusId;
  String category, catId;
  String address;
  String email;
  String contactNumber;
  double capacity;
  String deleteReason;
  String meterId;
  String plantId;
  String ownerName, plantName;
  DateTime openedDate, outageStart, outageEnd, lastUpdate;
  List imagesList;
  List<dynamic> caroselImage;

  factory Ticket.fromJson(Map<String, dynamic> json) {
    var ticket = Ticket(
      id: json["id"],
      title: json["problem"],
      description: json["Description"],
      statusId: json["statusId"],
      status: json["statusName"],
      category: json["catName"],
      address: json["address"],
      capacity: double.tryParse(json["capacity"]),
      meterId: json["meterId"],
      imagesList: json["images"],
      caroselImage: json["messageImages"],
      actualProblem: json["actualProblem"],
      openedDate: DateTime.parse(json["open_date"]),
      ownerName: json["name"],
      plantName: json["plantName"],
      catId: json["catId"],
      ticketNo: json["ticketNo"],
      city: json["city"],
      email: json["email"],
      contactNumber: json["contact_number"],
      plantId: json["plantId"],
      deleteReason: json["deleteReason"],
      lastUpdate: json["last_updated"] != null
          ? DateTime.tryParse(json["last_updated"])
          : null,
      outageStart: json["outageStart"] != null
          ? DateTime.tryParse(json["outageStart"])
          : null,
      outageEnd: json["outageEnd"] != null
          ? DateTime.tryParse(json["outageEnd"])
          : null,
    );
    return ticket;
  }
}
