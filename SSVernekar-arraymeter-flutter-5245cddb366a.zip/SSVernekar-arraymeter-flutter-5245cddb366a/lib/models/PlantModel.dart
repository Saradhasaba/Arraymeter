import 'package:arraymeter/services/service.dart';

class PlantModel {
  String name, id, city, state, zipCode, feed, address;
  double capacity;
  DateTime lastCommunication;
  PlantStatus plantStatus;
  double todayEnergy;
  double monthlyEnergy;
  double yearEnergy, lifeTimeEnergy;

  PlantModel(
      {this.plantStatus,
      this.id,
      this.lastCommunication,
      this.monthlyEnergy,
      this.name,
      this.todayEnergy,
      this.yearEnergy,
      this.capacity,
      this.lifeTimeEnergy,
      this.city,
      this.address,
      this.zipCode,
      this.state,
      this.feed});

  factory PlantModel.fromJson(Map<String, dynamic> json) {
    DateTime lastCommunication = json['lastCommunicationDate'] != null
        ? DateTime.fromMillisecondsSinceEpoch(
            int.parse(json['lastCommunicationDate']) * 1000)
        : null;

    DateTime _dateTime = DateTime.now();

    double todayProduction = 0;

    bool _statusUpdated = false;

    PlantStatus _plantStatus;

    if (lastCommunication != null) {
//setting todayproduction

      if (lastCommunication.hour == 23) {
        if (lastCommunication.minute >= 45) {
          todayProduction = 0;
          _plantStatus = PlantStatus.online;
          _statusUpdated = true;
        } else {
          todayProduction = double.parse(json['todaysProduction']);
        }
      } else if (lastCommunication.hour == 0) {
        if (lastCommunication.minute <= 15) {
          todayProduction = 0;
          _plantStatus = PlantStatus.online;
          _statusUpdated = true;
        }
      } else {
        todayProduction = double.parse(json['todaysProduction']);
      }

//plants status

      if (!_statusUpdated) {
        if (lastCommunication.isAfter(DateTime(_dateTime.year, _dateTime.month,
                _dateTime.day, _dateTime.hour - 12)) &&
            todayProduction >= 1) {
          _plantStatus = PlantStatus.online;
        } else if (lastCommunication.isAfter(DateTime(_dateTime.year,
                _dateTime.month, _dateTime.day, _dateTime.hour - 12)) &&
            todayProduction <= 1) {
          // print("No Production");
          _plantStatus = PlantStatus.noProduction;
        } else {
          // print("No Communication");
          _plantStatus = PlantStatus.noCommunication;
        }
      }
    } else
      _plantStatus = PlantStatus.idle;

    // print(lastCommunication);

    return PlantModel(
        id: json['meterId'],
        name: json['plantName'],
        todayEnergy: todayProduction,
        lastCommunication: lastCommunication,
        plantStatus: _plantStatus,
        monthlyEnergy: json['monthProduction'] != null
            ? double.parse(json['monthProduction'])
            : 0.0,
        yearEnergy: json['yearProduction'] != null
            ? double.parse(json['yearProduction'])
            : 0.0,
        lifeTimeEnergy: json['lifetimeProduction'] != null
            ? double.parse(json['lifetimeProduction'])
            : 0.0,
        capacity: double.parse(json['capacity']),
        city: json["city"] != null ? json["city"] : "N.A",
        state: json["city"] != null ? json["city"] : "N.A",
        feed: json["FeedinTariff"] != null ? json["FeedinTariff"] : "0",
        address: "",
        zipCode: "");
  }
}
