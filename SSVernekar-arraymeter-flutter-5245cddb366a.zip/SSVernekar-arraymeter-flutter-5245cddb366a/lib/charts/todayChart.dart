import 'dart:math';
import 'package:arraymeter/Networkmodule/network.dart';
import 'package:arraymeter/providers/providers.dart';
import 'package:charts_flutter/flutter.dart' hide Axis;
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:provider/provider.dart';
import '../services/service.dart';
import 'graphTool.dart';

double totalEnery = 0.0;

// ignore: must_be_immutable
class TodayChart extends StatefulWidget {
  DateTime ticketDate;

  TodayChart({this.ticketDate});

  @override
  _TodayChartState createState() => _TodayChartState();
}

class _TodayChartState extends State<TodayChart> {
  List<charts.Series<Graph, int>> _seriesLineData1 = [];
  List<Graph> dayTable = [];
  List<charts.Series<Graph, String>> _seriesLineData = [];

  DateTime _dateTime;
  bool _loding = true;
  bool _minGraph = true;
  List<Point> todayGraffValues = [];

  final customTickFormatter = charts.BasicNumericTickFormatterSpec((num value) {
    switch (value) {
      case 1:
        return "12AM";
        break;
      case 12:
        return "";
        break;
      case 24:
        return "6AM";
        break;
      case 36:
        return "";
        break;
      case 48:
        return "12PM";
        break;
      case 60:
        return "";
        break;
      case 72:
        return "6PM";
        break;
      case 84:
        return "";
        break;
      case 96:
        return "12AM";
        break;

      default:
        return "";
    }
  });

  Future _generateTodayGraph() async {
    // print("mingraphshow:$_minGraph");
    totalEnery = 0.0;
    _seriesLineData.clear();
    _seriesLineData1.clear();

    todayGraffValues =
        await NetworkHelper.getGData(_dateTime, _minGraph == false ? 0 : 3);
    List<Graph> linesalesdata = [];

    if (_minGraph) {
      //minutevice graph

      if (todayGraffValues.isNotEmpty) {
// print(todayGraffValues.length);

        // print("totalEnergy:$totalEnery");

        for (int i = 0; i < todayGraffValues.length; i++) {
          double value = double.parse(todayGraffValues[i].y);

          totalEnery = totalEnery + double.parse(todayGraffValues[i].y);
          linesalesdata.add(Graph(i + 1, value));
        }
      }
      if (linesalesdata.isNotEmpty)
        _seriesLineData1.add(
          charts.Series(
            id: 'Air Pollution',
            data: linesalesdata,
            // ignore: non_constant_identifier_names
            colorFn: (Sales, int) =>
                charts.ColorUtil.fromDartColor(Services.colors.graffColor),
            // ignore: non_constant_identifier_names
            areaColorFn: (Sales, int) =>
                charts.ColorUtil.fromDartColor(Services.colors.graffColor),
            // ignore: non_constant_identifier_names
            fillColorFn: (Sales, int) =>
                charts.ColorUtil.fromDartColor(Services.colors.graffColor),
            fillPatternFn: (_, __) => charts.FillPatternType.solid,
            domainFn: (Graph sales, _) => sales.year,
            measureFn: (Graph sales, _) => sales.quantity,
          ),
        );
    } else {
      if (todayGraffValues.isNotEmpty) {
        for (int i = 0; i < todayGraffValues.length; i++) {
          double value = 0;

          value += double.parse(todayGraffValues[i].y);
          totalEnery = totalEnery + value;
          linesalesdata.add(Graph(i, value));
        }

        dayTable = linesalesdata;
      }
      if (linesalesdata.isNotEmpty)
        _seriesLineData.add(
          charts.Series(
            id: 'Air Pollution',
            data: linesalesdata,
            // ignore: non_constant_identifier_names
            colorFn: (Sales, int) =>
                charts.ColorUtil.fromDartColor(Services.colors.graffColor),
            // ignore: non_constant_identifier_names
            areaColorFn: (Sales, int) =>
                charts.ColorUtil.fromDartColor(Services.colors.graffColor),
            // ignore: non_constant_identifier_names
            fillColorFn: (Sales, int) =>
                charts.ColorUtil.fromDartColor(Services.colors.graffColor),
            fillPatternFn: (_, __) => charts.FillPatternType.solid,
            domainFn: (Graph sales, _) => (sales.year + 1).toString(),
            measureFn: (Graph sales, _) => sales.quantity,
          ),
        );
    }

    setState(() {
      _loding = false;
    });

    return 'ok';
  }

  @override
  // ignore: must_call_super
  void initState() {
    _dateTime = widget.ticketDate ?? DateTime.now();

    _generateTodayGraph();
  }

  Widget _formattedDate() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          //privious date
          IconButton(
            icon: Icon(
              Icons.chevron_left,
            ),
            onPressed: () async {
              setState(() {
                _dateTime = DateTime(
                    _dateTime.year, _dateTime.month, _dateTime.day - 1);
                _loding = true;
              });
              await _generateTodayGraph();
            },
          ),

          Container(
            height: 30,
            width: Services.getWidth(context) * 0.45,
            decoration: Services.boxDecoration,
            child: FlatButton(
              color: Colors.white,
              onPressed: () => Services.showCalender(
                  context: context,
                  selectedDate: (value) async {
                    setState(() {
                      _dateTime = value;

                      _loding = true;
                    });
                    await _generateTodayGraph();
                  },
                  initialDate: _dateTime,
                  type: 0),
              child: Text(
                  "${_dateTime.month.toString().padLeft(2, '0')}/${_dateTime.day.toString().padLeft(2, '0')}/${_dateTime.year}",
                  style: TextStyle(
                      fontSize: 17.0,
                      color: Services.colors.textColor,
                      fontWeight: FontWeight.bold)),
            ),
          ),

          //after date

          IconButton(
              icon: Icon(Icons.chevron_right),
              onPressed: () async {
                setState(() {
                  _dateTime = DateTime(
                      _dateTime.year, _dateTime.month, _dateTime.day + 1);
                  _loding = true;
                });
                await _generateTodayGraph();
              })
        ],
      );

  @override
  Widget build(BuildContext context) {
    bool _total = true;
    final ProviderBlock counterBlock =
        Provider.of<ProviderBlock>(context, listen: false);

    // counterBlock.setCounter(totalEnery);

    var todayTable = todayGraffValues.isNotEmpty
        ? Container(
            padding: EdgeInsets.fromLTRB(0, 30, 0, 30),
            height: 971,
            child: Center(
              child: Container(
                  height: 871,
                  width: 326,
                  decoration: Services.boxDecoration,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          height: 39,
                          decoration: Services.boxDecoration,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                alignment: Alignment.center,
                                height: 39,
                                width: 160,
                                decoration: Services.boxDecoration,
                                child: Text(
                                  'Time (hr)',
                                  style: TextStyle(
                                    color: Services.colors.textColor,
                                    fontFamily: Services.mont_regular,
                                    fontSize: 17,
                                  ),
                                ),
                              ),
                              Container(
                                alignment: Alignment.center,
                                height: 39,
                                width: 160,
                                decoration: Services.boxDecoration,
                                child: Text(
                                  'Energy (kWh)',
                                  style: TextStyle(
                                    color: Services.colors.textColor,
                                    fontFamily: Services.mont_regular,
                                    fontSize: 17,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        Container(
                            margin: EdgeInsets.zero,
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    height: 829,
                                    width: 162,
                                    margin: EdgeInsets.zero,
                                    decoration: Services.boxDecoration,
                                    child: ListView.builder(
                                        scrollDirection: Axis.vertical,
                                        shrinkWrap: true,
                                        physics: ScrollPhysics(),
                                        itemCount: dayTable.length,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return Container(
                                              child: day(
                                                  dayTable[index]
                                                      .year
                                                      .toString(),
                                                  index));
                                        }),
                                  ),
                                  Container(
                                    height: 829,
                                    width: 162,
                                    decoration: Services.boxDecoration,
                                    child: ListView.builder(
                                      scrollDirection: Axis.vertical,
                                      shrinkWrap: true,
                                      physics: ScrollPhysics(),
                                      itemCount: dayTable.length,
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                        return Container(
                                            child: quantity(
                                                dayTable[index]
                                                    .quantity
                                                    .toStringAsFixed(1)
                                                    .replaceAllMapped(
                                                        reg, mathFunc),
                                                index));
                                      },
                                    ),
                                  ),
                                ])),
                      ])),
            ))
        : null;

    return

        // Padding(
        // padding: EdgeInsets.all(8.0),
        // child:
        OrientationBuilder(builder: (context, orientation) {
      return SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(children: [
            Container(
                child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Container(
                child: Center(
                    child: Column(
                  children: <Widget>[
                    // Row(
                    //   // mainAxisAlignment: MainAxisAlignment.start,
                    //   children: [
                    Container(
                      // width: Services.getWidth(context) * 0.75,
                      child: Column(
                        children: [
                          _formattedDate(),
                          Consumer<ProviderBlock>(
                              builder: (context, cart, child) {
                            return Text(
                              _total
                                  ? "Day Production: ${totalEnery.toStringAsFixed(1).replaceAllMapped(reg, mathFunc)} kWh"
                                  : "Production: ${cart.getCounter.toStringAsFixed(1).replaceAllMapped(reg, mathFunc)} kWh",
                              style: TextStyle(
                                  fontFamily: Services.mont_regular,
                                  color: Services.colors.textColor),
                            );
                          })
                        ],
                      ),
                    ),
                    // Padding(
                    //     padding: EdgeInsets.only(bottom: 15.0),
                    //     child: Container(
                    //       height: 55,
                    //       width: 55,
                    //       child: IconButton(
                    //         icon: Image.asset(_minGraph == false
                    //             ? Images.hourInterval
                    //             : Images.minInterval),
                    //         onPressed: () async {
                    //           setState(() {
                    //             _minGraph = !_minGraph;
                    //             _loding = true;
                    //           });
                    //
                    //           await _generateTodayGraph();
                    //         },
                    //       ),
                    //     ))
                    //   ],
                    // ),

                    todayGraffValues.isNotEmpty
                        ?
                        // if (snapshot.hasData)
                        SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Container(
                                height: orientation == Orientation.landscape
                                    ? Services.getHieght(context) * 0.6
                                    : 380,
                                width: MediaQuery.of(context).orientation ==
                                        Orientation.landscape
                                    ? Services.getWidth(context)
                                    : _minGraph
                                        ? Services.getWidth(context) * 0.9
                                        : Services.getWidth(context) * 1.2,
                                child: _loding
                                    ? Text(
                                        'Loading',
                                        style: TextStyle(
                                            fontSize: 18,
                                            color: Services.colors.textColor,
                                            fontFamily: Services.mont_regular),
                                      )
                                    : _minGraph
                                        ? charts.LineChart(_seriesLineData1,
                                            defaultRenderer:
                                                new charts.LineRendererConfig(
                                                    includeArea: true,
                                                    includeLine: false,
                                                    includePoints: false,
                                                    stacked: true),
                                            animate: true,
                                            domainAxis: charts.NumericAxisSpec(
                                              viewport: NumericExtents(1, 96),
                                              tickProviderSpec: charts
                                                  .BasicNumericTickProviderSpec(
                                                desiredTickCount: 97,
                                                // zeroBound: false,
                                              ),
                                              tickFormatterSpec:
                                                  customTickFormatter,
                                            ),
                                            primaryMeasureAxis:
                                                new charts.NumericAxisSpec(
                                              tickProviderSpec: new charts
                                                      .BasicNumericTickProviderSpec(
                                                  desiredTickCount: 6,
                                                  dataIsInWholeNumbers: false),
                                            ),
                                            selectionModels: [
                                              SelectionModelConfig(
                                                  changedListener:
                                                      (SelectionModel model) {
                                                if (model.hasDatumSelection) {
                                                  // print(durationToString(15*model.selectedSeries[0].domainFn(model.selectedDatum[0].index)));
                                                  toolTipTime =
                                                      durationToString(15 *
                                                          model
                                                              .selectedSeries[0]
                                                              .domainFn(model
                                                                  .selectedDatum[
                                                                      0]
                                                                  .index));
                                                }

                                                _total = false;

                                                counterBlock.setCounter(model
                                                    .selectedSeries[0]
                                                    .measureFn(model
                                                        .selectedDatum[0]
                                                        .index));
                                              })
                                            ],
                                            animationDuration:
                                                Duration(seconds: 1),
                                            behaviors: [
                                              LinePointHighlighter(
                                                  symbolRenderer:
                                                      CustomCircleSymbolRendererLineChart()),

                                              new charts.ChartTitle('kWh',
                                                  behaviorPosition: charts
                                                      .BehaviorPosition.start,
                                                  titleOutsideJustification:
                                                      charts
                                                          .OutsideJustification
                                                          .middleDrawArea),
                                              // new charts.ChartTitle('Departments',
                                              //     behaviorPosition: charts.BehaviorPosition.end,
                                              //     titleOutsideJustification:charts.OutsideJustification.middleDrawArea,
                                              //     )
                                            ])
                                        : charts.BarChart(_seriesLineData,
                                            animate: true,

                                            // domainAxis: charts.NumericAxisSpec(
                                            //   viewport: NumericExtents(1, 24),
                                            //   tickProviderSpec:
                                            //   charts.BasicNumericTickProviderSpec(
                                            //     desiredTickCount: 97,
                                            //     zeroBound: false,
                                            //   ),
                                            //   tickFormatterSpec: customTickFormatter,
                                            // ),

                                            primaryMeasureAxis:
                                                new charts.NumericAxisSpec(
                                              tickProviderSpec: new charts
                                                      .BasicNumericTickProviderSpec(
                                                  desiredTickCount: 6,
                                                  dataIsInWholeNumbers: false),
                                            ),
                                            selectionModels: [
                                              SelectionModelConfig(
                                                  changedListener:
                                                      (SelectionModel model) {
                                                if (model.hasDatumSelection)
                                                  // print(model.selectedSeries[0].measureFn(
                                                  //     model.selectedDatum[0].index));
                                                  toolTip = (model
                                                      .selectedSeries[0]
                                                      .measureFn(model
                                                          .selectedDatum[0]
                                                          .index));
                                              })
                                            ],
                                            animationDuration:
                                                Duration(seconds: 1),
                                            behaviors: [
                                              LinePointHighlighter(
                                                  symbolRenderer:
                                                      CustomCircleSymbolRenderer()),
                                              new charts.ChartTitle('kWh',
                                                  behaviorPosition: charts
                                                      .BehaviorPosition.start,
                                                  titleOutsideJustification:
                                                      charts
                                                          .OutsideJustification
                                                          .middleDrawArea),
                                            ])),
                          )
                        : Center(
                            child: Container(
                                margin: EdgeInsets.only(
                                    top: Services.getHieght(context) * 0.2),
                                child: Text("No data in this date",
                                    style: TextStyle(
                                        fontFamily: Services.mont_regular,
                                        fontSize: 22,
                                        color: Services.colors.textColor))),
                          )
                  ],
                )),
              ),
            )),
            Container(
                child: _minGraph ||
                        MediaQuery.of(context).orientation ==
                            Orientation.landscape
                    ? null
                    : todayTable)
          ]));
    });
    // );
  }

  String durationToString(int minutes) {
    print(minutes);
    var d = Duration(minutes: minutes);
    List<String> parts = d.toString().split(':');
    return '${parts[0].padLeft(2, '0')}:${parts[1].padLeft(2, '0')}';
  }

  Widget day(String data, int position) {
    return Container(
        alignment: Alignment.center,
        height: 34,
        width: 200,
        color: position.isOdd ? Services.colors.tableHeighlight : Colors.white,
        child: Text(
          data,
          style: TextStyle(
            color: Services.colors.textColor,
            fontFamily: Services.mont_regular,
            fontSize: 15,
          ),
        ));
  }

  Widget quantity(String data, int position) {
    return Container(
        alignment: Alignment.center,
        height: 34,
        width: 200,
        color: position.isOdd ? Services.colors.tableHeighlight : Colors.white,
        child: Text(
          data,
          style: TextStyle(
            color: Services.colors.textColor,
            fontFamily: Services.mont_regular,
            fontSize: 15,
          ),
        ));
  }
}
