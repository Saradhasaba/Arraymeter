import 'package:arraymeter/Networkmodule/network.dart';
import 'package:arraymeter/services/service.dart';
import 'package:charts_flutter/flutter.dart' hide Axis;
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;

import 'graphTool.dart';

List<Graph> monthTable = [];
double totalEnery = 0.0;

class MonthData extends StatefulWidget {
  @override
  _MonthDataState createState() => _MonthDataState();
}

class _MonthDataState extends State<MonthData> {
  DateTime _dateTime = DateTime.now();

  bool _loding = true;
  List<charts.Series<Graph, String>> _seriesData = [];

  @override
  // ignore: must_call_super
  void initState() {
    _generateMonthlyGraph();
  }

  Widget _formattedDate() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          //privious date
          IconButton(
            icon: Icon(
              Icons.chevron_left,
            ),
            onPressed: () async {
              setState(() {
                _dateTime = DateTime(
                    _dateTime.year, _dateTime.month - 1, _dateTime.day);

                _loding = true;
              });
              await _generateMonthlyGraph();
            },
          ),

          Container(
            height: 30,
            width: 200,
            decoration: Services.boxDecoration,
            child: FlatButton(
              color: Colors.white,
              onPressed: () => Services.showCalender(
                  context: context,
                  selectedDate: (value) async {
                    setState(() {
                      _dateTime = value;
                      _loding = true;
                    });
                    await _generateMonthlyGraph();
                  },
                  initialDate: _dateTime,
                  type: 1),
              child: Text(
                  "${Services.month(_dateTime.month)}-${_dateTime.year}",
                  style: TextStyle(
                      fontSize: 17.0,
                      color: Services.colors.textColor,
                      fontWeight: FontWeight.bold)),
            ),
          ),

          //after date

          IconButton(
              icon: Icon(Icons.chevron_right),
              onPressed: () async {
                setState(() {
                  _dateTime = DateTime(
                      _dateTime.year, _dateTime.month + 1, _dateTime.day);
                  _loding = true;
                });
                await _generateMonthlyGraph();
              })
        ],
      );

  List<Point> monthlyGraffValues = [];

  Future _generateMonthlyGraph() async {
    totalEnery = 0.0;

    monthlyGraffValues = await NetworkHelper.getGData(_dateTime, 1);

    List<Graph> data1 = [];

    //month

    for (int i = 1; i <= monthlyGraffValues.length; i++) {
      double value = double.parse(monthlyGraffValues[i - 1].y);
      data1.add(Graph(i, value));

      totalEnery = totalEnery + value;
    }
    monthTable = data1;
    _seriesData.clear();
    _seriesData.add(
      charts.Series(
        domainFn: (Graph pollution, _) => pollution.year.toString(),
        measureFn: (Graph pollution, _) => pollution.quantity,
        id: '2017',
        data: data1,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Graph pollution, _) =>
            charts.ColorUtil.fromDartColor(Services.colors.graffColor),
      ),
    );

    setState(() {
      _loding = false;
    });

    return 'ok';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: EdgeInsets.all(8.0),
        child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(children: [
              Container(
                  child: Column(
                children: <Widget>[
                  _formattedDate(),
                  Text(
                    "Monthly Production:${totalEnery.round().toStringAsFixed(0).replaceAllMapped(reg, mathFunc)} kWh",
                    style: TextStyle(
                        fontFamily: Services.mont_regular,
                        color: Services.colors.textColor),
                  ),
                  monthlyGraffValues.isNotEmpty
                      ? SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Container(
                              height: MediaQuery.of(context).orientation ==
                                      Orientation.landscape
                                  ? Services.getHieght(context) * 0.6
                                  : 380,
                              width: MediaQuery.of(context).orientation ==
                                      Orientation.portrait
                                  ? Services.getWidth(context) * 1.8
                                  : Services.getWidth(context) * 1,
                              child: _loding
                                  ? Text(
                                      'Loading',
                                      style: TextStyle(
                                          fontSize: 18,
                                          color: Services.colors.textColor,
                                          fontFamily: Services.mont_regular),
                                    )
                                  : charts.BarChart(
                                      _seriesData,
                                      animate: true,
                                      barGroupingType:
                                          charts.BarGroupingType.stacked,
                                      animationDuration: Duration(seconds: 1),

                                      // primaryMeasureAxis:  new charts.NumericAxisSpec(
                                      //   tickProviderSpec: new charts.BasicNumericTickProviderSpec(desiredTickCount: 3,
                                      //       dataIsInWholeNumbers: false),
                                      // ),

                                      selectionModels: [
                                        SelectionModelConfig(changedListener:
                                            (SelectionModel model) {
                                          if (model.hasDatumSelection)
                                            print(model.selectedSeries[0]
                                                .measureFn(model
                                                    .selectedDatum[0].index));
                                          toolTip = model.selectedSeries[0]
                                              .measureFn(
                                                  model.selectedDatum[0].index);
                                        })
                                      ],

                                      behaviors: [
                                        LinePointHighlighter(
                                            symbolRenderer:
                                                CustomCircleSymbolRenderer()),
                                        new charts.ChartTitle('kWh',
                                            behaviorPosition:
                                                charts.BehaviorPosition.start,
                                            titleOutsideJustification: charts
                                                .OutsideJustification
                                                .middleDrawArea),
                                      ],
                                    )),
                        )
                      : Container(
                          margin: EdgeInsets.only(
                              top: Services.getHieght(context) * 0.2),
                          child: Text("No data in this month",
                              style: TextStyle(
                                  fontFamily: Services.mont_regular,
                                  fontSize: 22,
                                  color: Services.colors.textColor)),
                        ),
                ],
              )),
              Container(
                child: MediaQuery.of(context).orientation ==
                            Orientation.landscape ||
                        monthlyGraffValues.isEmpty
                    ? null
                    : monthsTable(monthTable),
              ),
            ])));
  }

  Widget monthsTable(monthTable) => Container(
      padding: EdgeInsets.fromLTRB(0, 30, 0, 30),
      child: Center(
        child: Container(
            width: Services.size <= Services.iphone5Screen ? 285 : 326,
            decoration: Services.boxDecoration,
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 39,
                    decoration: Services.boxDecoration,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          alignment: Alignment.center,
                          height: 39,
                          width: Services.size <= Services.iphone5Screen
                              ? 140
                              : 161,
                          decoration: Services.boxDecoration,
                          child: Text(
                            'Date',
                            style: TextStyle(
                              color: Services.colors.textColor,
                              fontFamily: Services.mont_regular,
                              fontSize: Services.size <= Services.iphone5Screen
                                  ? 15
                                  : 18,
                            ),
                          ),
                        ),
                        Container(
                          alignment: Alignment.center,
                          height: 39,
                          width: Services.size <= Services.iphone5Screen
                              ? 141
                              : 161,
                          decoration: Services.boxDecoration,
                          child: Text(
                            'Energy (kWh)',
                            style: TextStyle(
                              color: Services.colors.textColor,
                              fontFamily: Services.mont_regular,
                              fontSize: Services.size <= Services.iphone5Screen
                                  ? 15
                                  : 17,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Container(
                      margin: EdgeInsets.zero,
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              width: Services.size <= Services.iphone5Screen
                                  ? 141
                                  : 162,
                              margin: EdgeInsets.zero,
                              decoration: Services.boxDecoration,
                              child: ListView.builder(
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemCount: monthTable.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Container(
                                        child: day(
                                            _dateTime.month
                                                    .toString()
                                                    .padLeft(2, "0") +
                                                "-" +
                                                monthTable[index]
                                                    .year
                                                    .toString()
                                                    .padLeft(2, "0") +
                                                "-" +
                                                _dateTime.year.toString(),
                                            index));
                                  }),
                            ),
                            Container(
                              width: Services.size <= Services.iphone5Screen
                                  ? 142
                                  : 162,
                              decoration: Services.boxDecoration,
                              child: ListView.builder(
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemCount: monthTable.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Container(
                                        child: quantity(
                                            monthTable[index]
                                                .quantity
                                                .toStringAsFixed(1)
                                                .replaceAllMapped(
                                                    reg, mathFunc),
                                            index));
                                  }),
                            ),
                          ])),
                  Row(
                    children: [
                      Container(
                        width:
                            Services.size <= Services.iphone5Screen ? 141 : 162,
                        height: 30,
                        decoration: Services.boxDecoration,
                        child: Center(
                          child: Text("Total",
                              style: TextStyle(
                                color: Services.colors.textColor,
                                fontFamily: Services.mont_regular,
                                fontSize: 15,
                              )),
                        ),
                      ),
                      Container(
                          width: Services.size <= Services.iphone5Screen
                              ? 142
                              : 162,
                          height: 30,
                          decoration: Services.boxDecoration,
                          child: Center(
                            child: Text(
                                totalEnery
                                    .roundToDouble()
                                    .toStringAsFixed(0)
                                    .replaceAllMapped(reg, mathFunc),
                                style: TextStyle(
                                  color: Services.colors.textColor,
                                  fontFamily: Services.mont_regular,
                                  fontSize: 15,
                                )),
                          ))
                    ],
                  )
                ])),
      ));

  Widget day(String data, int position) {
    return Container(
        alignment: Alignment.center,
        height: 34,
        width: 200,
        color: position.isEven ? Services.colors.tableOddColor : Colors.white,
        child: Text(
          data,
          style: TextStyle(
            color: Services.colors.textColor,
            fontFamily: Services.mont_regular,
            fontSize: 15,
          ),
        ));
  }

  Widget quantity(String data, int position) {
    return Container(
        alignment: Alignment.center,
        height: 34,
        width: 200,
        color: position.isEven ? Services.colors.tableOddColor : Colors.white,
        child: Text(
          data,
          style: TextStyle(
            color: Services.colors.textColor,
            fontFamily: Services.mont_regular,
            fontSize: 15,
          ),
        ));
  }
}
