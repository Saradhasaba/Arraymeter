import 'package:charts_flutter/flutter.dart' hide Axis;
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;

import '../NetworkModule/network.dart';
import '../services/service.dart';
import 'graphTool.dart';

double totalEnery = 0.0;
List<Graph> yearTable = [];

class YearChart extends StatefulWidget {
  @override
  _YearChartState createState() => _YearChartState();
}

class _YearChartState extends State<YearChart> {
  bool _loading = true;
  DateTime _dateTime = DateTime.now();
  List<charts.Series<Graph, String>> _seriesLineData2 = [];
  List<Graph> data2 = [];

  Future _generateYearlyGraph() async {
    totalEnery = 0.0;
    data2.clear();

    List response = await NetworkHelper.geatYearGraphData(_dateTime.year);

    yearTable = data2;

    if (response != null) {
      print(response.runtimeType);

      for (List data in response) {
        print(data);

        data2.add(Graph(response.indexOf(data) + 1, data[1].toDouble()));

        totalEnery += data[1];
      }
    }

    print("data:..............$data2");

    // yearlyGraffValues = await NetworkHelper.getGData(_dateTime, 2);

    //year

    // if (yearlyGraffValues.isNotEmpty) {
    //
    //
    //
    //   int maxDaysPerMonth = 0;
    //   int aded = 0;
    //
    //   for (var i = 1; i <= 12; i++) {
    //     switch (i) {
    //       case 2:
    //         if (yearlyGraffValues.length == 367)
    //           maxDaysPerMonth = 29;
    //         else
    //           maxDaysPerMonth = 28;
    //         break;
    //
    //       case 4:
    //         maxDaysPerMonth = 30;
    //         break;
    //
    //       case 6:
    //         maxDaysPerMonth = 30;
    //         break;
    //
    //       case 9:
    //         maxDaysPerMonth = 30;
    //         break;
    //
    //       case 11:
    //         maxDaysPerMonth = 30;
    //         break;
    //       default:
    //         maxDaysPerMonth = 31;
    //
    //         break;
    //     }
    //
    //     // double monthValue = 0;
    //
    //     // for (var j = aded; j < aded + maxDaysPerMonth; j++) {
    //     //
    //     //
    //     //
    //     //   monthValue += double.parse(yearlyGraffValues[j].y);
    //     //
    //     //
    //     //
    //     // }
    //
    //     double monthValue =
    //         double.parse(yearlyGraffValues[aded + maxDaysPerMonth].y);
    //
    //     aded += maxDaysPerMonth;
    //
    //     // print(monthValue/1000);
    //     // double value = monthValue / 1000;
    //
    //     data2.add(Graph(i, monthValue));
    //     totalEnery += monthValue;
    //   }
    // }

    _seriesLineData2.clear();

    _seriesLineData2.add(
      charts.Series(
        domainFn: (Graph pollution, _) => pollution.year.toString(),
        measureFn: (Graph pollution, _) => pollution.quantity,
        id: '2017',
        data: data2,
        fillPatternFn: (_, __) => charts.FillPatternType.solid,
        fillColorFn: (Graph pollution, _) =>
            charts.ColorUtil.fromDartColor(Services.colors.graffColor),
      ),
    );

    setState(() {
      _loading = false;
    });

    return 'ok';
  }

  Widget _formattedDate() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          //privious date
          IconButton(
            icon: Icon(
              Icons.chevron_left,
            ),
            onPressed: () async {
              setState(() {
                _loading = true;
                _dateTime = DateTime(
                    _dateTime.year - 1, _dateTime.month, _dateTime.day);
              });
              await _generateYearlyGraph();
            },
          ),

          Container(
            height: 30,
            width: 200,
            decoration: Services.boxDecoration,
            child: FlatButton(
              color: Colors.white,
              onPressed: () => Services.showCalender(
                  context: context,
                  selectedDate: (value) async {
                    setState(() {
                      _loading = true;

                      _dateTime = value;
                    });
                    await _generateYearlyGraph();
                  },
                  initialDate: _dateTime,
                  type: 2),
              child: Text("${_dateTime.year}",
                  style: TextStyle(
                      fontSize: 17.0,
                      color: Services.colors.textColor,
                      fontWeight: FontWeight.bold)),
            ),
          ),

          //after date

          IconButton(
              icon: Icon(Icons.chevron_right),
              onPressed: () async {
                setState(() {
                  _loading = true;
                  _dateTime = DateTime(
                      _dateTime.year + 1, _dateTime.month, _dateTime.day);
                });
                await _generateYearlyGraph();
              })
        ],
      );

  @override
  void initState() {
    _generateYearlyGraph();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: EdgeInsets.all(8.0),
        child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(children: [
              Container(
                  child: Column(
                children: <Widget>[
                  _formattedDate(),
                  Text(
                    "Yearly Production: ${totalEnery.round().toStringAsFixed(0).replaceAllMapped(reg, mathFunc)} kWh",
                    style: TextStyle(
                        fontFamily: Services.mont_regular,
                        color: Services.colors.textColor),
                  ),
                  Container(
                    height: MediaQuery.of(context).orientation ==
                            Orientation.landscape
                        ? Services.getHieght(context) * 0.6
                        : 380,
                    width: Services.getWidth(context),
                    child: data2.isNotEmpty
                        ? SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Container(
                                width: Services.getWidth(context),
                                child: _loading
                                    ? Text(
                                        'Loading',
                                        style: TextStyle(
                                            fontSize: 18,
                                            color: Services.colors.textColor,
                                            fontFamily: Services.mont_regular),
                                      )
                                    : charts.BarChart(
                                        _seriesLineData2,
                                        animate: true,
                                        barGroupingType:
                                            charts.BarGroupingType.stacked,
                                        animationDuration: Duration(seconds: 1),
                                        selectionModels: [
                                          SelectionModelConfig(changedListener:
                                              (SelectionModel model) {
                                            if (model.hasDatumSelection)
                                              // print(model.selectedSeries[0].measureFn(
                                              //     model.selectedDatum[0].index));
                                              toolTip = model.selectedSeries[0]
                                                  .measureFn(model
                                                      .selectedDatum[0].index);
                                          })
                                        ],
                                        behaviors: [
                                          LinePointHighlighter(
                                              symbolRenderer:
                                                  CustomCircleSymbolRenderer()),
                                          new charts.ChartTitle('kWh',
                                              behaviorPosition:
                                                  charts.BehaviorPosition.start,
                                              titleOutsideJustification: charts
                                                  .OutsideJustification
                                                  .middleDrawArea),
                                        ],
                                        primaryMeasureAxis:
                                            new charts.NumericAxisSpec(
                                          tickProviderSpec: new charts
                                                  .BasicNumericTickProviderSpec(
                                              desiredTickCount: 4,
                                              dataIsInWholeNumbers: false),
                                        ),
                                      )),
                          )
                        : Center(
                            child: Text("No data in this year",
                                style: TextStyle(
                                    fontFamily: Services.mont_regular,
                                    fontSize: 22,
                                    color: Services.colors.textColor)),
                          ),
                  ),
                ],
              )),
              Container(
                  child: data2.isNotEmpty &&
                          MediaQuery.of(context).orientation ==
                              Orientation.portrait
                      ? yearsTable(yearTable)
                      : null)
            ])));
  }

  Widget yearsTable(yearTable) => Container(
      padding: EdgeInsets.fromLTRB(0, 30, 0, 0),
      height: 512,
      child: Center(
        child: Container(
            width: 326,
            decoration: Services.boxDecoration,
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 39,
                    decoration: Services.boxDecoration,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          alignment: Alignment.center,
                          height: 39,
                          width: Services.size <= Services.iphone5Screen
                              ? 140
                              : 160,
                          decoration: Services.boxDecoration,
                          child: Text(
                            'Month',
                            style: TextStyle(
                              color: Services.colors.textColor,
                              fontFamily: Services.mont_regular,
                              fontSize: Services.size <= Services.iphone5Screen
                                  ? 15
                                  : 17,
                            ),
                          ),
                        ),
                        Container(
                          alignment: Alignment.center,
                          height: 39,
                          width: 160,
                          decoration: Services.boxDecoration,
                          child: Text(
                            'Energy (kWh)',
                            style: TextStyle(
                              color: Services.colors.textColor,
                              fontFamily: Services.mont_regular,
                              fontSize: Services.size <= Services.iphone5Screen
                                  ? 15
                                  : 17,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Container(
                      margin: EdgeInsets.zero,
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              height: 410,
                              width: Services.size <= Services.iphone5Screen
                                  ? 140
                                  : 162,
                              margin: EdgeInsets.zero,
                              decoration: Services.boxDecoration,
                              child: ListView.builder(
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemCount: yearTable.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Container(
                                        child: day(
                                            Services.month(
                                                    yearTable[index].year) +
                                                "-" +
                                                _dateTime.year.toString(),
                                            index));
                                  }),
                            ),
                            Container(
                              height: 410,
                              width: 162,
                              decoration: Services.boxDecoration,
                              child: ListView.builder(
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemCount: yearTable.length,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return Container(
                                        child: quantity(
                                            yearTable[index]
                                                .quantity
                                                .toStringAsFixed(1)
                                                .replaceAllMapped(
                                                    reg, mathFunc),
                                            index));
                                  }),
                            ),
                          ])),
                  Row(
                    children: [
                      Container(
                        color: Services.colors.tableOddColor,
                        child: Container(
                            width: Services.size <= Services.iphone5Screen
                                ? 140
                                : 162,
                            height: 31,
                            decoration: Services.boxDecoration,
                            child: Center(
                              child: Text("Total",
                                  style: TextStyle(
                                    color: Services.colors.textColor,
                                    fontFamily: Services.mont_regular,
                                    fontSize:
                                        Services.size <= Services.iphone5Screen
                                            ? 13
                                            : 15,
                                  )),
                            )),
                      ),
                      Container(
                        color: Services.colors.tableOddColor,
                        child: Container(
                            width: 162,
                            height: 31,
                            decoration: Services.boxDecoration,
                            child: Center(
                              child: Text(
                                  totalEnery
                                      .toStringAsFixed(0)
                                      .replaceAllMapped(reg, mathFunc),
                                  style: TextStyle(
                                    color: Services.colors.textColor,
                                    fontFamily: Services.mont_regular,
                                    fontSize:
                                        Services.size <= Services.iphone5Screen
                                            ? 13
                                            : 15,
                                  )),
                            )),
                      )
                    ],
                  )
                ])),
      ));

  Widget day(String data, int position) {
    return Container(
        alignment: Alignment.center,
        height: 34,
        width: 200,
        color: position.isEven ? Services.colors.tableOddColor : Colors.white,
        child: Text(
          data,
          style: TextStyle(
            color: Services.colors.textColor,
            fontFamily: Services.mont_regular,
            fontSize: Services.size <= Services.iphone5Screen ? 13 : 15,
          ),
        ));
  }

  Widget quantity(String data, int position) {
    return Container(
        alignment: Alignment.center,
        height: 34,
        width: 200,
        color: position.isEven ? Services.colors.tableOddColor : Colors.white,
        child: Text(
          data,
          style: TextStyle(
            color: Services.colors.textColor,
            fontFamily: Services.mont_regular,
            fontSize: Services.size <= Services.iphone5Screen ? 13 : 15,
          ),
        ));
  }
}
