import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_cupertino_date_picker/flutter_cupertino_date_picker.dart';

import 'constants.dart';

typedef DateValueCallBack = void Function(DateTime dateTime);
typedef onChangedCallBack = void Function(String text);

typedef onPopUpSelectedCallBack = void Function(int text);

typedef onItemSelectedCallBack = void Function(Map text);

class Services {
  static ColorBase _colorBase = ColorBase();
  static Texts _texts = Texts();

  // ignore: non_constant_identifier_names
  static String mont_regular = 'Montesarat';

  // ignore: non_constant_identifier_names
  static String mont_med = 'Montesarat-med';
  static String digitalFont = 'digital';
  static Size minimumSize = Size(360.0, 640.0);
  static Size iphone5Screen = Size(320.0, 568.3);
  static Size size;

  static TextStyle screenHeadingTextStyle = TextStyle(
    fontSize: 17,
    fontFamily: Services.mont_med,
  );

  static ColorBase get colors => _colorBase;

  static Texts get texts => _texts;

  static TextStyle cardTextStyle = TextStyle(
      color: _colorBase.textColor, fontFamily: mont_regular, fontSize: 16);

  static TextStyle fieldLabel = TextStyle(
      color: _colorBase.textColor, fontFamily: mont_regular, fontSize: 18);
  static BoxDecoration boxDecoration =
      BoxDecoration(border: Border.all(color: _colorBase.appBarColor));

  static BoxDecoration boxDecorationForMessageTilefrom = BoxDecoration(
      color: Color(0x99d7f9f7),
      border: Border.all(color: Colors.blueGrey),
      borderRadius: BorderRadius.all(Radius.circular(10)));

  static BoxDecoration boxDecorationForMessageTile = BoxDecoration(
      border: Border.all(color: Colors.blueGrey),
      borderRadius: BorderRadius.all(Radius.circular(10)));

  static getHieght(BuildContext context) => MediaQuery.of(context).size.height;

  static getWidth(BuildContext context) => MediaQuery.of(context).size.width;

  static String numberToPhone(String number) =>
      "(${number[0]}${number[1]}${number[2]}) ${number[3]}${number[4]}${number[5]}-${number[6]}${number[7]}${number[8]}${number[9]}";

  static String phoneToNum(String fPhoneNumber) =>
      fPhoneNumber[1] +
      fPhoneNumber[2] +
      fPhoneNumber[3] +
      fPhoneNumber[6] +
      fPhoneNumber[7] +
      fPhoneNumber[8] +
      fPhoneNumber[10] +
      fPhoneNumber[11] +
      fPhoneNumber[12] +
      fPhoneNumber[13];

  static String day(DateTime day) {
    switch (day.weekday) {
      case 0:
        return "Sunday";
      case 1:
        return "Monday";
      case 2:
        return "Tuesday";
      case 3:
        return "Wednesday";
      case 4:
        return "Thursday";
      case 5:
        return "Friday";
      case 6:
        return "Saturday";
        break;
      default:
        return "";
    }
  }

  static String month(int month) {
    switch (month) {
      case 1:
        return "January";
      case 2:
        return "February";
      case 3:
        return "March";
      case 4:
        return "April";
      case 5:
        return "May";
      case 6:
        return "June";
      case 7:
        return "July";
      case 8:
        return "August";
      case 9:
        return "September";
      case 10:
        return "October";
      case 11:
        return "November";
      case 12:
        return "December";
      default:
        return "";
    }
  }

  static String backendDate(_dateTime) =>
      _dateTime.month.toString() +
      '/' +
      _dateTime.day.toString() +
      '/' +
      _dateTime.year.toString();

  static showCalender(
      {BuildContext context,
      int type,
      DateTime initialDate,
      DateValueCallBack selectedDate}) {
    DatePicker.showDatePicker(
      context,
      pickerTheme: DateTimePickerTheme(
        showTitle: true,
        confirm:
            Text('Done', style: TextStyle(color: Services.colors.appBarColor)),
        cancel: Text('Cancel', style: TextStyle(color: Colors.red)),
      ),
      minDateTime: DateTime(1900, 3, 5),
      maxDateTime: DateTime.now(),
      initialDateTime: initialDate,
      dateFormat: type == 0
          ? "MM-dd-yyyy"
          : type == 1
              ? "MMMM-yyyy"
              : "yyyy",
      locale: DateTimePickerLocale.en_us,
      onClose: () => print("----- onClose -----"),
      onCancel: () => print('onCancel'),
      onChange: (dateTime, List<int> index) {},
      onConfirm: (dateTime, List<int> index) async {
        selectedDate(dateTime);
      },
    );
  }

  static Future<bool> deleteData(
      BuildContext context, String deleteItem) async {
    bool _deleteconfirm = false;
    await showDialog(
      context: context,
      barrierDismissible: false, // user must tap button for close dialog!
      builder: (BuildContext context) {
        return AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
          title: Text(
            'Do you really want to delete this $deleteItem?',
            style: cardTextStyle,
          ),
          actions: <Widget>[
            FlatButton(
              child: Text('NO', style: cardTextStyle),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            FlatButton(
                child: Text('YES', style: cardTextStyle),
                onPressed: () {
                  _deleteconfirm = true;
                  Navigator.of(context).pop();
                })
          ],
        );
      },
    );

    return _deleteconfirm;
  }

  static List<BottomNavigationBarItem> bottomBarItems({int pos}
      // {onPopUpSelectedCallBack onPopupChange}
      ) {
    // print(pos);
    List<BottomNavigationBarItem> items = [];
    List<String> installerIcons = [
      Images.bottomImages.fleetOverView,
      Images.bottomImages.allPants,
      Images.bottomImages.noPronoComm,
      Images.bottomImages.ticketIssues,
      Images.bottomImages.menu,
    ];

    List<String> ownerIcons = [
      Images.bottomImages.allPants,
      Images.bottomImages.noPronoComm,
      Images.bottomImages.ticketIssues,
      Images.bottomImages.menu,
    ];

    if (USerProfile.role == Role.plantOwner) {
      for (var i in ownerIcons) {
        items.add(BottomNavigationBarItem(
            icon: Container(
              child: Opacity(
                child: Image.asset(
                  i,
                  width: 30,
                  height: 30,
                ),
                opacity: ownerIcons.indexOf(i) == pos ? 1.0 : 0.6,
              ),

              //     : PopupMenuButton(
              //   color: Colors.white,
              //   enabled: true,
              //   onSelected: (value) {
              //     onPopupChange(value);
              //   },
              //
              //   elevation: 8,
              //   child: Container(
              //     // margin: EdgeInsets.only(left: 10),
              //       child: Image.asset(i,
              //           height: 30,
              //           width: 30,
              //           alignment: Alignment.bottomCenter)),
              //   shape: RoundedRectangleBorder(
              //       borderRadius: BorderRadius.circular(40.0)),
              //   offset: Offset(70, 0),
              //   // padding: EdgeInsets.only(left: 500),
              //
              //   itemBuilder: (context) => [
              //     PopupMenuItem(
              //       value: 0,
              //       child: Center(
              //         child: Image.asset(
              //           ownerIcons[1],
              //           height: 30,
              //           width: 30,
              //         ),
              //       ),
              //     ),
              //     PopupMenuItem(
              //       value: 1,
              //       child: Center(
              //         child: Image.asset(
              //           ownerIcons[2],
              //           height: 30,
              //           width: 30,
              //         ),
              //       ),
              //     ),
              //   ],
              // ),
            ),
            // ignore: deprecated_member_use
            title: Text("")));
      }
    } else
      for (var i in installerIcons) {
        items.add(BottomNavigationBarItem(
            icon: Container(
                child: Opacity(
              opacity: installerIcons.indexOf(i) == pos ? 1.0 : 0.6,
              child: Image.asset(
                i,
                width: 30,
                height: 30,
              ),
            ))
            // : PopupMenuButton(
            //     color: Colors.white,
            //     enabled: true,
            //     onSelected: (value) {
            //       onPopupChange(value);
            //
            //
            //     },
            //
            //     elevation: 8,
            //     child: Container(
            //         // margin: EdgeInsets.only(left: 10),
            //         child: Image.asset(i,
            //             height: 30,
            //             width: 30,
            //             alignment: Alignment.bottomCenter)),
            //     shape: RoundedRectangleBorder(
            //         borderRadius: BorderRadius.circular(40.0)),
            //     offset: Offset(70, 0),
            //     // padding: EdgeInsets.only(left: 500),
            //
            //     itemBuilder: (context) => [
            //       PopupMenuItem(
            //         value: 0,
            //         child: Center(
            //           child: Image.asset(
            //             installerIcons[2],
            //             height: 30,
            //             width: 30,
            //           ),
            //         ),
            //       ),
            //       PopupMenuItem(
            //         value: 1,
            //         child: Center(
            //           child: Image.asset(
            //             installerIcons[3],
            //             height: 30,
            //             width: 30,
            //           ),
            //         ),
            //       ),
            //     ],
            //   ),

            // ignore: deprecated_member_use
            ,
            // ignore: deprecated_member_use
            title: Text("")));
      }

    return items;
  }

  static String notNullText(String _textString) =>
      _textString == "null" ? "N.A" : _textString;

  static String roleToText(Role role) =>
      role == Role.Installer ? "Installer" : "Plant Owner";

  static Role textTORole(String role) =>
      role == "Installer" ? Role.Installer : Role.plantOwner;

  static Color statusColor(PlantStatus status) {
    switch (status) {
      case PlantStatus.online:
        return Services.colors.graffColor;

      case PlantStatus.noCommunication:
        return Colors.orange;

      case PlantStatus.noProduction:
        return Colors.red;

      default:
        return Colors.grey;
    }
  }
}

class Point {
  String x;
  String y;

  Point(x, y) {
    this.x = x;

    this.y = y != "null" ? y : "0";
  }
}

class Graph {
  final int year;
  final double quantity;

  Graph(this.year, this.quantity);
}

enum PlantStatus { online, noProduction, noCommunication, idle }
enum Role { plantOwner, Installer }

RegExp reg = new RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))');
Function mathFunc = (Match match) => '${match[1]},';

class SomeFixedUi {
  static Widget appBarLogo() => Container(
        margin: EdgeInsets.only(top: 10, bottom: 10, right: 5),
        child: ClipRRect(
            borderRadius: BorderRadius.circular(8.0),
            child: Image.asset(
              "assets/logo.png",
              fit: BoxFit.fill,
              width: 100,
            )),
      );

  //TextField

  static Widget field(String _title, TextEditingController _controller,
          {bool isNumber = false,
          bool decimal = false,
          bool password = false,
          bool email = false,
          bool readOnly = false}) =>
      Container(
        margin: EdgeInsets.only(top: 15),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            _title,
            style: Services.fieldLabel,
          ),
          Container(
            height: 40,
            padding: EdgeInsets.only(top: 5),
            child: TextFormField(
              readOnly: readOnly,
              controller: _controller,
              inputFormatters: [
                if (decimal)
                  FilteringTextInputFormatter.allow(RegExp('[0-9.,]'))
                else if (isNumber)
                  // ignore: deprecated_member_use
                  WhitelistingTextInputFormatter.digitsOnly,
                if (password)

                  // ignore: deprecated_member_use
                  WhitelistingTextInputFormatter(RegExp("[a-zA-Z0-9@*]")),
              ],
              keyboardType: isNumber
                  ?
              (decimal?
              TextInputType.numberWithOptions(decimal: true)
                  :
              TextInputType.number
            )


                  : email
                      ? TextInputType.emailAddress
                      : null,
              decoration: new InputDecoration(
                contentPadding: EdgeInsets.only(top: 5, left: 10),
                focusedBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Services.colors.textColor, width: 1),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide:
                      BorderSide(color: Services.colors.textColor, width: 1.0),
                ),
                hintText: 'Enter the ' + _title,
              ),
              // onChanged: (val)=>onSaved(val),
            ),
          ),
        ]),
      );

  //Save button

  static Widget button(String title, Function onPressed, {double fontSize}) =>
      Container(
          margin: EdgeInsets.only(top: 15),
          height: 45,
          width: 140,
          child: RaisedButton(
            textColor: Colors.white,
            color: Services.colors.appBarColor,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
            child: Text(title,
                style:
                    TextStyle(fontSize: fontSize ?? 20, color: Colors.white)),
            onPressed: onPressed,
          ));

  static Widget searchUi({onChangedCallBack onSearchTextChange}) {
    return TextField(
        decoration: new InputDecoration(
          border: new OutlineInputBorder(
            borderRadius: const BorderRadius.all(
              const Radius.circular(40.0),
            ),
          ),
          filled: true,
          contentPadding: EdgeInsets.only(top: 2, left: 15),
          hintStyle: new TextStyle(color: Services.colors.textColor),
          hintText: "search",
          fillColor: Colors.white70,
        ),
        onChanged: (searchTexts) => onSearchTextChange(searchTexts));
  }

  static Widget loader(String text) => Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
              height: 40,
              width: 40,
              child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                      Services.colors.appBarColor))),
          Container(
            height: 10,
          ),
          Text(text,
              style: TextStyle(
                color: Services.colors.textColor,
                fontSize: 18,
              ))
        ],
      );

  static Future showAlert(BuildContext _context, String message) async {
    return showDialog(
        context: _context,
        useSafeArea: true,
        barrierDismissible: false,
        builder: (BuildContext _context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(25))),
            title: Text(
              '$message',
              textAlign: TextAlign.center,
            ),
            titleTextStyle: Services.cardTextStyle,
            titlePadding: EdgeInsets.only(top: 30, left: 15, right: 10),
            content: Padding(
                padding: EdgeInsets.symmetric(horizontal: 65),
                child: SomeFixedUi.button("OK", () {
                  Navigator.pop(_context);
                })),
          );
        });
  }
}

// ignore: must_be_immutable
class Dropdown extends StatefulWidget {
  String hint, displayText;

  List items;
  int selectedValueIndex;
  onItemSelectedCallBack onSelected;

  Dropdown(
      {this.hint,
      this.items,
      this.onSelected,
      this.selectedValueIndex,
      this.displayText});

  @override
  _DropdownState createState() => _DropdownState();
}

class _DropdownState extends State<Dropdown> {
  Map _item;

  @override
  void initState() {
    if (widget.selectedValueIndex != null)
      _item = widget.items[widget.selectedValueIndex];

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        width: double.infinity,
        height: 35.0,
        margin: const EdgeInsets.only(
          top: 5.0,
        ),
        decoration: new BoxDecoration(
          color: Colors.white,
          border: new Border.all(color: Services.colors.textColor, width: 1.0),
          borderRadius: new BorderRadius.circular(10.0),
        ),
        //child: new Center(
        child: DropdownButtonHideUnderline(
          child: ButtonTheme(
            alignedDropdown: true,
            child: new DropdownButton<Map<String, dynamic>>(
                hint: new Text(widget.hint,
                    style: new TextStyle(
                        fontFamily: 'Montserrat',
                        color: Services.colors.textColor,
                        fontWeight: FontWeight.normal),
                    textAlign: TextAlign.center),
                items: widget.items.isNotEmpty
                    ? widget.items.map((item) {
                        return new DropdownMenuItem<Map<String, dynamic>>(
                          child: new Text(
                            widget.displayText != null
                                ? item[widget.displayText]
                                : item["text"],
                            overflow: TextOverflow.ellipsis,
                            style: new TextStyle(
                                fontFamily: 'Montserrat',
                                color: Services.colors.textColor,
                                fontWeight: FontWeight.normal),
                          ),
                          value: item,
                        );
                      }).toList()
                    : null,
                onChanged: (newVal) {
                  print(newVal);
                  widget.onSelected(newVal);

                  setState(() {
                    _item = newVal;
                  });
                },
                value: _item ?? null),
          ),
        ));
  }
}
