import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/notifications.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';

import 'constants.dart';



Future onSelectNotification(String payload) {
  debugPrint("payload : $payload");
  return null;
}

void callbackDispatcher() {

  Workmanager.executeTask((task, inputData) async {


    await showNotification();

    return true;
  });
}

Future showNotification() async {

  List<NotificationData> notifications = [];

  SharedPreferences sp = await SharedPreferences.getInstance();




  // print(sp.getStringList("plantIds").toString() + "ids");

  String url1 = Urls.ip + Urls.apiFolder + "fc=notification&plants=";
  String plantIds = "";

  for (String id in sp.getStringList("plantIds")) {
    plantIds += id;
    if (sp.getStringList("plantIds").indexOf(id) !=
        sp.getStringList("plantIds").length - 1) plantIds += ",";
  }

  url1 += plantIds;

  List response = await NetworkHelper.getServerData(url1);

  print("response in background: $response");

  print(response.runtimeType);
  response.forEach((element) async {
    print(element["lastDayEnergy"]);
    if (element["lastCommunicated"] != null)
    notifications.add(
        NotificationData.fromJson(element));

  });



  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin= new FlutterLocalNotificationsPlugin();
  var _android = new AndroidInitializationSettings('ic_launcher');
  var _iOS = new IOSInitializationSettings();
  var initSettings = new InitializationSettings(android: _android, iOS: _iOS);
  flutterLocalNotificationsPlugin.initialize(initSettings,
      onSelectNotification: onSelectNotification);

  var android = new AndroidNotificationDetails(
      'channel id', 'channel NAME', 'CHANNEL DESCRIPTION',
      priority: Priority.high, importance: Importance.max,
icon:'ic_launcher',
      showWhen: false,
      enableVibration: true,
      styleInformation: BigTextStyleInformation('')






  );





































  var iOS = new IOSNotificationDetails();
  var platform = new NotificationDetails(android: android, iOS: iOS);

  notifications.forEach((element) async {
    await flutterLocalNotificationsPlugin.show(int.parse(element.id),
        element.title, element.message, platform);
  });

  return Future.value(true);
}
