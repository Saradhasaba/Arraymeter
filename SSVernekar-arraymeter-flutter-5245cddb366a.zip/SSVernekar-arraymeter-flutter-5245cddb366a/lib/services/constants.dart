import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';

String msgDocs = "msgDocs";

class ColorBase {
  Color textColor = Color(0xff045544);
  Color graffColor = Color(0xff55dd55);
  Color appBarColor = Color(0xff045544);
  Color scaffoldColor = Color(0xffe0fff2);
  Color tableHeighlight = Color(0xffeafff9);
  Color tableOddColor = Colors.grey.shade300;
}

class Texts {
  // cards data

  String today = "Today,29-Friday";
  String todayEnergy = '96.15 kWh';
  String month = 'Month,September';
  String monthEnergy = '2723.15';
  String year = 'Year,2020';
  String yearEnergy = '32.15 kWh';

//  String lifeTime='Lifetime';
  String lifeTimeEnergy = '52.15 MWh';

//  String lifeTimeRevenueText='Lifetime,Revenue';
  String lifeTimeRevenueValue = '107,30.50\$';

//  String capacityText='Plant Capacity';
  String capacityValue = '500 kWh';

  //table data
  String lastCommunicationDate = "2020-09-27,23-30";
  String plantName = 'XYZ';
  String meterNo;
  String installerName = "Steve";
  String plantAdress = "XYZ,ABC";
  String state = 'NY';
  String plantStartDate = "22-09-2019";
  String projectId = "325436532";
  String city = "Chicago";
  String zipCode = "1234";

  //texts

  static String capacity = "Plant Size";
}

class Images {
  static BottomImages _bottomImages = BottomImages();

  static FleetOverViewImages _fleetOverViewImages = FleetOverViewImages();
  static FleetSummaryImages _fleetSummaryImages = FleetSummaryImages();

  static BottomImages get bottomImages => _bottomImages;

  static FleetOverViewImages get fleetOverViewImages => _fleetOverViewImages;

  static FleetSummaryImages get fleetSummaryImages => _fleetSummaryImages;
  static String filterImage = "assets/plant-filter.png";
  static String hourInterval = "assets/interval-1hr.png";
  static String minInterval = "assets/interval-15m.png";
  static String edit = "assets/edit.png";
  static String delete = "assets/delete.png";
}

class BottomImages {
  String fleetOverView = "assets/Fleet-overview.png";
  String allPants = "assets/All-plants.png";
  String noProduction = "assets/no-production1.png";
  String noCommunication = "assets/no-communication1.png";
  String tickets = "assets/tickets.png";
  String menu = "assets/Menu.png";
  String noPronoComm = "assets/no-production-communication.png";
  String ticketIssues = "assets/Issues.png";
}

class FleetOverViewImages {
  String totalPlants = "assets/Overview-all-plants.png";
  String estimateLoss = "assets/Overview-losses.png";
  String noCommunication = "assets/Overview-no-communication.png";
  String noProduction = "assets/Overview-no-production.png";
  String online = "assets/Overview-online.png";
  String inverterBreak = "assets/invertor-breakdown.png";
  String others = "assets/others-tickets.png";
}

class FleetSummaryImages {
  String totalKW = "assets/summary-energy-capacity.png";
  String todayProduction = "assets/summary-daily-energy.png";
  String monthlyProduction = "assets/summary-monthly-energy.png";
  String yearlyProduction = "assets/summary-yearly-energy.png";
  String lifeTimeProduction = "assets/summary-lifetime-energy.png";
}

class Urls {
  static String ip = "http://arraymeter.com/usaportal/production/";
  // static String localIp = "http://192.168.1.12/usaportal/production/";
  static String localIp = ip;

  static String apiFolder = "api_4g_meter_v2.php?";
  static String apiDataPhp = "api_data.php?"; //"meter_details.php
  static String ticketFile = "ticketing.php?";

  static String getTicketCat = localIp + ticketFile + "fc=ticket_category";
  static String getTicketStatus = localIp + ticketFile + "fc=ticket_status";
  static String addTicket = localIp + ticketFile + "fc=add_ticket";
  static String getTickets = localIp + ticketFile + "fc=get_ticket";
  static String getTicketCount = localIp + ticketFile + "fc=get_ticketCount";
  static String deleteTicket = localIp + ticketFile + "fc=delete_ticket";

  static String getMessages = localIp + ticketFile + "fc=get_message";
  static String addMessage = localIp + ticketFile + "fc=addMessage";
  static String deleteMessage = localIp + ticketFile + "fc=delete_message";
  static String forgotPassword = ip + "forgot_password.php";
}

class USerProfile {
  static String name, id, email, orgId;
  static Role role;
  static bool management, ticketManagement;
}
