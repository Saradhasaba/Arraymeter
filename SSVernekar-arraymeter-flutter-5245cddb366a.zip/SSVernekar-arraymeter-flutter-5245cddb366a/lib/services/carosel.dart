import 'package:arraymeter/screens/ticketing/imageView.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

List<String> imgList = [];

class CarouselWithIndicatorDemo extends StatefulWidget {

  CarouselWithIndicatorDemo({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return CarouselWithIndicatorState();
  }
}

class CarouselWithIndicatorState extends State<CarouselWithIndicatorDemo> {
  int _current = 0;

  List<Widget> imageSliders(BuildContext _context) {
    return imgList
        .map((item) => Container(
                child: Container(
              margin: EdgeInsets.all(5.0),
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                      _context,
                      MaterialPageRoute(
                          builder: (context) =>
                              ImageView(item, imageUrlList: imgList)));
                },
                child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(5.0)),
                    child: Stack(
                      children: <Widget>[
                        Image.network(item, fit: BoxFit.cover, width: 1000.0),
                        // Positioned(
                        //   bottom: 0.0,
                        //   left: 0.0,
                        //   right: 0.0,
                        //   child: Container(
                        //     // decoration: BoxDecoration(
                        //     //   gradient: LinearGradient(
                        //     //     colors: [
                        //     //       Color.fromARGB(200, 0, 0, 0),
                        //     //       Color.fromARGB(0, 0, 0, 0)
                        //     //     ],
                        //     //     begin: Alignment.bottomCenter,
                        //     //     end: Alignment.topCenter,
                        //     //   ),
                        //     // ),
                        //     padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
                        //     child: Text(
                        //       'No. ${imgList.indexOf(item)} image',
                        //       style: TextStyle(
                        //         color: Colors.white,
                        //         fontSize: 20.0,
                        //         fontWeight: FontWeight.bold,
                        //       ),
                        //     ),
                        //   ),
                        // ),
                      ],
                    )),
              ),
            )))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      CarouselSlider(
        items: imageSliders(context),
        options: CarouselOptions(
            autoPlay: false,
            reverse: false,
            enlargeCenterPage: true,
            aspectRatio: 2.0,
            viewportFraction: 1,
            onPageChanged: (index, reason) {
              setState(() {
                _current = index;
              });
            }),
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: imgList.map((url) {
          int index = imgList.indexOf(url);
          return Container(
            width: 8.0,
            height: 8.0,
            margin: EdgeInsets.only(top: 10.0, right: 2.0, left: 2),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _current == index
                  ? Color.fromRGBO(0, 0, 0, 0.9)
                  : Color.fromRGBO(0, 0, 0, 0.4),
            ),
          );
        }).toList(),
      ),
    ]);
  }
}
