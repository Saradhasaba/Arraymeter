import 'package:arraymeter/models/PlantModel.dart';

import 'package:arraymeter/screens/main/installerPants.dart';

import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';

import 'addUpdateplant.dart';

// ignore: must_be_immutable
class PlantListToManage extends StatefulWidget {
  List plants;
  final void Function(PlantModel plant) addNewPlant;
  final void Function(PlantModel plant) editPlant;
  final void Function(String index) deletePlant;

  PlantListToManage(this.plants,
      {this.addNewPlant, this.editPlant, this.deletePlant});

  @override
  _PlantListToManageState createState() => _PlantListToManageState();
}

class _PlantListToManageState extends State<PlantListToManage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // resizeToAvoidBottomPadding: false,
      backgroundColor: Services.colors.scaffoldColor,
      // appBar: AppBar(
      //     title: Text("Plant Management"), actions: [SomeFixedUi.appBarLogo()]),
      body: Stack(
        children: [
          InstallerPlantsView(
            plantList: widget.plants,
            editPlant: widget.editPlant,
            deletePlant: widget.deletePlant,
            title: "Plant Management",
            manageAble: true,
          ),
          // Align(
          //     alignment: Alignment.bottomCenter,
          //     child: BottomNavigationBar(
          //         elevation: 0,
          //         showSelectedLabels: false,
          //         showUnselectedLabels: true,
          //         items: Services.bottomBarItems(onPopupChange:(value){
          //           print("popup:$value");
          //         }),
          //         onTap: (indexValue) {})),
          Positioned(
            bottom: Services.getHieght(context) * 0.12,
            right: 10,
            child: FloatingActionButton(
              backgroundColor: Services.colors.appBarColor,
              onPressed: () async {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => AddOrUpdatePlant(
                              addNewPlant: widget.addNewPlant,
                            )));
              },
              child: Icon(Icons.add),
            ),
          )
        ],
      ),
    );
  }
}
