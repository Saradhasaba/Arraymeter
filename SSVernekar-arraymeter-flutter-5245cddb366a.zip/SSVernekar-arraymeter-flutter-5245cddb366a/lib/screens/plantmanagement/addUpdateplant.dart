import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class AddOrUpdatePlant extends StatefulWidget {
  PlantModel plant;
  final void Function(PlantModel plant) addNewPlant;
  final void Function(PlantModel plant) editPlant;

  AddOrUpdatePlant({this.plant, this.editPlant, this.addNewPlant});

  @override
  _AddOrUpdatePlantState createState() => _AddOrUpdatePlantState();
}

class _AddOrUpdatePlantState extends State<AddOrUpdatePlant> {
  bool _update = false;

  TextEditingController _plantId = TextEditingController();

  TextEditingController _plantName = TextEditingController();

  TextEditingController _pantCapacity = TextEditingController();

  TextEditingController _plantAdress = TextEditingController();

  TextEditingController _city = TextEditingController();

  TextEditingController _zipCode = TextEditingController();

  TextEditingController _triff = TextEditingController();
  String _state;

  List _allStates = [];

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  _initialization() async {
    if (widget.plant != null) {
      _plantId.text = widget.plant.id;
      _plantName.text = widget.plant.name;
      _pantCapacity.text = widget.plant.capacity.toString();
      _plantAdress.text = widget.plant.address;
      _city.text = widget.plant.city;
      _zipCode.text = widget.plant.zipCode;
      _city.text = widget.plant.city;
      _triff.text = widget.plant.feed;
      _state = widget.plant.state;

      _update = true;
    }

    String url = Urls.ip + Urls.apiFolder + "fc=getStates";
    _allStates = await NetworkHelper.getServerData(url);

    // print(_allStates);
    setState(() {});
  }

  bool isValidate() {
    if (_plantId.text.trim().isNotEmpty &&
        _plantName.text.trim().isNotEmpty &&
        _pantCapacity.text.trim().isNotEmpty &&
        _plantAdress.text.isNotEmpty &&
        _city.text.trim().isNotEmpty &&
        _zipCode.text.trim().isNotEmpty &&
        _triff.text.trim().isNotEmpty &&
        _state != null) {

      if(_zipCode.text.length==5)

      return true;
      // ignore: deprecated_member_use
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            'Zip Code must have 5 digits',
            style: TextStyle(color: Colors.red),
          )));

    } else
      // ignore: deprecated_member_use
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            'Please Enter all the fields',
            style: TextStyle(color: Colors.red),
          )));

    return false;
  }

  _addNew() async {
    String url = Urls.ip +
        Urls.apiFolder +
        "fc=addPlant&plantId=" +
        _plantId.text +
        "&name=" +
        _plantName.text +
        "&capacity=" +
        _pantCapacity.text +
        "&plantAddress=" +
        _plantAdress.text +
        "&city=" +
        _city.text +
        "&state=" +
        _state +
        "&zipcode=" +
        _zipCode.text +
        "&orgId=" +
        USerProfile.orgId +
        "&feed=" +
        _triff.text;

    var response = await NetworkHelper.getServerData(url);
    if (response != 409) {
      widget.addNewPlant(widget.plant);
   Navigator.of(context).pop(widget.plant);
    } else
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            'Plant is already exists',
            style: TextStyle(color: Colors.red),
          )));
  }

  _updatePlant() async {
    String url = Urls.ip +
        Urls.apiFolder +
        "fc=updatePlant&plantId=" +
        _plantId.text +
        "&name=" +
        _plantName.text +
        "&capacity=" +
        _pantCapacity.text +
        "&plantAddress=" +
        _plantAdress.text +
        "&city=" +
        _city.text +
        "&state=" +
        _state +
        "&zipcode=" +
        _zipCode.text +
        "&feed=" +
        _triff.text;

     await NetworkHelper.getServerData(url);

    widget.editPlant(widget.plant);
    Navigator.of(context).pop(widget.plant);
  }

  @override
  void initState() {
    _initialization();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
          centerTitle: true,
          actions: [SomeFixedUi.appBarLogo()],
          title: Column(
            children: [
              Text(
                "ARRAYMETER",
                style: TextStyle(fontSize: 16),
              ),
              // Text("Plant-DashBoard", style: TextStyle(fontSize: 16))
            ],
          )),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(10),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(
                child: Text(
          _update?"Edit Plant":"Add Plant",
              style: Services.screenHeadingTextStyle,
            )),
            SomeFixedUi.field("Serial Number", _plantId, isNumber: true,readOnly:_update),
            SomeFixedUi.field("Plant Name", _plantName),
            SomeFixedUi.field("${Texts.capacity} (kW)", _pantCapacity, isNumber: true,decimal: true),
            SomeFixedUi.field("Plant Address", _plantAdress),
            SomeFixedUi.field("City", _city),
            Container(height: 15.0),
            Text("State", style: Services.fieldLabel),
            Dropdown(
                hint: _update?widget.plant.state:"Select State",
                items: _allStates,
                displayText: "stateName",

                 onSelected: (Map val) {
                  _state = val['stateName'];
                }),
            SomeFixedUi.field("Zip Code", _zipCode, isNumber: true),
            SomeFixedUi.field("Electricity Cost (\$/kWh)", _triff, isNumber: true,decimal: true),
            Center(
                child:
                    SomeFixedUi.button(_update ? "Update" : "Save", () async {
              var connectivityResult =
                  await (Connectivity().checkConnectivity());

              if (connectivityResult == ConnectivityResult.mobile ||
                  connectivityResult == ConnectivityResult.wifi) {
                if (isValidate()) {
                  if (widget.plant == null) widget.plant = PlantModel();
                  widget.plant.id = _plantId.text;
                  widget.plant.name = _plantName.text;
                  widget.plant.capacity = double.parse(_pantCapacity.text);
                  widget.plant.address = _plantAdress.text;
                  widget.plant.city = _city.text;
                  widget.plant.zipCode = _zipCode.text;
                  widget.plant.state = _state;
                  widget.plant.feed = _triff.text;

                  !_update
                      ?
                      //add new
                      _addNew()
                      :

                      //update

                      _updatePlant();
                }
              } else
                _scaffoldKey.currentState.showSnackBar(new SnackBar(
                    content:
                        new Text('Please check your internet connection')));
            }))
          ]),
        ),
      ),
    );
  }
}
