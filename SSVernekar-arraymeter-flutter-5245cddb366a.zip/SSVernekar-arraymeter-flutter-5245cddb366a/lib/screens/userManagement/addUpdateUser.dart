import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/models/UserModel.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/multiSelection/multiSelectFormField.dart';
import 'package:arraymeter/services/service.dart';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class AddOrUpdateUser extends StatefulWidget {
  User user;

  //to update in userList
  int index;

  List<PlantModel> _allPlants = [];

  final void Function(User user) addUser;
  final void Function(int index, User user) editUser;

  AddOrUpdateUser(this._allPlants,
      {this.user, this.editUser, this.addUser, this.index});

  @override
  _AddOrUpdateUserState createState() => _AddOrUpdateUserState();
}

class _AddOrUpdateUserState extends State<AddOrUpdateUser> {
  bool _update = false;
  bool authorityPlus = false;

  TextEditingController _name = TextEditingController();

  TextEditingController _email = TextEditingController();

  TextEditingController _password = TextEditingController();

  TextEditingController _cpasword = TextEditingController();

  TextEditingController _phone = TextEditingController();
  List _selectedPlants = [];
  List _allPlants = [];
  Role _role;
  bool _management = false, //user Management and plant management
      ticketManagement = false;

  List _roleList = [
    {"text": "Installer", "id": 0},
    {"text": "Plant Owner", "id": 1}
  ];

  List _installManagement = [
    {"text": "Enable", "state": true},
    {"text": "Disable", "state": false}
  ];

  @override
  void initState() {
    initialization();

    super.initState();
  }

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    _cpasword.dispose();
    _phone.dispose();

    super.dispose();
  }

  void initialization() async {
    widget._allPlants.forEach((element) {
      _allPlants.add(
          {"display": "${element.id}-${element.name}", "value": element.id});
    });

    print(_allPlants);

    if (widget.user != null) {
      _email.text = widget.user.email;
      _name.text = widget.user.name;
      _password.text = widget.user.password;
      _cpasword.text = widget.user.password;
      _role = widget.user.role;

//plants must be same from the getPlants

      _phone.text = Services.phoneToNum(widget.user.phoneNumber);

      // _phone.text =widget.user.phoneNumber[1]+widget.user.phoneNumber[2]+widget.user.phoneNumber[3]+widget.user.phoneNumber[6]+widget.user.phoneNumber[7]+widget.user.phoneNumber[8]+widget.user.phoneNumber[10]+widget.user.phoneNumber[11]+widget.user.phoneNumber[12]+widget.user.phoneNumber[13];
// print(widget.user.phoneNumber[1]+widget.user.phoneNumber[2]+widget.user.phoneNumber[3]+widget.user.phoneNumber[6]+widget.user.phoneNumber[7]+widget.user.phoneNumber[8]+widget.user.phoneNumber[10]+widget.user.phoneNumber[11]+widget.user.phoneNumber[12]+widget.user.phoneNumber[13] );
      widget.user.plantIds.forEach((element) {
        _selectedPlants.add(element);
      });

      _management = widget.user.management;
      ticketManagement = widget.user.ticketManagement;

      _update = true;
    }

    setState(() {});
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  bool isValidate() {
    if (_name.text.trim().isNotEmpty &&
        _email.text.trim().isNotEmpty &&
        _password.text.trim().isNotEmpty &&
        _cpasword.text.trim().isNotEmpty &&
        _phone.text.trim().isNotEmpty &&
        _role != null) {
      if (_password.text.length >= 6) {
        if (_password.text == _cpasword.text) {
          if (_email.text.contains(".") && _email.text.contains("@")) {
            if (_phone.text.length == 10) {
              // _phone.text ="(${_phone.text[0]}${_phone.text[1]}${_phone.text[2]}) ${_phone.text[3]}${_phone.text[4]}${_phone.text[5]}-${_phone.text[6]}${_phone.text[7]}${_phone.text[8]}${_phone.text[9]}";
              _phone.text = Services.numberToPhone(_phone.text);
              // widget.user.phoneNumber = _phone.text;

              return true;
            } else if (_phone.text.length == 14) {
              return true;
            } else
              _scaffoldKey.currentState.showSnackBar(new SnackBar(
                  backgroundColor: Colors.white,
                  content: new Text(
                    "Mobile Number is not valid",
                    style: TextStyle(color: Colors.red),
                  )));
          } else {
            _scaffoldKey.currentState.showSnackBar(new SnackBar(
                backgroundColor: Colors.white,
                content: new Text(
                  "Email Address is not valid",
                  style: TextStyle(color: Colors.red),
                )));
          }
        } else {
          _scaffoldKey.currentState.showSnackBar(new SnackBar(
              backgroundColor: Colors.white,
              content: new Text(
                "Password doesn't match",
                style: TextStyle(color: Colors.red),
              )));

          return false;
        }
      } else {
        _scaffoldKey.currentState.showSnackBar(new SnackBar(
            backgroundColor: Colors.white,
            content: new Text(
              "Password must have at least 6 characters",
              style: TextStyle(color: Colors.red),
            )));

        return false;
      }
    } else
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            'Please Enter all the fields',
            style: TextStyle(color: Colors.red),
          )));

    return false;
  }

  String _plantsString() {
    String plants = "";

    if (_selectedPlants.isNotEmpty)
      _selectedPlants.forEach((element) {
        plants += element;

        if (_selectedPlants.indexOf(element) != _selectedPlants.length - 1)
          plants += ",";
      });
    else
      plants = "0";

    return plants;
  }

  String _roleToText(Role role) =>
      role == Role.Installer ? "Installer" : "PlantUser";

  _addNew() async {
    String installerId;
    // if(_role==Role.Installer)
    installerId = USerProfile.orgId;
    // else
    //   installerId= "999999";

    String url = Urls.ip +
        Urls.apiFolder +
        "fc=addUser&email=" +
        _email.text +
        "&installerId=" +
        installerId +
        "&password=" +
        _password.text +
        "&name=" +
        _name.text +
        "&phone=" +
        _phone.text +
        "&role=" +
        _roleToText(_role) +
        "&management=" +
        _management.toString() +
        "&ticket=" +
        ticketManagement.toString() +
        "&plants=" +
        _plantsString();

    String secondUrl =
        "http://git.pv-india.net/email_alert_arraymeter.php?wch=" +
            _email.text +
            "&dp=" +
            _password.text;

    var response = await NetworkHelper.getServerData(url);
    NetworkHelper.getServerData(secondUrl);

// in bellow line id must be from backend
    if (response != 409) {
      widget.user.id = response["lastInsertedId"];

      widget.addUser(widget.user);
      Navigator.pop(context);
    } else
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            'User is already exists',
            style: TextStyle(color: Colors.red),
          )));

    print(response);
  }

  _updateUser() async {
    String url = Urls.ip +
        Urls.apiFolder +
        "fc=updateUser&email=" +
        _email.text +
        "&userId=" +
        widget.user.id +
        "&password=" +
        _password.text +
        "&name=" +
        _name.text +
        "&phone=" +
        _phone.text +
        "&role=" +
        _roleToText(_role) +
        "&management=" +
        _management.toString() +
        "&ticket=" +
        ticketManagement.toString() +
        "&plants=" +
        _plantsString();

    String secondUrl =
        "http://git.pv-india.net/email_alert_arraymeter.php?wch=" +
            _email.text +
            "&dp=" +
            _password.text;

    await NetworkHelper.getServerData(url);

    // NetworkHelper.getServerData(secondUrl);

    widget.editUser(widget.index, widget.user);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
          centerTitle: true,
          actions: [SomeFixedUi.appBarLogo()],
          title: Column(
            children: [
              Text(
                "ARRAYMETER",
                style: TextStyle(fontSize: 16),
              ),
              // Text("Plant-DashBoard", style: TextStyle(fontSize: 16))
            ],
          )),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(10),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(
                child: Text(
              _update ? "Edit User" : "Add User",
              style: Services.cardTextStyle,
            )),
            SomeFixedUi.field(
              "Name",
              _name,
            ),
            SomeFixedUi.field("Email", _email, email: true),
            SomeFixedUi.field("Password", _password, password: true),
            SomeFixedUi.field("Confirm Password", _cpasword, password: true),
            SomeFixedUi.field("Phone", _phone, isNumber: true),
            Container(height: 15.0),

            widgetAccess(
              enable: !_update,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Select Role of User", style: Services.fieldLabel),
                  Dropdown(
                      selectedValueIndex:
                          _update ? (_role == Role.plantOwner ? 1 : 0) : null,
                      hint: "Select Role",
                      items: _roleList,
                      onSelected: (Map val) {
                        setState(() {
                          if (val["id"] == 0) {
                            _role = Role.Installer;
                            _selectedPlants.clear();
                          } else
                            _role = Role.plantOwner;
                        });
                        print(_role);
                      }),
                ],
              ),
            ),

            //   ),
            // ),
            Container(height: 10.0),
            if (_role == Role.Installer)
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text("Plant and User Management", style: Services.fieldLabel),
                Dropdown(
                  selectedValueIndex: _update ? (!_management ? 1 : 0) : null,
                  hint: "Select Type",
                  items: _installManagement,
                  onSelected: (Map val) {
                    _management = val["state"];
                    print("Management:" + _management.toString());
                  },
                ),
              ]),
            Container(height: 10.0),
            widgetAccess(
              enable: USerProfile.ticketManagement,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Ticket Management", style: Services.fieldLabel),
                    Dropdown(
                      selectedValueIndex:
                          _update ? (!ticketManagement ? 1 : 0) : null,
                      hint: "Select Type",
                      items: _installManagement,
                      onSelected: (Map val) {
                        ticketManagement = val["state"];
                        print("Management:" + _management.toString());
                      },
                    ),
                  ]),
            ),
            if (_role == Role.plantOwner)
              MultiSelectFormField(
                autovalidate: true,
                chipBackGroundColor: Services.colors.appBarColor,
                chipLabelStyle: TextStyle(fontFamily: Services.mont_regular),
                dialogTextStyle: TextStyle(
                    fontFamily: Services.mont_med,
                    color: Services.colors.textColor),
                checkBoxActiveColor: Services.colors.appBarColor,
                checkBoxCheckColor: Colors.green,
                dialogShapeBorder: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(12.0))),
                title: Text(
                  " ",
                ),
                dataSource: _allPlants,
                textField: 'display',
                valueField: 'value',
                okButtonLabel: 'OK',
                cancelButtonLabel: 'CANCEL',

                // hintWidget: Text('Please choose one or more'),
                initialValue: _selectedPlants,
                onSaved: (value) {
                  if (value == null) return;
                  setState(() {
                    _selectedPlants = value;
                  });
                },
              ),
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.center,
            //   children: [
            //     Checkbox(
            //         checkColor: Colors.white,
            //         activeColor: Colors.green[900],
            //         value: authorityPlus,
            //         onChanged: (state) {
            //           setState(() {
            //             authorityPlus = state;
            //           });
            //         }),
            //     Text(
            //       "Authorized for ArrayMeter Plus",
            //       style: Services.cardTextStyle,
            //     )
            //   ],
            // ),
            Center(
                child:
                    SomeFixedUi.button(_update ? "Update" : "Save", () async {
              var connectivityResult =
                  await (Connectivity().checkConnectivity());
              if (connectivityResult == ConnectivityResult.mobile ||
                  connectivityResult == ConnectivityResult.wifi) {
                if (isValidate()) {
                  if (widget.user == null) widget.user = User();
                  widget.user.email = _email.text;
                  widget.user.role = _role;
                  widget.user.phoneNumber = _phone.text;
                  widget.user.name = _name.text;
                  widget.user.plantIds = _selectedPlants;
                  widget.user.password = _cpasword.text;
                  widget.user.management = _management;
                  widget.user.ticketManagement = ticketManagement;

                  !_update
                      ?
                      //add new
                      _addNew()
                      :

                      //update

                      _updateUser();
                }
              } else
                _scaffoldKey.currentState.showSnackBar(new SnackBar(
                    content:
                        new Text('Please check your internet connection')));
            }))
          ]),
        ),
      ),
    );
  }

  Widget widgetAccess({bool enable, Widget child}) => Opacity(
        opacity: enable ? 1.0 : 0.5,
        child: AbsorbPointer(
          absorbing: !enable,
          child: child,
        ),
      );
}
