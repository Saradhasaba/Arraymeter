import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/models/UserModel.dart';
import 'package:arraymeter/screens/userManagement/addUpdateUser.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/marqueText.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

// ignore: must_be_immutable
class UserDetailsScreen extends StatefulWidget {
  User user;
  int index;
  List<PlantModel> _plantList = [];
  final void Function(int index) deleteUser;
  final void Function(int index, User newUser) editUser;

  UserDetailsScreen(this._plantList,
      {this.index, this.user, this.deleteUser, this.editUser});

  @override
  _UserDetailsScreenState createState() => _UserDetailsScreenState();
}

class _UserDetailsScreenState extends State<UserDetailsScreen> {
  final GlobalKey _textKey = GlobalKey();
  List<PlantModel> _selectedPlants = [];

  double _height;
  Size _size;
  double _width;

  Widget _menuRow(BuildContext _context, String _key, String value) {
    return Container(
      padding: EdgeInsets.only(bottom: 30),
      child: Row(
        children: [
          SizedBox(
              width: Services.getWidth(_context) * 0.19,
              child: Text(
                _key ?? "",
                style:
                    TextStyle(fontSize: 18, color: Services.colors.textColor),
              )),
          Text(":  "),
          Flexible(
            child: Container(
              child: Text(
                value ?? "",
                maxLines: 2,
                style:
                    TextStyle(fontSize: 17, color: Services.colors.textColor),
              ),
            ),
          )
        ],
      ),
    );
  }

  void _initialization() {
    print(widget.user.plantIds);

    for (var id in widget.user.plantIds) {
      List temp =
          widget._plantList.where((element) => element.id == id).toList();

      if (temp.isNotEmpty) {
        int index = widget._plantList.indexWhere((element) => element.id == id);

        _selectedPlants.add(widget._plantList[index]);
      }
    }
  }

  @override
  void initState() {
    _initialization();

    WidgetsBinding.instance.addPostFrameCallback((_) => getSizeAndPosition());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("ArrayMeter"),
        actions: [SomeFixedUi.appBarLogo()],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 10,
            ),
            Text(
              "User Details",
              style: TextStyle(fontSize: 18, color: Services.colors.textColor),
            ),
            Container(
              height: 10,
            ),
            Stack(
              children: [
                Container(
                    margin: EdgeInsets.symmetric(horizontal: 10),
                    height: Services.getHieght(context) * 0.5,
                    width: Services.getWidth(context),
                    // margin: EdgeInsets.only(top: 20,bottom: 10),

                    decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        border: Border.all(
                            width: 1, color: Services.colors.textColor)),
                    child: Container(
                      padding: EdgeInsets.only(
                          left: Services.getWidth(context) * 0.05,
                          top: Services.getHieght(context) * 0.13),
                      child: ListView(
                        children: [
                          _menuRow(context, "Name", widget.user.name),
                          _menuRow(context, "Email", widget.user.email),
                          _menuRow(context, "Phone", widget.user.phoneNumber),
                          _menuRow(context, "Role",
                              Services.roleToText(widget.user.role)),
                          // _menuRow(context, "Total plants", widget.user.plantIds.length.toString()),
                          // _menuRow(context, "Plant", "451231642"),
                        ],
                      ),
                    )),
                Positioned(
                    right: 20,
                    top: 10,
                    child: Row(
                      children: [
                        Container(
                          height: 55,
                          width: 55,
                          child: IconButton(
                            icon: Image.asset(Images.edit),
                            onPressed: () async {
                              await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => AddOrUpdateUser(
                                          widget._plantList,
                                          user: widget.user,
                                          editUser: widget.editUser,
                                          index: widget.index)));

                              Navigator.pop(context);
                            },
                          ),
                        ),
                        Container(
                          height: 55,
                          width: 55,
                          child: IconButton(
                            icon: Image.asset(Images.delete),
                            onPressed: () async {
                              bool isDeleted =
                                  await Services.deleteData(context, "User");

                              if (isDeleted) _deleteUser(context);
                            },
                          ),
                        ),
                      ],
                    ))
              ],
            ),
            widget.user.role == Role.plantOwner
                ? Container(
                    margin: EdgeInsets.only(top: 10),
                    width: Services.getWidth(context),
                    height: 40,
                    color: Colors.grey,
                    child: Center(
                      child: Text(
                        "Plant List",
                        style: TextStyle(
                            fontFamily: Services.mont_med,
                            color: Colors.white,
                            fontSize: 18),
                      ),
                    ),
                  )
                : Container(),
            widget.user.role == Role.plantOwner
                ? GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    children: gridItems(_selectedPlants, context))
                : Container()
          ],
        ),
      ),
    );
  }

  void _deleteUser(BuildContext context) {
    String url =
        Urls.ip + Urls.apiFolder + "fc=deleteUser&userId=" + widget.user.id;

    NetworkHelper.getServerData(url);

    widget.deleteUser(widget.index);
    Navigator.pop(context);
  }

  getSizeAndPosition() {
    RenderBox _cardBox = _textKey.currentContext.findRenderObject();
    _height = _cardBox.size.height;
    _width = _cardBox.size.width;
    // print("card height:${_cardBox.size.height}");
    setState(() {});
  }

  List<Widget> gridItems(List<PlantModel> _plantList, BuildContext context) {
    List<Widget> items = [];

    for (PlantModel p in _plantList) {
      items.add(InkWell(
        onTap: () {
          //
          // Navigator.push(
          //     context,
          //     MaterialPageRoute(
          //         builder: (context) => ArrayData(p, widget.manageAble,
          //             editPlant: widget.editPlant)));
        },
        child: Stack(
          key: _plantList.indexOf(p) == 0 ? _textKey : null,
          children: [
            Image.asset(
              "assets/listcard_background.png",
              fit: BoxFit.fill,
            ),
            Positioned(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      width: _width != null ? _width / 1.5 : 150,
                      child: MarqueeWidget(
                          child: Text(
                        p.name,
                        style: TextStyle(
                            fontFamily: Services.mont_med,
                            color: Services.colors.textColor,
                            fontSize: 16),
                      ))),
                  Text(
                      p.lastCommunication != null
                          ? DateFormat("MM-dd-yyyy").format(p.lastCommunication)
                          : "",
                      style: TextStyle(
                          fontFamily: Services.mont_regular,
                          color: Services.colors.textColor)),
                ],
              ),
              left: Services.getWidth(context) * 0.05,
              top: Services.getHieght(context) * 0.02,
            ),
            Positioned(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    width: Services.getWidth(context) * 0.27,
                    child: Text(
                      p.todayEnergy != null
                          ? p.todayEnergy.toStringAsFixed(1)
                          // .padLeft(6, '0')
                          : "",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontFamily: Services.digitalFont,
                          fontSize: 30,
                          color: Colors.white),
                    ),
                  ),
                  Text(" kWh",
                      style: TextStyle(
                          fontFamily: Services.mont_regular,
                          fontSize: _size > Services.minimumSize ? 15 : 13,
                          color: Colors.white))
                ],
              ),
              top: _height != null
                  ? MediaQuery.of(context).orientation == Orientation.landscape
                      ? _height / 1.4
                      : _height / 2.24
                  : 20,
              left: Services.getWidth(context) * 0.06,
            ),
            Positioned(
              child: Container(
                  child: CircleAvatar(
                      backgroundColor: Services.colors.textColor,
                      radius: 16,
                      child: CircleAvatar(
                          radius: 15,
                          backgroundColor:
                              Services.statusColor(p.plantStatus)))),
              top: MediaQuery.of(context).orientation == Orientation.landscape
                  ? Services.getWidth(context) * 0.02
                  : Services.getHieght(context) * 0.02,
              right: MediaQuery.of(context).orientation == Orientation.landscape
                  ? Services.getWidth(context) * 0.09
                  : Services.getWidth(context) * 0.03,
            ),
            Positioned(
              child: Text(
                p.id,
                style: TextStyle(
                  fontFamily: Services.mont_regular,
                  fontSize: 15,
                  color: Services.colors.textColor,
                ),
              ),
              bottom:
                  MediaQuery.of(context).orientation == Orientation.landscape
                      ? Services.getHieght(context) * 0.23
                      : Services.getHieght(context) * 0.05,
              left: Services.getWidth(context) * 0.05,
            ),
            Positioned(
              child: Column(
                children: [
                  Text(
                    "${p.capacity} kW",
                    style: TextStyle(
                        color: Services.colors.textColor,
                        fontFamily: Services.mont_regular,
                        fontSize: 12),
                  ),
                  Text("Capacity",
                      style: TextStyle(
                          color: Services.colors.textColor,
                          fontFamily: Services.mont_regular,
                          fontSize: 12))
                ],
              ),
              bottom:
                  MediaQuery.of(context).orientation == Orientation.landscape
                      ? Services.getHieght(context) * 0.2
                      : Services.getHieght(context) * 0.03,
              right: MediaQuery.of(context).orientation == Orientation.landscape
                  ? Services.getWidth(context) * 0.09
                  : Services.getWidth(context) * 0.03,
            ),
          ],
        ),
      ));
    }

    return items;
  }
}
