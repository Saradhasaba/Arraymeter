import 'package:arraymeter/NetworkModule/network.dart';

import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class EditProfile extends StatefulWidget {
  String name, email;

  EditProfile({this.name, this.email});

  @override
  _EditProfileState createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  String name = USerProfile.name;
  String email = USerProfile.email;
  TextEditingController _password = TextEditingController();

  TextEditingController _cpasword = TextEditingController();
  bool textFieldEnable = false;

  // String _title;

  TextStyle cardTextStyle = TextStyle(
      color: Services.colors.textColor,
      fontFamily: Services.mont_regular,
      fontSize: 18);

  Widget _row(key, value) {
    return Padding(
      padding: EdgeInsets.only(left: 20.0, bottom: 10),
      child: Row(children: [
        Container(
          width: 85,
          child: Text("$key", style: cardTextStyle),
        ),
        Text(":  "),
        Expanded(
          child: Text(
            value ?? "",
            style: cardTextStyle,
          ),
        )
      ]),
    );
  }

  @override
  void dispose() {
    _password.dispose();
    _cpasword.dispose();

    super.dispose();
  }

  bool _validation() {
    if (_password.text.length == 0 && _cpasword.text.length == 0) {
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            "Please Enter Password",
            style: TextStyle(color: Colors.red),
          )));

      return false;
    } else if (_password.text.length < 6) {
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            "Please Enter Minimum 6 Characters",
            style: TextStyle(color: Colors.red),
          )));

      return false;
    } else if (_password.text != _cpasword.text) {
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            "Password doesn't match",
            style: TextStyle(color: Colors.red),
          )));
      return false;
    } else
      return true;
  }

  Widget _textField(TextEditingController controller, String hint) => Container(
      height: 45,
      margin: EdgeInsets.all(10),
      child: TextFormField(
          controller: controller,
          initialValue: null,
          decoration: InputDecoration(
              contentPadding: EdgeInsets.only(top: 5, left: 10),
              hintText: hint,
              hintStyle: TextStyle(fontSize: 18),
              border: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.green, width: 2.0),
                  borderRadius: BorderRadius.circular(10)))));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        body: SingleChildScrollView(
            child: Center(
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
              Card(
                  margin: EdgeInsets.fromLTRB(10, 30, 10, 0),
                  shape: RoundedRectangleBorder(
                    side: BorderSide(color: Colors.green, width: 1.0),
                    borderRadius: BorderRadius.circular(40.0),
                  ),
                  color: Colors.white,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                padding: EdgeInsets.only(
                                    left: 30, top: 25, bottom: 15),
                                child: Text(
                                  'My Profile Details',
                                  style: cardTextStyle,
                                )),
                            Divider(
                              color: Colors.green,
                              thickness: 1,
                            ),
                            Container(
                                padding: EdgeInsets.only(
                                    left: 10, top: 15, bottom: 5),
                                child: _row("Name", name)),
                            Container(
                                padding: EdgeInsets.only(
                                    left: 10, top: 15, bottom: 5),
                                child: _row("Email", email)),
                          ],
                        ),
                        Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              textFieldEnable == false
                                  ? changePasswordWidget()
                                  : Column(
                                      children: [
                                        _textField(_password, "Enter Password"),
                                        _textField(
                                            _cpasword, "Re Enter Password"),
                                        SomeFixedUi.button('Save', () async {
                                          if (_validation()) {
                                            var response = await NetworkHelper
                                                .getServerData(Urls.ip +
                                                    Urls.apiFolder +
                                                    'fc=PasswordUpdate&UserId=' +
                                                    USerProfile.id +
                                                    '&password=' +
                                                    _password.text);
                                            print(response);
                                            setState(() {
                                              textFieldEnable = false;
                                            });
                                          }
                                        }),
                                        Container(
                                          height: 50,
                                        )
                                      ],
                                    )
                            ]),
                      ])),
              SizedBox(
                height: 70,
              )
            ]))));
  }

  Widget changePasswordWidget() => Container(
      width: 225,
      height: 45,
      color: Colors.white70,
      margin: EdgeInsets.all(20),
      child: RaisedButton(
        disabledColor: Colors.white,

        // focusColor: Colors.white70,
        onPressed: () {
          setState(() {
            textFieldEnable = true;
          });
        },
        shape: RoundedRectangleBorder(
          side: BorderSide(color: Colors.green, width: 2.0),
          borderRadius: BorderRadius.circular(10.0),
        ),
        color: Colors.white70,
        child: Text(
          'Change Password',
          style: TextStyle(color: Colors.green, fontSize: 18),
        ),
      ));
}
