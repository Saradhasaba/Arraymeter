import 'dart:async';

import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/models/UserModel.dart';
import 'package:arraymeter/screens/userManagement/userDetails.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';

import 'addUpdateUser.dart';

// ignore: must_be_immutable
class UserList extends StatefulWidget {
  List<PlantModel> plantList = [];

  UserList(this.plantList);

  @override
  UserListState createState() => UserListState();
}

class UserListState extends State<UserList> {
  List<User> _mainUsers = [];

  List<User> _userList = [];

  bool _loading = true;
  Size _size;

  gettingUSerData() async {
    String url = Urls.ip +
        Urls.apiFolder +
        "fc=getUsers&installerId=" +
        USerProfile.orgId;

    var data = await NetworkHelper.getServerData(url);

    List users = data['users'] ?? [];

    for (var user in users) {
      _mainUsers.add(User.fromJson(user));
    }

    _userList = _mainUsers;
    _loading = false;
    setState(() {});
  }

  _deleteUser(int index) {
    _mainUsers.remove(_userList[index]);
    // _userList.removeAt(index);//(Unknown Bug)
    _userList = _mainUsers;
    setState(() {});
  }

  _editUser(int index, User newUser) {
    _userList[index] = newUser;

    _mainUsers[_mainUsers.indexOf(_userList[index])] = newUser;

    setState(() {});
  }

  _addUser(User newUser) {
    // _userList.add(newUser);Error: In UserList Two Time User detail are shown(Unknown Bug)
    _mainUsers.add(newUser);
    _userList = _mainUsers;
    setState(() {});
  }

  @override
  void initState() {
    gettingUSerData();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
        // resizeToAvoidBottomPadding: false,
        backgroundColor: Services.colors.scaffoldColor,
        body: !_loading
            ? Stack(
                children: [
                  Column(
                    children: [
                      Container(height: 8),
                      Text(
                        "User Management",
                        style: Services.screenHeadingTextStyle,
                      ),
                      Container(height: 5),
                      Container(
                          width: Services.getWidth(context),
                          margin: EdgeInsets.symmetric(horizontal: 20),
                          height: 40,

                          // decoration:  BoxDecoration(
                          //     color: Colors.white,
                          //     shape: BoxShape.rectangle,
                          //     borderRadius: BorderRadius.all(
                          //         Radius.circular(40.0)
                          //
                          //
                          //
                          //
                          //
                          //
                          //
                          //
                          //     ),border: Border.all(width: 1,color: Services.colors.textColor)),

                          child: SomeFixedUi.searchUi(
                              onSearchTextChange: (searchText) {
                            Timer(Duration(milliseconds: 100), () {
                              setState(() {
                                _userList = _mainUsers
                                    .where((element) => (element.name
                                            .toLowerCase()
                                            .contains(
                                                searchText.toLowerCase()) ||
                                        element.email
                                            .toString()
                                            .toLowerCase()
                                            .contains(
                                                searchText.toLowerCase()) ||
                                        Services.phoneToNum(element.phoneNumber)
                                            .toString()
                                            .contains(
                                                searchText.toLowerCase())))
                                    .toList();
                              });
                            });
                          })),
                      Container(height: 10),
                      Container(
                        margin: EdgeInsets.symmetric(horizontal: 10),
                        color: Colors.white,
                        child: Container(
                            height: 40,
                            decoration: Services.boxDecoration,
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                      padding: EdgeInsets.only(left: 10),
                                      width: Services.getWidth(context) * 0.6,
                                      child: Text(
                                        "E-mail",
                                        style: TextStyle(
                                            fontFamily: Services.mont_med,
                                            fontWeight: FontWeight.bold),
                                      )),
                                  // Container(
                                  //   height: 40,
                                  //   width: 1,
                                  //   color: Services.colors.textColor,
                                  // ),
                                  Container(
                                      padding: EdgeInsets.only(left: 10),
                                      child: Text("Role",
                                          style: TextStyle(
                                              fontFamily: Services.mont_med,
                                              fontWeight: FontWeight.bold)))
                                ])),
                      ),
                      // Container(
                      //     margin: EdgeInsets.symmetric(horizontal: 10),
                      //     height: _size >= Size(432.0, 816.0)
                      //         ? Services.getHieght(context) * 0.6
                      //         : (_size > Services.minimumSize
                      //             ? Services.getHieght(context) * 0.6
                      //             : Services.getHieght(context) * 0.54),
                      //     child:
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 10),
                          padding: EdgeInsets.only(bottom: 75),
                          child: ListView.builder(
                              itemCount: _userList.length,
                              itemBuilder: (BuildContext context, index) {
                                return InkWell(
                                  onTap: () => Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              UserDetailsScreen(
                                                widget.plantList,
                                                user: _userList[index],
                                                index: index,
                                                deleteUser: _deleteUser,
                                                editUser: _editUser,
                                              ))),
                                  child: Container(
                                    height: 40,
                                    decoration: BoxDecoration(
                                        color: !index.isEven
                                            ? Colors.white
                                            : Services.colors.tableOddColor,
                                        border: Border(
                                          right: BorderSide(),
                                          left: BorderSide(),
                                          bottom: BorderSide(),
                                        )),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Container(
                                            width: Services.getWidth(context) *
                                                0.6,
                                            padding: EdgeInsets.only(left: 5),
                                            child:
                                                Text(_userList[index].email)),
                                        Container(
                                          height: 40,
                                          width: 1,
                                          color: Services.colors.textColor,
                                        ),
                                        Container(
                                            padding: EdgeInsets.only(left: 5),
                                            // width: Services.getWidth(context) * 0.2,
                                            child: Text(Services.roleToText(
                                                _userList[index].role)))
                                      ],
                                    ),
                                  ),
                                );
                              }),
                        ),
                      ),
                    ],
                  ),
                  // Align(
                  //     alignment: Alignment.bottomCenter,
                  //     child: BottomNavigationBar(
                  //         elevation: 0,
                  //         showSelectedLabels: false,
                  //         showUnselectedLabels: true,
                  //         items: Services.bottomBarItems(onPopupChange:(value){
                  //           print("popup:$value");
                  //         }),
                  //         onTap: (indexValue) {})),
                  Positioned(
                    bottom: Services.getHieght(context) * 0.12,
                    right: 10,
                    child: FloatingActionButton(
                      backgroundColor: Services.colors.appBarColor,
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => AddOrUpdateUser(
                                    widget.plantList,
                                    addUser: _addUser)));
                      },
                      child: Icon(Icons.add),
                    ),
                  )
                ],
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                      height: 40,
                      width: 40,
                      child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                              Services.colors.appBarColor))),
                  Container(
                    height: 10,
                  ),
                  Text("Loading User data",
                      style: TextStyle(
                        color: Services.colors.textColor,
                        fontSize: 18,
                      ))
                ],
              ));
  }
}
