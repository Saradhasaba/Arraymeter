import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:math';
import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/models/category.dart';
import 'package:arraymeter/models/ticketModel.dart';
import 'package:arraymeter/screens/ticketing/dateFilter.dart';
import 'package:arraymeter/screens/ticketing/ticketDetails.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/marqueText.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:intl/intl.dart';
import 'addTicket.dart';
import 'filter.dart';

// ignore: must_be_immutable
class TicketList extends StatefulWidget {
  List<PlantModel> plants;

  TicketList({this.plants});

  @override
  _TicketListState createState() => _TicketListState();
}

class _TicketListState extends State<TicketList> {
  bool _loading;
  List<int> calState = [];
  List<int> calCategory = [];
  List<Ticket> ticketList = [];
  List<Ticket> _ticketListWithoutDeleteAndClosed = [];
  List<Ticket> _onlyClosedTickets = [];
  List<Ticket> _onlyDeletedTickets = [];

  List<Category> _category = [];
  List<Category> _status = [];
  List<Category> _unChangedStatus = [];
  TextStyle _cardTextStyle = TextStyle(
      fontFamily: Services.mont_regular,
      color: Services.colors.textColor,
      fontSize: 14);

  @override
  void initState() {
    getTicketData(true);

    super.initState();
  }

  _filter(bool all, bool includeDeleteOrClosed) {
    if (!all) {
      _ticketListWithoutDeleteAndClosed = ticketList
          .where((element) =>
              selectedStatus.contains(element.statusId) ||
              selectedCat.contains(element.catId))
          .toList();
      if (!selectedStatus.contains("6") && !selectedStatus.contains("7")) {
        _ticketListWithoutDeleteAndClosed.removeWhere(
            (element) => element.statusId == "6" || element.statusId == "7");
      }
    } else {
      _ticketListWithoutDeleteAndClosed = ticketList
          .where(
              (element) => element.statusId != "6" && element.statusId != "7")
          .toList();
    }

    if (selectedStatus.isNotEmpty && selectedCat.isNotEmpty) {
      _ticketListWithoutDeleteAndClosed = ticketList
          .where((element) =>
              selectedStatus.contains(element.statusId) &&
              selectedCat.contains(element.catId))
          .toList();
    }
    if (includeDeleteOrClosed)
      _ticketListWithoutDeleteAndClosed.removeWhere(
          (element) => element.statusId == "6" && element.statusId == "7");

    _ticketListWithoutDeleteAndClosed
        .sort((a, b) => b.openedDate.compareTo(a.openedDate));

    setState(() {});
  }

  _dateWiseFilter(DateTime fromDate, DateTime toDate, bool all) async {
    if (!all)
      _ticketListWithoutDeleteAndClosed = ticketList
          .where((element) =>
              ((element.openedDate.isAfter(fromDate)) ||
                  (fromDate.day == element.openedDate.day &&
                      fromDate.month == element.openedDate.month &&
                      fromDate.year == element.openedDate.year)) &&
              ((toDate.day == element.openedDate.day &&
                      toDate.month == element.openedDate.month &&
                      toDate.year == element.openedDate.year) ||
                  element.openedDate.isBefore(toDate)))
          .toList();
    else
      _ticketListWithoutDeleteAndClosed = ticketList.where(
          (element) => element.statusId != "6" && element.statusId != "7");

    setState(() {});
  }

  refresh() => getTicketData(false);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // resizeToAvoidBottomPadding: false,
      body: !_loading
          ? Stack(
              children: [
                Column(mainAxisSize: MainAxisSize.max, children: [
                  Container(height: 10),
                  Column(
                    children: [
                      Container(
                        width: Services.getWidth(context),
                        margin: EdgeInsets.symmetric(horizontal: 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                                width: Services.getWidth(context) * 0.75,
                                height: 40,
                                child: SomeFixedUi.searchUi(
                                    onSearchTextChange: (searchTexts) {
                                  Timer(Duration(milliseconds: 100), () {
                                    setState(() {
                                      _ticketListWithoutDeleteAndClosed = ticketList
                                          .where((element) => (element.title.toLowerCase().contains(
                                                  searchTexts.toLowerCase()) ||
                                              element.status.toString().toLowerCase().contains(
                                                  searchTexts.toLowerCase()) ||
                                              element.address.toString().toLowerCase().contains(
                                                  searchTexts.toLowerCase()) ||
                                              element.ticketNo.toString().toLowerCase().contains(
                                                  searchTexts.toLowerCase()) ||
                                              element.openedDate.toString().toLowerCase().contains(
                                                  searchTexts.toLowerCase()) ||
                                              element.meterId.toString().toLowerCase().contains(
                                                  searchTexts.toLowerCase()) ||
                                              element.category.toString().toLowerCase().contains(
                                                  searchTexts.toLowerCase()) ||
                                              element.city
                                                  .toString()
                                                  .toLowerCase()
                                                  .contains(
                                                      searchTexts.toLowerCase())))
                                          .toList();
                                    });
                                    if (searchTexts.isEmpty) {
                                      _ticketListWithoutDeleteAndClosed =
                                          ticketList
                                              .where((element) =>
                                                  element.statusId != "6" &&
                                                  element.statusId != "7")
                                              .toList();
                                      _ticketListWithoutDeleteAndClosed.sort((a,
                                              b) =>
                                          b.openedDate.compareTo(a.openedDate));
                                    }
                                  });
                                })),
                            GestureDetector(
                                // iconSize: 40,
                                child: Image.asset(
                                  Images.filterImage,
                                  height: 40,
                                  width: 40,
                                ),
                                onTap: () => showDialog(
                                    context: context,
                                    builder: (context) => FilterView(
                                          category: _category,
                                          status: _unChangedStatus,
                                          filterTickets: _filter,
                                          statusNo: calState,
                                          categoryNo: calCategory,
                                        )))
                          ],
                        ),
                      ),
                      Container(
                          margin: EdgeInsets.symmetric(
                              horizontal: Services.getWidth(context) * 0.03),
                          height: 30,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              GestureDetector(
                                  child: Icon(
                                    Icons.calendar_today,
                                  ),
                                  onTap: () {
                                    showDialog(
                                        context: context,
                                        builder: (BuildContext context) =>
                                            DateWiseFilter(
                                              dateWiseFilter: _dateWiseFilter,
                                            ));
                                  }),
                              Row(
                                children: [
                                  GestureDetector(
                                      child: Icon(Icons.keyboard_arrow_up,
                                          size: 30),
                                      onTap: () {
                                        _ticketListWithoutDeleteAndClosed.sort(
                                            (a, b) => a.openedDate
                                                .compareTo(b.openedDate));
                                        setState(() {});
                                      }),
                                  GestureDetector(
                                      child: Icon(
                                        Icons.keyboard_arrow_down,
                                        size: 30,
                                      ),
                                      onTap: () {
                                        _ticketListWithoutDeleteAndClosed.sort(
                                            (a, b) => b.openedDate
                                                .compareTo(a.openedDate));
                                        setState(() {});
                                      }),
                                ],
                              ),
                            ],
                          )),
                    ],
                  ),
                  Expanded(
                    child:
                        // Container(
                        //   height: USerProfile.role == Role.plantOwner
                        //       ? Services.getHieght(context) * 0.68
                        //       : Services.getHieght(context) * 0.63,
                        //   width: Services.getWidth(context),
                        //   child:
                        ListView.builder(
                            padding: EdgeInsets.only(bottom: 60),
                            itemCount: _ticketListWithoutDeleteAndClosed.length,
                            itemBuilder: (BuildContext context, index) =>
                                GestureDetector(
                                  onTap: () {
                                    PlantModel plant;
                                    try {
                                      plant = widget.plants.singleWhere(
                                          (element) =>
                                              element.id ==
                                                  _ticketListWithoutDeleteAndClosed[index].meterId);





                                    } catch (e) {
                                      print("err:$e");
                                    }


                                    // print( _ticketListWithoutDeleteAndClosed[
                                    //                   index]);
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => TicketDetails(
                                                  _ticketListWithoutDeleteAndClosed[
                                                      index],
                                                  _status,
                                                  plant,
                                                  refreshTickets: refresh,
                                                )));
                                  },
                                  child: Container(
                                      // height: 150,
                                      child: Card(
                                    elevation: 6.0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(20),
                                      side: new BorderSide(
                                          color: Services.colors.appBarColor,
                                          width: 1.0),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.all(15.0),
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              MarqueeWidget(
                                                child: Text(
                                                    _ticketListWithoutDeleteAndClosed[
                                                            index]
                                                        .status,
                                                    style: _cardTextStyle),
                                              ),
                                              // Container(
                                              // width:
                                              //     Services.getWidth(context) *
                                              //         0.45,
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.end,
                                                children: [
                                                  if (Services.size <=
                                                      Size(350.0, 550.3))
                                                    Container(
                                                      width: Services.getWidth(
                                                              context) *
                                                          0.45,
                                                      child: MarqueeWidget(
                                                        child: Text(
                                                          "Ticket# : ${_ticketListWithoutDeleteAndClosed[index].ticketNo}",
                                                          style: _cardTextStyle,
                                                          textAlign:
                                                              TextAlign.right,
                                                        ),
                                                      ),
                                                    )
                                                  else
                                                    MarqueeWidget(
                                                      child: Text(
                                                        "Ticket# : ${_ticketListWithoutDeleteAndClosed[index].ticketNo}",
                                                        style: _cardTextStyle,
                                                        textAlign:
                                                            TextAlign.right,
                                                      ),
                                                    ),
                                                ],
                                              ),
                                              // ),
                                            ],
                                          ),
                                          SizedBox(height: 10),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                width:
                                                    Services.getWidth(context) *
                                                        0.40,
                                                child: MarqueeWidget(
                                                  child: Text(
                                                      _ticketListWithoutDeleteAndClosed[
                                                                  index]
                                                              .category ??
                                                          "",
                                                      textAlign: TextAlign.left,
                                                      style: _cardTextStyle),
                                                ),
                                              ),
                                              Services.size <=
                                                      Size(350.0,
                                                          550.3) // 4 inch
                                                  ? Container(
                                                      width: Services.getWidth(
                                                              context) *
                                                          0.45,
                                                      child: MarqueeWidget(
                                                        child: Text(
                                                            "Issue Date : ${DateFormat("MM-dd-yyyy").format(_ticketListWithoutDeleteAndClosed[index].openedDate)}",
                                                            style:
                                                                _cardTextStyle),
                                                      ),
                                                    )
                                                  : Container(
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: [
                                                          MarqueeWidget(
                                                            child: Text(
                                                                "Issue Date : ${DateFormat("MM-dd-yyyy").format(_ticketListWithoutDeleteAndClosed[index].openedDate)}",
                                                                style:
                                                                    _cardTextStyle),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                            ],
                                          ),
                                          SizedBox(height: 10),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                width:
                                                    Services.getWidth(context) *
                                                        0.40,
                                                child: MarqueeWidget(
                                                  child: Text(
                                                      _ticketListWithoutDeleteAndClosed[
                                                                  index]
                                                              .title ??
                                                          "",
                                                      maxLines: 1,
                                                      style: _cardTextStyle),
                                                ),
                                              ),
                                              Container(
                                                width:
                                                    Services.getWidth(context) *
                                                        0.45,
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    MarqueeWidget(
                                                      child: Text(
                                                          "Capacity : ${_ticketListWithoutDeleteAndClosed[index].capacity ?? ""} kw" ??
                                                              "",
                                                          style:
                                                              _cardTextStyle),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 10),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                width:
                                                    Services.getWidth(context) *
                                                        0.40,
                                                child: MarqueeWidget(
                                                    child: Text(
                                                        _ticketListWithoutDeleteAndClosed[
                                                                    index]
                                                                .address ??
                                                            "",
                                                        style: _cardTextStyle)),
                                              ),
                                              Container(
                                                width:
                                                    Services.getWidth(context) *
                                                        0.45,
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  children: [
                                                    MarqueeWidget(
                                                        child: Text(
                                                            " ${_ticketListWithoutDeleteAndClosed[index].city}",
                                                            style:
                                                                _cardTextStyle)),
                                                  ],
                                                ),
                                              ),
                                              // Text("Ticket ID #713684",style: _cardTextStyle),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  )),
                                )),
                  ),
                ]),
                if (USerProfile.role == Role.plantOwner)
                  Positioned(
                      bottom: Services.getHieght(context) * 0.12,
                      right: 10,
                      child: FloatingActionButton(
                        backgroundColor: Services.colors.appBarColor,
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => AddTicketPage(
                                        categories: _category,
                                        plants: widget.plants,
                                        addTicket: refresh,
                                      )));
                        },
                        child: Icon(Icons.add),
                      ))

                // :Container()
              ],
            )
          : SomeFixedUi.loader("Loading tickets"),
    );
  }

  void getTicketData(bool firstTime) async {
    _loading = true;
    final  plantIds=List.generate( widget.plants.length, (index) => widget.plants[index].id);

    if (firstTime) {
      String url = Urls.getTicketCat;
      String url1 = Urls.getTicketStatus;

      Response statusResponse = await NetworkHelper.sendDataToBackend(url1,
          {"installer": USerProfile.role == Role.Installer ? true : false});

      List cat = await NetworkHelper.getServerData(url);

      List status = json.decode(statusResponse.body);

      cat.forEach((element) {
        _category.add(Category(element["catId"], element["catName"]));
      });
      status.forEach((element) {
        _status.add(Category(element["statusId"], element["statusName"]));
        _unChangedStatus
            .add(Category(element["statusId"], element["statusName"]));
      });
      if (USerProfile.role == Role.plantOwner) {
        _unChangedStatus.removeWhere((element) => element.id == '7');
      }
    }

    //call api to getTickets

    var response = await NetworkHelper.sendDataToBackend(Urls.getTickets, {
      "role": USerProfile.role == Role.Installer ? "Installer" : "PlantUser",
      "userId": USerProfile.id,
      "orgId": USerProfile.orgId,
      "plantIds":plantIds
    });
    // print({
    //   "role": USerProfile.role == Role.Installer ? "Installer" : "PlantUser",
    //   "userId": USerProfile.id,
    //   "orgId": USerProfile.orgId
    // });
    List tickets = await json.decode(response.body);
    // print(tickets.last);
    ticketList = List.generate(
        tickets.length, (index) => Ticket.fromJson(tickets[index]));

    _ticketListWithoutDeleteAndClosed = ticketList
        .where((element) => element.statusId != "6" && element.statusId != "7")
        .toList();

    _onlyClosedTickets =
        ticketList.where((element) => element.statusId == "6").toList();
    _onlyDeletedTickets =
        ticketList.where((element) => element.statusId == "7").toList();

// print("_onlyClosedTickets:${_onlyClosedTickets.length}");
// print("_onlyDeletedTickets:${_onlyDeletedTickets.length}");
//

    calStatusDetails();
    calCategoryDetails();
    _ticketListWithoutDeleteAndClosed
        .sort((a, b) => b.openedDate.compareTo(a.openedDate));

    // _ticketListWithoutDeleteAndClosed.forEach((element){print(element.statusId);});
    setState(() {
      _loading = false;
    });
  }

  void calStatusDetails() {
    calState.clear();
    for (int k = 0; k < _unChangedStatus.length; k++) calState.add(0);
    for (int i = 0; i < _unChangedStatus.length; i++) {
      for (Ticket eachTicket in _ticketListWithoutDeleteAndClosed) {
        if (eachTicket.status == _unChangedStatus[i].name) calState[i] += 1;
      }
    }
    print(calState);

    if (USerProfile.role == Role.Installer) {
      calState[5] = _onlyClosedTickets.length;
      calState[6] = _onlyDeletedTickets.length;
    } else {
      calState[5] = _onlyClosedTickets.length;
    }
  }

  void calCategoryDetails() {
    calCategory.clear();
    for (int k = 0; k < _category.length; k++) calCategory.add(0);
    for (int i = 0; i < _category.length; i++) {
      for (Ticket eachTicket in _ticketListWithoutDeleteAndClosed) {
        if (eachTicket.category == _category[i].name &&
            eachTicket.statusId != '7' &&
            eachTicket.statusId != '6') calCategory[i] += 1;
      }
    }
  }
}
