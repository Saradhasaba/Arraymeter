import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class DateWiseFilter extends StatefulWidget {
  Function dateWiseFilter;

  DateWiseFilter({this.dateWiseFilter});

  @override
  _DateWiseFilterState createState() => _DateWiseFilterState();
}

class _DateWiseFilterState extends State<DateWiseFilter> {
  DateTime _fDateTime = DateTime.now(), _toDate = DateTime.now();
  TextStyle _cardTextStyle = TextStyle(
      fontFamily: Services.mont_regular,
      color: Services.colors.textColor,
      fontSize: 14);

  _dateSelector(bool isFrom, context) {
    DateTime _dateTime = isFrom ? _fDateTime : _toDate;

    return Container(
      height: 30,
      width: Services.getWidth(context) * 0.45,
      decoration: Services.boxDecoration,
      child: FlatButton(
        color: Colors.white,
        onPressed: () => Services.showCalender(
            context: context,
            selectedDate: (value) async {
              isFrom ? _fDateTime = value : _toDate = value;

              setState(() {});
            },
            initialDate: _dateTime,
            type: 0),
        child: Text(
            "${_dateTime.month.toString().padLeft(2, '0')}/${_dateTime.day.toString().padLeft(2, '0')}/${_dateTime.year}",
            style: TextStyle(
                fontSize: 17.0,
                color: Services.colors.textColor,
                fontWeight: FontWeight.bold)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
        elevation: 16,
        child: Stack(
          children: [
            Container(
              height: 300,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Text("Filter by date")

                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text("From Date   ", style: _cardTextStyle),
                      _dateSelector(true, context)
                    ]),

                    Container(height: 10),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text("To Date         ", style: _cardTextStyle),
                      _dateSelector(false, context)
                    ]),
                    Container(height: 20),
                    SomeFixedUi.button("Apply", () {
                      widget.dateWiseFilter(_fDateTime, _toDate,false);
                      Navigator.pop(context);
                    })
                  ]),
            ),
            Positioned(
              child: IconButton(
                  icon: Icon(
                    Icons.clear,
                    size: 35,
                    color: Colors.black,
                  ),
                  onPressed: () {

                    widget.dateWiseFilter(_fDateTime, _toDate,true);

                    Navigator.pop(context);
                  }),
              top: 0,
              right: 5,
            )
          ],
        ));
  }
}
