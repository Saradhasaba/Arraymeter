import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:arraymeter/models/chatModel.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:arraymeter/screens/ticketing/imageView.dart';

class ChatBubble extends CustomPainter {
  final Color color;
  final Alignment alignment;

  ChatBubble({
    @required this.color,
    this.alignment,
  });

  var _radius = 10.0;
  var _x = 10.0;

  @override
  void paint(Canvas canvas, Size size) {
    if (alignment == Alignment.topRight) {
      canvas.drawRRect(
          RRect.fromLTRBAndCorners(
            0,
            0,
            size.width - 8,
            size.height,
            bottomLeft: Radius.circular(_radius),
            topRight: Radius.circular(_radius),
            topLeft: Radius.circular(_radius),
          ),
          Paint()
            ..color = Color(0x99d7f9f7)
            ..style = PaintingStyle.fill);
      canvas.drawRRect(
          RRect.fromLTRBAndCorners(
            0,
            0,
            size.width - 8,
            size.height,
            bottomLeft: Radius.circular(_radius),
            topRight: Radius.circular(_radius),
            topLeft: Radius.circular(_radius),
          ),
          Paint()
            ..color = this.color
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke
            ..strokeWidth = 0.5);
      var path = new Path();
      path.moveTo(size.width - _x, size.height - 10);
      path.lineTo(size.width - _x, size.height);
      path.lineTo(size.width, size.height);
      canvas.clipPath(path);
    } else {
      canvas.drawRRect(
          RRect.fromLTRBAndCorners(
            _x - 7,
            0,
            size.width,
            size.height,
            bottomRight: Radius.circular(_radius),
            topRight: Radius.circular(_radius),
            topLeft: Radius.circular(_radius),
          ),
          Paint()
            ..color = this.color
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke
            ..strokeWidth = 0.5);
      var path = new Path();
      path.moveTo(0, size.height);
      path.lineTo(_x, size.height);
      path.lineTo(_x, size.height - 10);
      canvas.clipPath(path);
      // canvas.drawRRect(
      //     RRect.fromLTRBAndCorners(
      //       0,
      //       0.0,
      //       _x,
      //       size.height,
      //       topRight: Radius.circular(_radius),
      //     ),
      //     Paint()
      //       ..color = this.color
      //       ..style = PaintingStyle.stroke
      //       ..strokeCap = StrokeCap.round
      //       ..style = PaintingStyle.stroke
      //       ..strokeWidth = 0.5);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}

class ChatTile extends StatefulWidget {
  String userName;
  String dateTime;
  EdgeInsets edgeInsets;
  EdgeInsets margins;
  bool fromMe;
  CrossAxisAlignment crossAxisAlignment;
  Alignment chatArrowAlignment;
  Alignment alignment;
  ChatMessageModel chatMessageModel;
  TextStyle textStyle;
  Function deleteMessage;
  TextStyle smallTextStyle;

  ChatTile(this.chatMessageModel, {this.deleteMessage}) {
    fromMe = chatMessageModel.from == USerProfile.id;
    alignment = fromMe ? Alignment.topRight : Alignment.topLeft;
    chatArrowAlignment = fromMe ? Alignment.topRight : Alignment.topLeft;
    textStyle = TextStyle(
      fontSize: 16.0,
      fontFamily: Services.mont_med,
      color: Services.colors.textColor,
    );
    smallTextStyle = TextStyle(
      fontSize: 12.0,
      fontFamily: Services.mont_regular,
      color: Services.colors.textColor,
    );
    // Color chatBgColor = fromMe ? Colors.blue : Colors.black12;
    edgeInsets = fromMe
        ? EdgeInsets.fromLTRB(5, 5, 15, 5)
        : EdgeInsets.fromLTRB(15, 5, 5, 5);
    margins = fromMe
        ? EdgeInsets.fromLTRB(80, 5, 10, 5)
        : EdgeInsets.fromLTRB(10, 5, 80, 5);

    crossAxisAlignment =
        fromMe ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    String you;
    you = chatMessageModel.deletable ? "--You   " : "- You";
    userName = fromMe ? you : "${chatMessageModel.fName}-";
    dateTime = DateFormat("MM-dd-yyyy").format(chatMessageModel.timeStamp) +
        ',' +
        (chatMessageModel.timeStamp.hour.toString().padLeft(2, "0") +
            ":" +
            (chatMessageModel.timeStamp.minute.toString().padLeft(2, "0")));
  }

  @override
  _ChatTileState createState() => _ChatTileState();
}

class _ChatTileState extends State<ChatTile> {
  String msgDocs = "msgDocs";

  bool isFileDownloaded = false;
  List<Document> allDocs = List<Document>();
  Widget fileIcon = Icon(
    Icons.arrow_circle_down_rounded,
    color: Services.colors.appBarColor,
  );

  String url;
  String docPath;
  int imageLength;

  // List<String> allImgs = List<String>();
  @override
  void initState() {
    // if (widget.chatMessageModel.docPath != null)
    // _isDocumentDownloaded();
    // _checkDownloadedFile();
    // _createListIcon(); // to create all icons for doc to avoid null due to
    // _updateIconList();
    for (var eachDoc in widget.chatMessageModel.docName) {
      allDocs.add(Document(eachDoc, widget.chatMessageModel.chatId));
    }
    setDocs();
    imageLength = widget.chatMessageModel.imagePath.length;
    print(imageLength);
    super.initState();
  }

  setDocs() {
    for (var e in allDocs) {
      setState(() {
        e.isDownloaded().then((a) {
          setState(() {
            e.uiUpdate();
          });
        });
      });
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  List<Widget> listIcon = List<Widget>();

  addData(String id, String path) async {
    print("ID" + id + " :: " + "path" + path);
    SharedPreferences pre = await SharedPreferences.getInstance();
    List<String> msgDocs = pre.getStringList("msgDocs") ?? [];
    String data = jsonEncode({"id": id, "path": path});
    msgDocs.add(data);
    bool ret = await pre.setStringList("msgDocs", msgDocs);
    return ret;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          margin: widget.margins,
          // decoration: Services.boxDecorationForMessageTile,
          child: Align(
            alignment: widget.alignment,
            child: Stack(
              children: [
                CustomPaint(
                  painter: ChatBubble(
                    color: Services.colors.textColor,
                    alignment: widget.chatArrowAlignment,
                  ),
                  child: Container(
                    margin: EdgeInsets.all(10),
                    child: Stack(
                      children: <Widget>[
                        Padding(
                          padding: widget.edgeInsets,
                          child: Column(
                            crossAxisAlignment: widget.crossAxisAlignment,
                            children: [
                              Text(widget.userName,
                                  style: widget.smallTextStyle),
                              Text(
                                widget.dateTime,
                                style: widget.smallTextStyle,
                              ),
                              // Text(
                              //   widget.chatMessageModel.status,
                              //   style: TextStyle(
                              //     fontSize: 14.0,
                              //     color: Services.colors.textColor,
                              //   ),
                              // ),
                              Text(
                                widget.chatMessageModel.message,
                                style: widget.textStyle,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (widget.chatMessageModel.deletable)
                  Positioned(
                      left: -6,
                      top: -8,
                      child: IconButton(
                        icon: Image.asset(
                          Images.delete,
                          width: 25,
                          height: 25,
                        ),
                        onPressed: () {
                          Services.deleteData(context, "Message").then((value) {
                            if (value) {
                              widget.deleteMessage(
                                  widget.chatMessageModel.chatId);
                            }
                          });
                        },
                      ))
              ],
            ),
          ),
        ),
        if (widget.chatMessageModel.imagePath != null &&
            widget.chatMessageModel.imagePath.length == 1)
          for (String eachImagePath in widget.chatMessageModel.imagePath)
            Container(
                // decoration: Services.boxDecorationForMessageTile,
                margin: widget.margins,
                child: Align(
                  alignment: widget.alignment,
                  child: GestureDetector(
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(10.0),
                        child: Image.network(
                          Urls.localIp + eachImagePath,
                          //widget.chatMessageModel.imagePath,
                          width: 160,
                          height: 160,
                          fit: BoxFit.fill,
                        )),
                    onTap: () {
                      List<String> img = List<String>();
                      img.add(Urls.localIp + eachImagePath);
                      // widget.chatMessageModel.imagePath);
                      if (widget.chatMessageModel.imagePath != null)
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    ImageView(img.first, imageUrlList: img)));
                    },
                  ),
                )),

        if (widget.chatMessageModel.imagePath.length > 1)
          Align(
            alignment: widget.alignment,
            child: Container(
              decoration: widget.fromMe
                  ? Services.boxDecorationForMessageTilefrom
                  : Services.boxDecorationForMessageTile,
              margin: EdgeInsets.all(6),
              padding: EdgeInsets.all(3),
              width: Services.getWidth(context) / 1.9,
              child: Column(
                children: [
                  GridView(
                    physics: NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 2.0,
                      mainAxisSpacing: 2.0,
                    ),
                    shrinkWrap: true,
                    children: [
                      ...List.generate(
                          imageLength == 3
                              ? imageLength - 1
                              : widget.chatMessageModel.imagePath.length,
                          (index) {
                        return ClipRRect(
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(index == 0 ? 10 : 0),
                              topRight: Radius.circular(index == 1 ? 10 : 0),
                              bottomLeft: imageLength == 2 && index == 0
                                  ? Radius.circular(10)
                                  : Radius.circular(index == 2 ? 10 : 0),
                              bottomRight: imageLength == 2 && index == 1
                                  ? Radius.circular(10)
                                  : Radius.circular(index == 3 ? 10 : 0)),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => ImageView(
                                          Urls.localIp +
                                              widget.chatMessageModel
                                                  .imagePath[index],
                                          imageUrlList: List.generate(
                                              widget.chatMessageModel.imagePath
                                                  .length, (index) {
                                            return Urls.localIp +
                                                widget.chatMessageModel
                                                    .imagePath[index];
                                          }))));
                            },
                            child: Image.network(
                              Urls.localIp +
                                  widget.chatMessageModel.imagePath[index],
                              width: 50,
                              height: 50,
                              fit: BoxFit.fill,
                            ),
                          ),
                        );
                      })
                    ],
                  ),
                  if (imageLength == 3)
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ImageView(
                                    Urls.localIp +
                                        widget.chatMessageModel.imagePath[2],
                                    imageUrlList: List.generate(
                                        widget.chatMessageModel.imagePath
                                            .length, (index) {
                                      return Urls.localIp +
                                          widget.chatMessageModel
                                              .imagePath[index];
                                    }))));
                      },
                      child: Container(
                        height: 90,
                        margin: EdgeInsets.only(top: 2),
                        child: ClipRRect(
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                          ),
                          child: Image.network(
                            Urls.localIp + widget.chatMessageModel.imagePath[2],
                            width: double.infinity,
                            height: 50,
                            fit: BoxFit.fill,
                          ),
                        ),
                      ),
                    )
                ],
              ),
            ),
          ),
        // if (widget.chatMessageModel.docName != null)
        if (allDocs.isNotEmpty && allDocs != null)
          for (var pathDoc in allDocs)
            GestureDetector(
              onTap: () async {
                setState(() {
                  pathDoc.openOrDownload(addData).then((_) {
                    print("UI Updated");
                    setState(() {
                      pathDoc.uiUpdate();
                    });
                  });
                });
              },
              child: Container(
                  height: 45,
                  decoration: widget.fromMe
                      ? Services.boxDecorationForMessageTilefrom
                      : Services.boxDecorationForMessageTile,
                  margin: widget.margins,
                  padding: widget.edgeInsets,
                  child: Align(
                    alignment: widget.alignment,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          if (widget.fromMe) pathDoc.fileIcon,
                          // listIcon[widget.chatMessageModel.docName
                          //     .indexOf(pathDoc)],
                          Flexible(
                            child: Text(
                              pathDoc.docName,
                              // pathDoc["name"],
                              overflow: TextOverflow.ellipsis,
                              softWrap: false,
                              style: widget.textStyle,
                            ),
                          ),
                          if (!widget.fromMe) pathDoc.fileIcon
                          // listIcon[widget.chatMessageModel.docName
                          //     .indexOf(pathDoc)],
                        ],
                      ),
                    ),
                  )),
            ),
      ],
    );
  }
}

class Document {
  String docName;
  String docPath;
  String ticketIds;
  Widget fileIcon = Icon(
    Icons.file_present,
    color: Services.colors.appBarColor,
  );
  bool isDocDownloded = false;
  String msgDocs = "msgDocs";

  Document(Map<String, dynamic> data, String ticketId) {
    this.docName = data["name"];
    this.docPath = data["path"];
    this.ticketIds = ticketId;
    isDownloaded().then((a) {
      uiUpdate();
    });
  }

  String getFileName(String path) => path.split('/').last;

  isDownloaded() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    List<String> msgDocList = sharedPreferences.getStringList(msgDocs) ?? [];
    var dir = await getApplicationDocumentsDirectory();
    if (msgDocList.isNotEmpty) {
      List<Map> docList = List.generate(
          msgDocList.length, (index) => jsonDecode(msgDocList[index]));

      int index = docList.indexWhere((element) => element["id"] == ticketIds);

      if (index >= 0) {
        List<String> pathList =
            List.generate(docList.length, (index) => docList[index]["path"]);

        isDocDownloded =
            pathList.contains("${dir.path}/" + getFileName(docPath));

        print('Condition:' + isDocDownloded.toString());

        if (isDocDownloded == true) {
          fileIcon = Icon(
            Icons.file_present,
            color: Services.colors.appBarColor,
          );
        } else {
          fileIcon = Icon(
            Icons.arrow_circle_down_rounded,
            color: Services.colors.appBarColor,
          );
        }
        print("path  " + "${dir.path}/" + getFileName(docPath));
      } else
        isDocDownloded = false;
      fileIcon = Icon(
        Icons.arrow_circle_down_rounded,
        color: Services.colors.appBarColor,
      );
    } else {
      fileIcon = Icon(
        Icons.arrow_circle_down_rounded,
        color: Services.colors.appBarColor,
      );
      isDocDownloded = false;
    }
  }

  uiUpdate() {
    // print('is Present:' + isDocDownloded.toString());
    if (isDocDownloded) {
      fileIcon = Icon(
        Icons.file_present,
        color: Services.colors.appBarColor,
      );
    } else {
      fileIcon = Icon(
        Icons.arrow_circle_down_rounded,
        color: Services.colors.appBarColor,
      );
    }
  }

  openOrDownload(Function updateShraredPre) async {
    if (isDocDownloded) {
      fileIcon = Icon(
        Icons.file_present,
        color: Services.colors.appBarColor,
      );
      var dir = await getApplicationDocumentsDirectory();
      OpenFile.open("${dir.path}/" + getFileName(docPath));
    } else {
      fileIcon = Container(
          margin: EdgeInsets.all(5),
          width: 19,
          height: 19,
          child: CircularProgressIndicator(
              valueColor:
                  AlwaysStoppedAnimation<Color>(Services.colors.appBarColor)));

      // SharedPreferences sharedPreferences =
      //     await SharedPreferences.getInstance();

      // List<String> msgDocList = sharedPreferences.getStringList(msgDocs) ?? [];
      // print(
      //     "First Time legnth" + msgDocList.length.toString() + "::" + docName);
      var data = await http.get(Urls.localIp + docPath);

      var bytes = data.bodyBytes;
      var dir = await getApplicationDocumentsDirectory();
      File file = File("${dir.path}/" + getFileName(docPath));
      print('downloaded:' + file.path);

      File urlFile = await file.writeAsBytes(bytes);
      docPath = urlFile.path;

      print("path is" + urlFile.path);

      String docDetails = jsonEncode({"id": ticketIds, "path": urlFile.path});

      print("data IS :" + docDetails);

      // int i = msgDocList.length;

      // msgDocList.add(docDetails);

      // print("after:" + msgDocList.length.toString() + "::" + docName);

      // if (i == msgDocList.length) {
      //   isDocDownloded = false;
      //   print("not Stored");
      //   return false;
      // }

      bool stored = await updateShraredPre(
          ticketIds,
          urlFile
              .path); //Singletoned SharedPreference instance cannot be called in every instatnce Simultaneously

      print(file.toString() +
          "#" +
          data.statusCode.toString() +
          "#" +
          stored.toString());

      if (stored) {
        fileIcon = Icon(
          Icons.file_present,
          color: Services.colors.appBarColor,
        );
        print("present");
      } else {
        fileIcon = Icon(
          Icons.arrow_circle_down_rounded,
          color: Services.colors.appBarColor,
        );
      }
      isDocDownloded = stored;
    }
  }
}
