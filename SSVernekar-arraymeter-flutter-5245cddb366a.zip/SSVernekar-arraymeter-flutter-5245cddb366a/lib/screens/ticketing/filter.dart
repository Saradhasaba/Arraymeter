import 'package:arraymeter/models/category.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';

List selectedCat = [], selectedStatus = [];

// ignore: must_be_immutable
class FilterView extends StatefulWidget {
  List<Category> category, status;
  Function filterTickets;
  List<int> statusNo;
  List<int> categoryNo;

  FilterView(
      {this.status,
      this.category,
      this.filterTickets,
      this.statusNo,
      this.categoryNo});

  @override
  _FilterViewState createState() => _FilterViewState();
}

class _FilterViewState extends State<FilterView> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
        elevation: 16,
        child: Container(
            height: Services.size >= Size(432.0, 816.0)
                ? Services.getHieght(context) / 1.35
                : Services.getHieght(context) / 1.2,
            width: Services.getWidth(context),
            child: SingleChildScrollView(
                child: DefaultTabController(
                    length: 2,
                    child: Column(children: [
                      Align(
                        alignment: Alignment(1, 1),
                        child: Container(
                            margin:
                                EdgeInsets.only(top: 10, right: 10, bottom: 5),
                            child: IconButton(
                              icon: Icon(Icons.clear),
                              onPressed: () => Navigator.pop(context),
                            ),
                            height: 20),
                      ),
                      Container(
                          height: 50,
                          child: TabBar(
                              indicatorColor: Services.colors.textColor,
                              tabs: [
                                Tab(
                                  child: Text(
                                    "Status",
                                    style: TextStyle(
                                        color: Services.colors.textColor,
                                        fontSize: 18,
                                        fontFamily: Services.mont_med),
                                  ),
                                ),
                                Tab(
                                  child: Text(
                                    "Category",
                                    style: TextStyle(
                                        color: Services.colors.textColor,
                                        fontSize: 18,
                                        fontFamily: Services.mont_med),
                                  ),
                                )
                              ])),
                      Container(
                        height: (Services.getHieght(context) / 1.3) * 0.7,
                        child: TabBarView(
                          children: [
                            Container(
                              child: ListView.builder(
                                  itemCount: widget.status.length,
                                  itemBuilder: (context, index) => _catStatRow(
                                        widget.status[index],
                                        0,
                                        widget.statusNo[index],
                                      )),
                            ),
                            Container(
                              child: ListView.builder(
                                  itemCount: widget.category.length,
                                  itemBuilder: (context, index) => _catStatRow(
                                      widget.category[index],
                                      1,
                                      widget.categoryNo[index])),
                            ),
                          ],
                        ),
                      ),
                      SomeFixedUi.button("Apply", () {
                        if (selectedCat.isNotEmpty || selectedStatus.isNotEmpty)
                          widget.filterTickets(false, false);
                        else {
                          if (selectedStatus.contains("7") ||
                              selectedStatus.contains("6"))
                            widget.filterTickets(true, true);
                          else
                            widget.filterTickets(true, false);
                        }

                        Navigator.pop(context);
                      })
                    ])))));
  }

  void _onCategorySelected(bool selected, categoryId, int a) {
    switch (a) {
      case 0:
        if (selected == true) {
          setState(() {
            selectedStatus.add(categoryId);
          });
        } else {
          setState(() {
            selectedStatus.remove(categoryId);
          });
        }

        break;
      case 1:
        if (selected == true) {
          setState(() {
            selectedCat.add(categoryId);
          });
        } else {
          setState(() {
            selectedCat.remove(categoryId);
          });
        }

        break;
    }
  }

  Widget _catStatRow(Category data, int a, int calculatedList) {
    String name;
    if (a == 0) {
      name = data.name + " " + "($calculatedList)";
    } else {
      name = data.name + " " + "($calculatedList)";
    }
    return Container(
      margin: EdgeInsets.only(top: 30, left: 30),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            height: 20,
            width: 20,
            child: Checkbox(
              value: a == 0
                  ? selectedStatus.contains(data.id)
                  : selectedCat.contains(data.id),
              onChanged: (value) {
                _onCategorySelected(value, data.id, a);
              },
            ),
            decoration: Services.boxDecoration,
          ),
          SizedBox(
            width: 10,
          ),
          Expanded(
            child: Text(
              name,
              style: TextStyle(
                  color: Services.colors.textColor,
                  fontSize: 17,
                  fontFamily: Services.mont_regular),
            ),
          )
        ],
      ),
    );
  }
}
