import 'dart:convert';

import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/screens/ticketing/ticketList.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';

// ignore: must_be_immutable
class TicketSummary extends StatefulWidget {
  List<PlantModel> plants;

  TicketSummary({this.plants});

  @override
  _TicketSummaryState createState() => _TicketSummaryState();
}

class _TicketSummaryState extends State<TicketSummary> {
  Size _size;

  String _noProduction,
      _noCommunication,
      _inverterBreakdown,
      _performanceIssues,
      _others,_meters;

  bool _loading = true;

  Widget _detailstable(String imagePath, String value, String text,
          BuildContext context, int fleet) =>
      Container(
        margin: EdgeInsets.only(bottom: 20),
        child: Row(
          children: [
            Image.asset(
              imagePath,
              height: _size >= Size(428.0, 816.0)
                  ? 70
                  : (_size > Services.minimumSize ? 60 : 50),
              width: _size >= Size(428.0, 816.0)
                  ? 70
                  : (_size > Services.minimumSize ? 60 : 50),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 30.0),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (value != null)
                      Text(
                        fleet == 1
                            ? value.padLeft(2, '0')
                            : value.padLeft(2, '0'),
                        style: TextStyle(
                            fontSize: _size >= Size(428.0, 816.0)
                                ? 50
                                : (_size > Services.minimumSize ? 44 : 30),
                            color: Services.colors.textColor),
                      ),
                    Text(text,
                        style: TextStyle(
                            fontSize: _size > Services.minimumSize ? 18 : 16,
                            color: Services.colors.textColor))
                  ]),
            )
          ],
        ),
      );

  @override
  void initState() {
    getTickets();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    print(_size);

    return !_loading
        ? Scaffold(
            // resizeToAvoidBottomPadding: false,
            backgroundColor: Services.colors.scaffoldColor,
            body: DefaultTabController(
              length: 2,
              child: Column(
                children: [
                  Container(
                    child: TabBar(
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicatorColor: Services.colors.textColor,
                      labelColor: Services.colors.textColor,
                      labelStyle: TextStyle(
                        color: Services.colors.textColor,
                        fontFamily: Services.mont_med,
                        fontSize: 18,
//                            fontFamily: Constants.mont_regular
                      ),
                      unselectedLabelStyle: TextStyle(
                        color: Services.colors.textColor,
                        fontFamily: Services.mont_med,
                        fontSize: 18,
//                            fontFamily: Constants.mont_regular
                      ),
                      tabs: [
                        Tab(
                          child: Text(
                            'Ticket Summary',
                            style: TextStyle(
                              fontSize: Services.size <= Services.iphone5Screen
                                  ? 15
                                  : 18,
                            ),
                          ),
                        ),
                        Tab(
                            child: Text(
                          'Ticket List',
                          style: TextStyle(
                            fontSize: Services.size <= Services.iphone5Screen
                                ? 15
                                : 18,
                          ),
                        )),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      child: TabBarView(
                        children: [
                          Container(
                            height: Services.size <= Services.iphone5Screen
                                ? Services.getHieght(context) * 0.64
                                : (Services.size >= Size(432.0, 816.0)
                                    ? Services.getHieght(context) * 0.75
                                    : (Services.size > Services.minimumSize
                                        ? Services.getHieght(context) * 0.70
                                        : Services.getHieght(context) * 0.68)),

                            decoration: BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.rectangle,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(40.0)),
                                border: Border.all(
                                    width: 1,
                                    color: Services.colors.textColor)),
                            margin: EdgeInsets.only(
                                top: 10,
                                right: 10,
                                left: 10,
                                bottom: Services.size <= Services.iphone5Screen
                                    ? Services.getHieght(context) * 0.15
                                    : Services.getHieght(context) * 0.1),

                            padding: EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: Services.size > Services.minimumSize
                                    ? 20
                                    : 7),
                            // height: Services.getHieght(context) * 0.72,
                            width: Services.getWidth(context),
                            child: SingleChildScrollView(
                              padding: EdgeInsets.symmetric(
                                  vertical: 0.030637 * Services.size.height,
                                  horizontal: 0),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  _detailstable(
                                      Images.fleetOverViewImages.noProduction,
                                      // Images.fleetOverViewImages.totalPlants,
                                      _noProduction,
                                      "No Production",
                                      context,
                                      0),
                                  _detailstable(
                                      Images
                                          .fleetOverViewImages.noCommunication,
                                      // Images.fleetOverViewImages.online,
                                      _noCommunication,
                                      "No Communication",
                                      context,
                                      0),
                                  _detailstable(
                                      Images.fleetOverViewImages.inverterBreak,
                                      _inverterBreakdown,
                                      "Inverter Breakdown",
                                      context,
                                      0),
                                  _detailstable(
                                      Images.fleetOverViewImages.estimateLoss,
                                      // Images.fleetOverViewImages.noCommunication,
                                      _performanceIssues,
                                      "Performance Issues",
                                      context,
                                      0),
                                  _detailstable(
                                      Images.fleetOverViewImages.totalPlants,
                                      _meters,
                                      "Meter reading",
                                      context,
                                      1),    _detailstable(
                                      Images.fleetOverViewImages.others,
                                      _others,
                                      "Others",
                                      context,
                                      1),
                                ],
                              ),
                            ),
                          ),
                          TicketList(
                            plants: widget.plants,
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ))
        : Scaffold(body: SomeFixedUi.loader("Loading tickets"));
  }

  Future<void> getTickets() async {


  final  plantIds=List.generate( widget.plants.length, (index) => widget.plants[index].id);


    Response response = await NetworkHelper.sendDataToBackend(
        Urls.getTicketCount, {"orgId": USerProfile.orgId, "plantIds": plantIds});

    var _data = jsonDecode(response.body);

    _noCommunication = _data['No Communication'];
    _noProduction = _data['No Production'];
    _performanceIssues = _data['Performance Issues'];
    _inverterBreakdown = _data['Inverter Breakdown'];
    _others = _data['Others'];
    _meters = _data['Meter reading'];

    print(_data);
    _loading = false;
    setState(() {});
  }
}
