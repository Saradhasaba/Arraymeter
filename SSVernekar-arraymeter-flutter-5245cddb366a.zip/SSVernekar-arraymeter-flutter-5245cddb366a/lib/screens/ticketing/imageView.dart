import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';

class ImageView extends StatefulWidget {
  final String imageUrl;
  final List<dynamic> imageUrlList;
  ImageView(this.imageUrl, {this.imageUrlList});

  @override
  _ImageViewState createState() => _ImageViewState();
}

class _ImageViewState extends State<ImageView> {
  PageController pagecontroll = PageController();
  int initPage;
  TextStyle loadStyle =
      TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.white);
  @override
  void initState() {
    initPage = widget.imageUrlList.indexOf(widget.imageUrl);
    print(initPage);
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if (pagecontroll.hasClients) {
        pagecontroll.jumpToPage(initPage);
      }
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        PhotoViewGallery.builder(
            onPageChanged: (i) {},
            loadingBuilder: (context, chunk) {
              return Container(
                  width: double.infinity,
                  color: Colors.black,
                  child: Center(
                    child: Text(
                      'Loading.....',
                      style: loadStyle,
                    ),
                  ));
            },
            loadFailedChild: Container(
                color: Colors.black,
                width: double.infinity,
                child: Center(
                    child: Text(
                  'Failed to Load Image',
                  style: loadStyle,
                ))),
            pageController: pagecontroll,
            itemCount: widget.imageUrlList.length,
            builder: (context, i) {
              return PhotoViewGalleryPageOptions(
                initialScale: PhotoViewComputedScale.contained * 0.9,
                imageProvider: NetworkImage(
                  widget.imageUrlList[i],
                ),
                minScale: PhotoViewComputedScale.contained * 0.8,
                maxScale: PhotoViewComputedScale.covered * 2.8,
              );
            }),
        Positioned(
            top: 20,
            left: 10,
            child: IconButton(
                icon: Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                ),
                onPressed: () => Navigator.pop(context)))
      ]),
    );
  }
}
