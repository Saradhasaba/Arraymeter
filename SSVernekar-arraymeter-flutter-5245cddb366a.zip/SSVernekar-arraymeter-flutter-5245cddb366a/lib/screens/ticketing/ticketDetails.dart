import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/models/category.dart';
import 'package:arraymeter/models/chatModel.dart';
import 'package:arraymeter/models/ticketModel.dart';
import 'package:arraymeter/screens/main/arraymeter.dart';
import 'package:arraymeter/services/carosel.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';

import 'chatUi.dart';

// ignore: must_be_immutable
class TicketDetails extends StatefulWidget {
  Ticket ticket;
  List<Category> status;
  Function refreshTickets;
  PlantModel plantModel;

  TicketDetails(this.ticket, this.status, this.plantModel,
      {this.refreshTickets});

  @override
  _TicketDetailsState createState() => _TicketDetailsState();
}

class _TicketDetailsState extends State<TicketDetails> {
  TextEditingController _problemController = TextEditingController(),
      _reasonMsg = TextEditingController(),
      _chatTfController = TextEditingController();
  DateTime _outageEndDate = DateTime.now();
  ScrollController scrollDown = ScrollController();

  List<ChatMessageModel> _chatMessages;
  ScrollController _chatLVController;

  String _statusId, _statusName, _docName, status;
  bool _outage = false;

  bool _loading = true;

  bool _submiting = false;
  List<Image> allPhotos = List<Image>();
  List<Map<String, dynamic>> alldoc = List<Map<String, dynamic>>();
  List<String> alldocNames = List<String>();
  TextStyle headerStyle = TextStyle(
      fontSize: 18,
      color: Services.colors.textColor,
      fontFamily: Services.mont_med,
      fontWeight: FontWeight.bold);

  TextStyle normalText = TextStyle(
      fontSize: 16,
      color: Services.colors.textColor,
      fontFamily: Services.mont_regular);

  List _status;

  List<Map<String, String>> doc = [];

  List<String> _base64Images = [];

  final GlobalKey<CarouselWithIndicatorState> _imgKey = GlobalKey();

  Widget _row(key, value, {bool underline = false}) {
    return Padding(
      padding: EdgeInsets.only(left: 20.0, bottom: 20),
      child: Row(children: [
        Container(
          width: 160,
          child: Text(
            "$key",
            style: TextStyle(
              fontSize: 16,
              color: Services.colors.textColor,
              fontFamily: Services.mont_regular,
              decoration: underline ? TextDecoration.underline : null,
            ),
          ),
        ),
        Text(":   "),
        Expanded(
          child: Text(
            value ?? "",
            style: TextStyle(
              fontSize: 16,
              color: Services.colors.textColor,
              fontFamily: Services.mont_regular,
              decoration: underline ? TextDecoration.underline : null,
            ),
          ),
        ),
        if (underline)
          GestureDetector(
            child: Icon(
              Icons.keyboard_arrow_down,
            ),
            onTap: () => _scrollDown(),
          ),
        if (underline)
          SizedBox(
            width: 7,
          )
      ]),
    );
  }

  bool enableStatus() {
    if (USerProfile.role == Role.Installer) {
      //installer

      if (widget.ticket.statusId != "5")
        return true;
      else
        return false;
    } else {
      //plantUser

      if (widget.ticket.statusId == "5")
        return true;
      else
        return false;
    }
  }

  _getMessages() async {
    var response = await NetworkHelper.sendDataToBackend(
        Urls.getMessages, {"ticketId": widget.ticket.id});
    print(widget.ticket.id);
    print(response.body);
    String value = response.body;

    List messages = await json.decode(value);
    print(messages);
    _chatMessages = List.generate(messages.length, (index) {
      return ChatMessageModel.fromJson(messages[index]);
    });
    //Deleted Reason from Plant Owner to Installer
    if (widget.ticket.statusId == "7" &&
        USerProfile.role == Role.Installer &&
        widget.ticket.deleteReason != null)
      _chatMessages.add(ChatMessageModel.fromJson({
        "userName": widget.ticket.ownerName,
        "body": widget.ticket.deleteReason + '\n',
        "imagePath": [],
        "timestamp": widget.ticket.lastUpdate != null
            ? widget.ticket.lastUpdate.toString()
            : null,
        //"2021-02-24 06:31:00.000",
        "doc": []
      }));
    print(widget.ticket.lastUpdate.toString());
    // _chatMessages.forEach((element) {print(element.docName);});

    _loading = false;
    setState(() {});
  }

  setUp() {
    imgList = List.generate(widget.ticket.imagesList.length,
        (index) => Urls.localIp + widget.ticket.imagesList[index]);

    if (widget.ticket.caroselImage != null) {
      widget.ticket.caroselImage.forEach((element) {
        element.forEach((forelement) {
          imgList.add(Urls.localIp + forelement);
        });
      });
    }
    print("widget.plantModel.id");
    print(widget.plantModel.id);
    widget.status.removeWhere((element) => element.id == "7");
    _status = List.generate(
        widget.status.length,
        (index) =>
            {"text": widget.status[index].name, "id": widget.status[index].id});
    _statusId = widget.ticket.statusId;

    status = _statusName = widget.ticket.status;

    _problemController.text = widget.ticket.actualProblem;

    //getMessages

    _getMessages();
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  // ignore: missing_return
  bool validate() {
    if (USerProfile.role == Role.plantOwner) _problemController.text = "N.A";

    if (_chatTfController.text.trim() != "" &&
        _problemController.text.trim() != "") {
      if (USerProfile.role == Role.Installer) {
        if (_statusId != "6")
          return true;
        else
          _scaffoldKey.currentState.showSnackBar(new SnackBar(
              backgroundColor: Colors.white,
              content: new Text(
                "You can not close this Ticket",
                style: TextStyle(color: Colors.red),
              )));
      } else
        //plantUser condition

        return true;
    } else {
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            "Please enter all the fields",
            style: TextStyle(color: Colors.red),
          )));

      return false;
    }
  }

  _deleteMessage(String id) {
    NetworkHelper.sendDataToBackend(Urls.deleteMessage, {"id": id});
    _chatMessages.removeWhere((element) => element.chatId == id);
    setState(() {});
  }

  @override
  void dispose() {
    imgList.clear();
    timer.cancel();
    _chatLVController.dispose();
    _chatTfController.dispose();
    super.dispose();
  }

  Timer timer;

  @override
  void initState() {
    setUp();
    _chatLVController = ScrollController(initialScrollOffset: 0.0);
    _chatTfController = TextEditingController();
    // _chatMessages = [
    //   ChatMessageModel(
    //     chatId: "1",
    //     from: "516",
    //     message: widget.ticket.description,
    //   ),
    // ];
    timer = Timer.periodic(Duration(minutes: 5), (Timer t) => _getMessages());

    super.initState();
  }

  Future<void> enterReasonForDelete(BuildContext _context) async {
    return showDialog(
        context: _context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20.0))),
            title: Text('Write Reason for Deleting'),
            content: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
              SingleChildScrollView(
                child: Container(
                  width: 250,
                  child: TextFormField(
                    minLines: 1,
                    maxLines: null,
                    keyboardType: TextInputType.multiline,
                    controller: _reasonMsg,
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              SomeFixedUi.button('OK', () async {
                await NetworkHelper.sendDataToBackend(Urls.deleteTicket, {
                  "ticketId": widget.ticket.id,
                  "reason": _reasonMsg.text,
                }).then((value) {
                  Navigator.pop(context);

                  widget.refreshTickets();
                  Navigator.pop(context);
                });
              }, fontSize: 15),
            ]),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        centerTitle: true,
        title: Text("ArrayMeter"),
        actions: [SomeFixedUi.appBarLogo()],
      ),
      body: Stack(
        children: [
          ListView(
            controller: scrollDown,
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Text(
                        "Ticket Number",
                        style: headerStyle,
                      ),
                      Text(
                        widget.ticket.ticketNo,
                        style: headerStyle,
                      ),
                      if (USerProfile.role == Role.plantOwner)
                        Container(
                          height: 55,
                          width: 55,
                          child: IconButton(
                              icon: Image.asset(Images.delete),
                              onPressed: () async {
                                bool isDeleted = await Services.deleteData(
                                    context, "Ticket");
                                if (isDeleted) {
                                  enterReasonForDelete(context);
                                }
                                // if (isDeleted)

                                //  _deleteUser(context);
                              }),
                        ),
                    ]),
              ),
              Divider(thickness: 1, color: Services.colors.appBarColor),
              if (imgList.isNotEmpty)
                CarouselWithIndicatorDemo(
                  key: _imgKey,
                ),
              Align(
                alignment: Alignment.centerRight,
                child: Row(mainAxisAlignment: MainAxisAlignment.end, children: <
                    Widget>[
                  Container(
                      height: 55,
                      width: 55,
                      margin: EdgeInsets.only(right: 20),
                      child: IconButton(
                        icon:
                            Image.asset(Images.fleetOverViewImages.totalPlants),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ArrayData(
                                        widget.plantModel,
                                        false,
                                        ticketDate: widget.ticket.outageStart,
                                      )));
                        },
                      )),
                ]),
              ),
              _row("Plant Name", widget.ticket.plantName),
              _row("Serial Number", widget.ticket.plantId),
              _row("Category", widget.ticket.category),
              if (widget.ticket.lastUpdate != null)
                GestureDetector(
                  onTap: () => _scrollDown(),
                  child: _row("Last Updated",
                      "${DateFormat("MM-dd-yyyy").format(widget.ticket.lastUpdate)},${widget.ticket.lastUpdate.hour.toString().padLeft(2, '0')}:${widget.ticket.lastUpdate.minute.toString().padLeft(2, '0')}",
                      underline: true),
                ),
              _row("Status", status),

              _row("Indicated Problem", widget.ticket.title),
              if (widget.ticket.actualProblem != null)
                _row("Actual Problem", "${_problemController.text}"),
              _row(
                  "Outage Start Date",
                  widget.ticket.outageStart != null
                      ? "${DateFormat("MM-dd-yyyy").format(widget.ticket.outageStart)}"
                      : ""),
              if (widget.ticket.outageEnd != null)
                _row("Outage End Date",
                    "${DateFormat("MM-dd-yyyy").format(widget.ticket.outageEnd)}"),
              _row("Created Date",
                  "${DateFormat("MM-dd-yyyy").format(widget.ticket.openedDate)},${widget.ticket.openedDate.hour.toString().padLeft(2, '0')}:${widget.ticket.openedDate.minute.toString().padLeft(2, '0')}"),
              _row("Plant Owner", widget.ticket.ownerName),
              _row("Address", widget.ticket.address),
              _row("Location", widget.ticket.city),
              _row("Email", widget.ticket.email),
              _row("Phone Number", widget.ticket.contactNumber),
              // _row("Status", status),
              // _row("Category", widget.ticket.category),
              // _row("Created Date",
              //     "${DateFormat("MM-dd-yyyy").format(widget.ticket.openedDate)}"),
              // _row("Indicated Problem", widget.ticket.title),
              // _row(
              //     "Outage Start Date",
              //     widget.ticket.outageStart != null
              //         ? "${DateFormat("MM-dd-yyyy").format(widget.ticket.outageStart)}"
              //         : ""),

              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 10.0, horizontal: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    _chatList(),
                    if (widget.ticket.statusId != "7" &&
                        widget.ticket.statusId !=
                            "6") //buttons disabled for Delete and Close Status
                      Column(children: [
                        if (USerProfile.role == Role.Installer)
                          SomeFixedUi.field(
                              "Actual Problem", _problemController),
                        SizedBox(height: 8),
                        if (enableStatus())
                          Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Change Ticket Status',
                                  style: Services.fieldLabel,
                                ),
                                Dropdown(
                                    // selectedValueIndex:
                                    // _update ? (_role == Role.plantOwner ? 1 : 0) : null,
                                    hint: widget.ticket.status,
                                    items: _status,
                                    onSelected: (Map val) {
                                      print(val);
                                      _statusId = val['id'];
                                      _statusName = val['text'];
                                      print(_statusId);
                                      if (_statusId == "6")
                                        _outage = true;
                                      else
                                        _outage = false;

                                      setState(() {});
                                    }),
                              ]),
                        if (USerProfile.role == Role.plantOwner && _outage)
                          _outageEnd(),
                        _bottomChatArea(),
                        //'///////////////////////////Work in Progress /////////////////
                        // Stack(children: [
                        //   Container(
                        //     width: double.infinity,
                        //     height: _fileImg != null ? _fileImg.height : 200,
                        //     decoration: BoxDecoration(
                        //       border: Border.all(
                        //           color: Color(0x884e7567), width: 1.5),
                        //     ),
                        //     child: Center(
                        //       child: _fileImg != null
                        //           ? AspectRatio(aspectRatio: 2, child: _fileImg)
                        //           : addFilebutton("Add-Image", () {
                        //               _picDoc(true);
                        //             }),
                        //     ), //center
                        //   ), //container
                        //   if (_fileImg != null)
                        //     Positioned(
                        //       top: -1,
                        //       right: -5,
                        //       child: IconButton(
                        //         icon: Icon(Icons.cancel_outlined),
                        //         onPressed: () {
                        //           setState(() {
                        //             _fileImg = null;
                        //             _base64Images.clear();
                        //           });
                        //         },
                        //       ),
                        //     ), //positioned
                        // ]),
                        Wrap(
                          direction: Axis.horizontal,
                          spacing: 3.0,
                          runSpacing: 3.0,
                          children: listImages(),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Wrap(
                          direction: Axis.horizontal,
                          spacing: 3.0,
                          runSpacing: 3.0,
                          children: allDocs(),
                        ),
                        ///////////////////////////////work in progress /////////////////
                        // Column(
                        //     mainAxisAlignment: MainAxisAlignment.center,
                        //     crossAxisAlignment: CrossAxisAlignment.center,
                        //     children: allDocs()
                        //     // [
                        //     //   addFilebutton("Add pdf/doc file", () {
                        //     //     _picDoc(false);
                        //     //   }, widthManual: 160, textSize: 16),
                        //     //
                        //     //   if (doc.isNotEmpty)
                        //     //     Container(
                        //     //         width: Services.getWidth(context) * 0.5,
                        //     //         child: Wrap(
                        //     //           children: [
                        //     //             Text(_docName,
                        //     //                 style: TextStyle(
                        //     //                     color:
                        //     //                         Services.colors.textColor)),
                        //     //             InkWell(
                        //     //                 onTap: () {
                        //     //                   doc.clear();
                        //     //                   setState(() {});
                        //     //                 },
                        //     //                 child: Text("Remove",
                        //     //                     style: TextStyle(
                        //     //                         color: Colors.red))),
                        //     //           ],
                        //     //         ))
                        //     // ]
                        //     ),
                        Align(
                          alignment: Alignment.center,
                          child: !_submiting
                              ? SomeFixedUi.button("Submit", () async {
                                  var date = DateTime.now();
                                  if (validate()) {
                                    setState(() {
                                      _submiting = true;
                                    });
                                    var response =
                                        await NetworkHelper.sendDataToBackend(
                                            Urls.addMessage, {
                                      "role": USerProfile.role == Role.Installer
                                          ? "Installer"
                                          : "PlantUser",
                                      "ticketId": widget.ticket.id,
                                      "userId": USerProfile.id,
                                      "body": _chatTfController.text,
                                      "actualP": _problemController.text,
                                      "statusId": _statusId,
                                      "outageEnd": _outageEndDate.toString(),
                                      "image": _base64Images,
                                      "doc": doc,
                                      "dateTime":
                                          "${date.year}-${date.month}-${date.day} ${date.hour}:${date.minute}:${date.second}"
                                    });
                                    setState(() {
                                      widget.ticket.lastUpdate = DateTime.now();
                                    });
                                    //print(response.body);
                                    var responseData =
                                        jsonDecode(response.body);
                                    _chatMessages.add(ChatMessageModel(
                                        chatId: responseData["id"],
                                        imagePath: responseData["imagePath"],
                                        from: USerProfile.id,
                                        docPath: responseData["docPath"],
                                        docName: responseData["doc"],
                                        message: _chatTfController.text,
                                        status: _statusName,
                                        deletable: true,
                                        timeStamp: DateTime.now()));
                                    if (responseData["imagePath"].isNotEmpty) {
                                      List newImgList = List.generate(
                                          responseData["imagePath"].length,
                                          (index) =>
                                              Urls.localIp +
                                              responseData["imagePath"][index]);

                                      imgList = [...imgList, ...newImgList];
                                      // _imgKey.currentState.setState(() {

                                      // });
                                    }
                                    widget.refreshTickets();
                                    status = _statusName;
                                    _base64Images.clear();
                                    allPhotos.clear();
                                    doc.clear();
                                    // _fileImg = null;
                                    _base64Images.clear();
                                    setState(() {
                                      _submiting = false;
                                    });
                                    _chatTfController.clear();
                                  }
                                })
                              : Padding(
                                  padding: EdgeInsets.all(13),
                                  child: CircularProgressIndicator()),
                        )
                      ]),
                  ],
                ),
              )
            ],
          ),
          if (_loading) SomeFixedUi.loader("")
        ],
      ),
    );
  }

  _bottomChatArea() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 2),
      child: Row(
        children: <Widget>[
          _chatTextArea(),
        ],
      ),
    );
  }

  _chatTextArea() {
    return Expanded(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(
          'Add your Reply',
          style: Services.fieldLabel,
        ),
        TextField(
          controller: _chatTfController,
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10.0),
              borderSide: BorderSide(
                color: Services.colors.textColor,
                width: 1.0,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10.0),
              borderSide: BorderSide(
                color: Services.colors.textColor,
                width: 1.0,
              ),
            ),
            filled: true,
            fillColor: Colors.white,
            contentPadding: EdgeInsets.all(10.0),
            hintText: 'Type message...',
          ),
          maxLines: 4,
          minLines: 1,
        ),
      ]),
    );
  }

  // _chatListScrollToBottom() {
  //   Timer(Duration(milliseconds: 100), () {
  //     if (_chatLVController.hasClients) {
  //       _chatLVController.animateTo(
  //         _chatLVController.position.maxScrollExtent,
  //         duration: Duration(milliseconds: 100),
  //         curve: Curves.decelerate,
  //       );
  //     }
  //   });
  // }

  _chatList() {
    return Container(
      child: ListView.builder(
        cacheExtent: 100,
        controller: _chatLVController,
        reverse: false,
        shrinkWrap: true,
        padding: EdgeInsets.fromLTRB(0, 10.0, 0, 10.0),
        itemCount: null == _chatMessages ? 0 : _chatMessages.length,
        itemBuilder: (context, index) {
          ChatMessageModel chatMessage = _chatMessages[index];
          return Stack(
            children: [
              ChatTile(
                chatMessage,
                deleteMessage: _deleteMessage,
              ),
            ],
          );
        },
      ),
    );
  }

  _outageEnd() => Container(
        margin: EdgeInsets.only(top: 10, left: 10, right: 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            "Outage End date",
            style: Services.fieldLabel,
          ),
          GestureDetector(
            onTap: () {
              Services.showCalender(
                  context: context,
                  type: 0,
                  initialDate: _outageEndDate,
                  selectedDate: (date) {
                    _outageEndDate = date;
                    setState(() {});
                  });
            },
            child: Container(
                decoration: BoxDecoration(
                    border: Border.all(color: Services.colors.textColor)),
                height: 40,
                width: Services.getWidth(context),
                padding: EdgeInsets.only(top: 5),
                child: Padding(
                  padding: const EdgeInsets.only(left: 10.0, top: 3),
                  child: Text(
                    DateFormat("MM-dd-yyyy").format(_outageEndDate),
                    style: Services.fieldLabel,
                  ),
                )),
          ),
        ]),
      );

  _picDoc(bool img) async {
    FilePickerResult result = await FilePicker.platform.pickFiles(
        type: img ? FileType.image : FileType.custom,
        onFileLoading: (load) {
          if (load != FilePickerStatus.done || load != FilePickerStatus.picking)
            return;
        },
        allowedExtensions: img ? null : ["pdf", "doc"]);
    Image _fileImg;
    if (result != null) {
      File file = File(result.files.single.path);

      if (img) _fileImg = Image.file(file, fit: BoxFit.cover);

      PlatformFile file1 = result.files.first;

      Uint8List imageBytes = file.readAsBytesSync();

      String imageB64 = base64Encode(imageBytes);

      _docName = file1.name;

      if (img) {
        _base64Images.add(imageB64);
        if (!(["jpg", "png", "jpeg"].contains(file1.extension.toLowerCase()))) {
          SomeFixedUi.showAlert(context, "Only Images Can Be Selected");
          _fileImg = null;
          _base64Images.removeLast();
          allPhotos.removeLast();
          setState(() {});
        }
      } else {
        doc.add({
          "extension": file1.extension,
          "name": _docName,
          "base64": imageB64
        });
        if (!(["pdf", "doc"].contains(file1.extension.toLowerCase()))) {
          SomeFixedUi.showAlert(context, "Only Documents Can Be Selected");
          doc.removeLast();
          setState(() {});
        }
      }
      setState(() {});
    }
    if (img) {
      return _fileImg;
    }
  }

  Widget addFilebutton(String _title, Function _task,
      {double widthManual, double heightManual, double textSize}) {
    return Container(
        margin: EdgeInsets.only(top: 15),
        height: heightManual != null ? heightManual : 45,
        width: widthManual != null ? widthManual : 140,
        child: RaisedButton(
          textColor: Colors.white,
          color: Color(0xffd0eae0),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
              side: BorderSide(color: Services.colors.appBarColor)),
          child: Text(_title,
              style: TextStyle(
                fontSize: textSize != null ? textSize : 18,
                color: Services.colors.appBarColor,
              )),
          onPressed: _task,
        ));
  }

  _scrollDown() {
    final bottomOffset = scrollDown.position.maxScrollExtent;
    var scroll =
        (widget.ticket.statusId == '7' || widget.ticket.statusId == '6')
            ? bottomOffset
            : bottomOffset - (USerProfile.role == Role.Installer ? 510.0 : 390);
    scrollDown.animateTo(scroll,
        duration: Duration(milliseconds: 200), curve: Curves.bounceInOut);
  }

  List<Widget> listImages() {
    List<Widget> allImg = List<Widget>();
    // print(allPhotos);
    print("IMAGE base64 lENGTH:" + _base64Images.length.toString());
    print("image photo:" + allPhotos.length.toString());
    allImg.addAll([
      if (allPhotos != null && allPhotos.isNotEmpty)
        for (var _img in allPhotos)
          Stack(children: [
            Container(
              width: (Services.getWidth(context) / 2) - 10,
              height: 100,
              decoration: BoxDecoration(
                border: Border.all(color: Color(0x884e7567), width: 1.5),
              ),
              child: Center(
                  child: AspectRatio(aspectRatio: 2, child: _img)), //center
            ), //container
            if (_img != null)
              Positioned(
                top: -1,
                right: -5,
                child: IconButton(
                  icon: Icon(Icons.cancel_outlined),
                  onPressed: () {
                    setState(() {
                      int i = allPhotos.indexOf(_img);
                      allPhotos.remove(_img);
                      _base64Images.removeAt(i);
                    });
                  },
                ),
              ), //positioned
          ])
    ]);
    if (allPhotos.length != 4)
      allImg.add(
        Container(
          width: (Services.getWidth(context) / 2) - 10,
          height: 100,
          decoration: BoxDecoration(
            border: Border.all(color: Color(0x884e7567), width: 1.5),
          ),
          child: Center(
            child: addFilebutton("Add-Image", () {
              _picDoc(true).then((img) {
                if (img != null) allPhotos.add(img);

                print("Hash Code is:" + img.hashCode.toString());
              });
            }),
          ), //center
        ),
      );
    return allImg;
  }

  List<Widget> allDocs() {
    List<Widget> documentsWidget = List<Widget>();
    print("Doc Legnth: " + doc.length.toString());
    print(doc);
    jsonEncode(doc);
    if (doc.isNotEmpty) documentsWidget.add(SizedBox(height: 8));
    documentsWidget.addAll([
      if (doc != null && doc.isNotEmpty)
        for (var eachDoc in doc)
          Stack(
            children: [
              Container(
                  height: 100,
                  decoration: BoxDecoration(
                    border: Border.all(color: Color(0x884e7567), width: 1.5),
                  ),
                  padding: EdgeInsets.all(10),
                  width: (Services.getWidth(context) / 2) - 15,
                  child: Center(
                    child:
                        //  Wrap(
                        //   children: [
                        Text(
                      eachDoc["name"],
                      style: TextStyle(color: Services.colors.textColor),
                      maxLines: 5,
                    ),
                    //   ],
                    // ),
                  )),
              Positioned(
                top: -10,
                right: -10,
                child: IconButton(
                    icon: Icon(Icons.cancel_outlined),
                    onPressed: () {
                      doc.remove(eachDoc);
                      setState(() {});
                    }),
              )
            ],
          )
    ]);

    if (doc.length != 4)
      documentsWidget.add(Container(
        width: (Services.getWidth(context) / 2) - 15,
        height: 100,
        child: Center(
          child: Container(
              margin: EdgeInsets.only(top: 10),
              child: addFilebutton("Add pdf/doc file", () {
                _picDoc(false);
                print(doc);
              }, widthManual: 156, textSize: 14)),
        ),
      ));
    return documentsWidget;
  }
}
