import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';

import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/models/category.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:connectivity/connectivity.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

// ignore: must_be_immutable
class AddTicketPage extends StatefulWidget {
  final List<Category> categories;
  final List<PlantModel> plants;

  Function addTicket;

  AddTicketPage({this.categories, this.plants, this.addTicket});

  @override
  _AddTicketPageState createState() => _AddTicketPageState();
}

class _AddTicketPageState extends State<AddTicketPage> {
  TextEditingController _problem = TextEditingController(),
      _description = TextEditingController();
  BuildContext _context;
  List<File> _imageList = [];
  List<String> _base64Images = [];
  var doc;
  String _docName;
  String selectedCatId;
  String selectedMeter;
  bool submitLoader = false;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  final GlobalKey<State> keyLoad = GlobalKey<State>();

  // bool _sending = false;
  DateTime _outageStartDate = DateTime.now();
  List _categories = [];
  List _meters = [];
  List<Map<String, dynamic>> docList = List<Map<String, dynamic>>();

  // _imgFromCamera() async {
  //   // ignore: deprecated_member_use
  //   File image = await ImagePicker.pickImage(
  //       source: ImageSource.camera, imageQuality: 50);
  //
  //   if (image != null) {
  //     _imageList.add(image);
  //     Uint8List imageBytes = image.readAsBytesSync();
  //
  //     String imageB64 = base64Encode(imageBytes);
  //
  //     _base64Images.add(imageB64);
  //
  //     setState(() {});
  //   }
  // }

  // _imgFromGallery() async {
  //   // ignore: deprecated_member_use
  //   File image = await ImagePicker.pickImage(
  //       source: ImageSource.gallery, imageQuality: 50);
  //   if (image != null) {
  //     _imageList.add(image);
  //
  //     Uint8List imageBytes = image.readAsBytesSync();
  //
  //     String imageB64 = base64Encode(imageBytes);
  //
  //     _base64Images.add(imageB64);
  //     setState(() {});
  //   }
  // }

  Future<void> _showSubmitPopUp(BuildContext _context) async {
    return showDialog(
        barrierDismissible: false,
        context: _context,
        builder: (BuildContext builder) {
          return WillPopScope(
            onWillPop: () async => false,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 45,
                    height: 45,
                    child: CircularProgressIndicator(
                        // backgroundColor: Theme.of(context).accentColor,
                        valueColor: AlwaysStoppedAnimation<Color>(
                            Services.colors.textColor)),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Text("Submitting...",
                      style: Theme.of(context)
                          .textTheme
                          .headline6
                          .copyWith(color: Colors.black)),
                ],
              ),
            ),
          );
        });
  }

  _picDoc(bool img) async {
    if (img) {
      FilePickerResult result = await FilePicker.platform.pickFiles(
        type: FileType.image,
      );

      if (result != null) {
        File file = File(result.files.single.path);
        PlatformFile file1 = result.files.first;
        Uint8List imageBytes = file.readAsBytesSync();

        String imageB64 = base64Encode(imageBytes);
        _imageList.add(file);

        _base64Images.add(imageB64);
        if (!(["jpg", "png", "jpeg"].contains(file1.extension.toLowerCase()))) {
          SomeFixedUi.showAlert(context, "Only Images Can Be Selected!");
          _imageList.removeLast();
          _base64Images.removeLast();
        }
        setState(() {});
      }
    } else {
      FilePickerResult result = await FilePicker.platform
          .pickFiles(type: FileType.custom, allowedExtensions: ["pdf", "doc"]);

      if (result != null) {
        File file = File(result.files.single.path);

        PlatformFile file1 = result.files.first;

        Uint8List imageBytes = file.readAsBytesSync();

        String imageB64 = base64Encode(imageBytes);

        _docName = file1.name;

        docList.add({
          "extension": file1.extension,
          "name": _docName,
          "base64": imageB64
        });

        if (!(["pdf", "doc"].contains(file1.extension.toLowerCase()))) {
          SomeFixedUi.showAlert(context, "Only Documents Can Be Selected!");
          // doc = null;
          // _docName = null;
          docList.removeLast();
        }

        setState(() {});
      }
    }
  }

  // showPicker(context) {
  //   showModalBottomSheet(
  //       context: context,
  //       builder: (BuildContext bc) {
  //         return SafeArea(
  //           child: Container(
  //             child: new Wrap(
  //               children: <Widget>[
  //                 new ListTile(
  //                     leading: new Icon(
  //                       Icons.photo_library,
  //                       color: Services.colors.appBarColor,
  //                     ),
  //                     title: new Text('Photo Library',
  //                         style: TextStyle(color: Services.colors.textColor)),
  //                     onTap: () {
  //                       _imgFromGallery();
  //                       Navigator.of(context).pop();
  //                     }),
  //                 new ListTile(
  //                   leading: new Icon(Icons.photo_camera,
  //                       color: Services.colors.appBarColor),
  //                   title: new Text(
  //                     'Camera',
  //                     style: TextStyle(color: Services.colors.textColor),
  //                   ),
  //                   onTap: () {
  //                     _imgFromCamera();
  //                     Navigator.of(context).pop();
  //                   },
  //                 ),
  //               ],
  //             ),
  //           ),
  //         );
  //       });
  // }

  Widget _button() => Padding(
        padding: EdgeInsets.symmetric(vertical: 13, horizontal: 5),
        child: SomeFixedUi.button("Add-Image", () {
          FocusScopeNode currentFocus = FocusScope.of(context);
          currentFocus.unfocus();

          _picDoc(true);

          // showPicker(context);
        }, fontSize: 16),
      );

  Widget _image(File image) => Stack(
        children: [
          AspectRatio(
            aspectRatio: 2,
            child: Image.file(
              image,
              fit: BoxFit.fill,
            ),
          ),
          Positioned(
              top: -10,
              right: -10,
              child: IconButton(
                  icon: Icon(Icons.cancel_outlined),
                  onPressed: () {
                    _base64Images.removeAt(_imageList.indexOf(image));
                    _imageList.remove(image);
                    setState(() {});
                  }))
        ],
      );

  List<Widget> gridList() {
    switch (_imageList.length) {
      case 0:
        return [_button()];

      case 1:
        return [_image(_imageList[0]), _button()];

      case 2:
        return [_image(_imageList[0]), _image(_imageList[1]), _button()];

      case 3:
        return [
          _image(_imageList[0]),
          _image(_imageList[1]),
          _image(_imageList[2]),
          _button()
        ];

      case 4:
        return [
          _image(_imageList[0]),
          _image(_imageList[1]),
          _image(_imageList[2]),
          _image(_imageList[3]),
        ];

      default:
        return [];
    }
  }

  Widget _addImage() => Container(
      margin: EdgeInsets.only(top: 10),
      height: 200,
      // decoration: Services.boxDecoration,
      child: GridView.extent(
        physics: NeverScrollableScrollPhysics(),
        maxCrossAxisExtent: 200,
        childAspectRatio: 2,
        children: gridList(),
      ));

  _setUp() {
    _categories = List.generate(
        widget.categories.length,
        (index) => {
              "text": widget.categories[index].name,
              "id": widget.categories[index].id
            });

    _meters = List.generate(
        widget.plants.length,
        (index) => {
              "text": "${widget.plants[index].id}"
                  "-${widget.plants[index].name}",
              "id": widget.plants[index].id
            });

    setState(() {});
  }

  @override
  void initState() {
    _setUp();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _context = context;
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
          centerTitle: true,
          title: Text("ARRAYMETER"),
          actions: [SomeFixedUi.appBarLogo()]),
      body: Padding(
        padding: EdgeInsets.only(top: 5, right: 10, left: 10),
        child: SingleChildScrollView(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Dropdown(
                hint: "Select Plant id",
                items: _meters,
                onSelected: (Map val) {
                  selectedMeter = val["id"].toString();
                }),
            Container(height: 10),
            Dropdown(
                hint: "Select Category",
                items: _categories,
                onSelected: (Map val) {
                  selectedCatId = val["id"].toString();
                }),
            SomeFixedUi.field("Indicated Problem", _problem),
            Container(
              margin: EdgeInsets.only(top: 15),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Outage Start date",
                      style: Services.fieldLabel,
                    ),
                    GestureDetector(
                      onTap: () {
                        Services.showCalender(
                            context: context,
                            type: 0,
                            initialDate: _outageStartDate,
                            selectedDate: (date) {
                              _outageStartDate = date;
                              setState(() {});
                            });
                      },
                      child: Container(
                          decoration: BoxDecoration(
                              border:
                                  Border.all(color: Services.colors.textColor)),
                          height: 40,
                          width: Services.getWidth(context),
                          padding: EdgeInsets.only(top: 5),
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10.0, top: 3),
                            child: Text(
                              DateFormat("MM-dd-yyyy").format(_outageStartDate),
                              style: Services.fieldLabel,
                            ),
                          )),
                    ),
                  ]),
            ),
            Container(height: 10),
            Text(
              "Add Description",
              style: Services.fieldLabel,
            ),
            Container(
              height: 90,
              margin: EdgeInsets.only(top: 5),
              child: TextFormField(
                controller: _description,
                maxLines: 10,
                decoration: new InputDecoration(
                  contentPadding: EdgeInsets.only(top: 5, left: 10),
                  focusedBorder: OutlineInputBorder(
                    borderSide:
                        BorderSide(color: Services.colors.textColor, width: 1),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                        color: Services.colors.textColor, width: 1.0),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Wrap(
              direction: Axis.horizontal,
              spacing: 3.0,
              runSpacing: 3.0,
              children: docListAlign(),
            ),
            // Row(
            //     mainAxisSize: MainAxisSize.max,
            //     mainAxisAlignment: MainAxisAlignment.center,
            //     children: [Column(children: docListAlign())]
            //     // [
            //     // Container(
            //     //   width: Services.getWidth(context) * 0.44,
            //     //   height: 55,
            //     //   child: SomeFixedUi.button("Add pdf/doc", () {
            //     //     _picDoc(false);
            //     //   }),
            //     // ),
            //     // Container(height: 10),
            //     // if (doc != null)
            //     //   Container(
            //     //       width: Services.getWidth(context) * 0.4,
            //     //       child: Wrap(
            //     //         children: [
            //     //           Text(_docName,
            //     //               style:
            //     //                   TextStyle(color: Services.colors.textColor)),
            //     //           InkWell(
            //     //               onTap: () {
            //     //                 _docName = null;
            //     //                 doc = null;
            //     //                 setState(() {});
            //     //               },
            //     //               child: Text("Remove",
            //     //                   style: TextStyle(color: Colors.red))),
            //     //         ],
            //     //       )),
            //     // ],
            //     ),
            _addImage(),
            Container(height: 10),
            // submitLoader == false
            //     ?
            Align(
              alignment: Alignment.center,
              child: Container(
                width: Services.getWidth(context) * 0.8,
                child: SomeFixedUi.button("Post", () async {
                  if (_validate()) {
                    var connectivityResult =
                        await (Connectivity().checkConnectivity());
                    if (connectivityResult == ConnectivityResult.mobile ||
                        connectivityResult == ConnectivityResult.wifi)
                      sendDataToBackend();
                    else
                      _scaffoldKey.currentState.showSnackBar(new SnackBar(
                          content: new Text(
                              'Please check your internet connection')));
                  }
                }),
              ),
            ),
            // :
            // Center(
            //     child: Padding(
            //         padding: EdgeInsets.all(10),
            //         child: CircularProgressIndicator())
            //         ),

            Container(height: 10)
          ]),
        ),
      ),
    );
  }

  // ignore: missing_return
  bool _validate() {
    if (selectedMeter != null &&
        selectedCatId != null &&
        _problem.text.trim().isNotEmpty &&
        _description.text.trim().isNotEmpty)
      return true;
    else {
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            "Please enter all the fields",
            style: TextStyle(color: Colors.red),
          )));
      return false;
    }
  }

  sendDataToBackend() async {
    try {
      setState(() {
        submitLoader = true;
      });
      _showSubmitPopUp(_context);
      // print({
      //   "createdBy": USerProfile.id,
      //   "problem": _problem.text,
      //   "description": _description.text,
      //   "plantId": selectedMeter,
      //   "orgId": USerProfile.orgId,
      //   "outageStart": _outageStartDate.toString(),
      //   "categoryId": selectedCatId,
      //   "images": _base64Images,
      //   "doc": [doc]
      // });
      print({
        "createdBy": USerProfile.id,
        "problem": _problem.text,
        "description": _description.text,
        "plantId": selectedMeter,
        "orgId": USerProfile.orgId,
        "categoryId": selectedCatId,
        "images": _base64Images,
        "outageStart": _outageStartDate.toString(),
        "doc": docList
      });
      NetworkHelper.sendDataToBackend(Urls.addTicket, {
        "createdBy": USerProfile.id,
        "problem": _problem.text,
        "description": _description.text,
        "plantId": selectedMeter,
        "orgId": USerProfile.orgId,
        "categoryId": selectedCatId,
        "images": _base64Images,
        "outageStart": _outageStartDate.toString(),
        "doc": docList
      }).then((value) {
        // Navigator.pop(context);
        print(value.body);
        if (value != null)
          setState(() {
            submitLoader = false;
          });
        widget.addTicket();
        Navigator.pop(context);
        Navigator.pop(context);
        print("Im here 2");
      });
    } catch (e) {
      print('error  ' + e.toString());
      //
    }
  }

  List<Widget> docListAlign() {
    List<Widget> docUIs = [];
    docUIs.add(SizedBox(
      height: 15,
    ));
    print(docList.length);
    if (docList != null && docList.isNotEmpty)
      docUIs = List.generate(docList.length, (index) {
        return Stack(
          children: [
            Container(
                height: 100,
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0x884e7567), width: 1.5),
                ),
                padding: EdgeInsets.all(10),
                width: (Services.getWidth(context) / 2) - 15,
                child: Center(
                  child: Text(
                    docList[index]["name"],
                    style: TextStyle(color: Services.colors.textColor),
                    maxLines: 4,
                  ),
                  //   ],
                  // ),
                )),
            Positioned(
              top: -10,
              right: -10,
              child: IconButton(
                  icon: Icon(Icons.cancel_outlined),
                  onPressed: () {
                    docList.remove(docList[index]);
                    setState(() {});
                  }),
            )
          ],
        );
      });
    if (docList.length != 4)
      docUIs.add(Container(
        width: Services.getWidth(context) * 0.44,
        height: 55,
        margin: EdgeInsets.only(top: 10),
        child: SomeFixedUi.button("Add pdf/doc", () {
          _picDoc(false);
        }, fontSize: 16),
      ));
    return docUIs;
  }
}
