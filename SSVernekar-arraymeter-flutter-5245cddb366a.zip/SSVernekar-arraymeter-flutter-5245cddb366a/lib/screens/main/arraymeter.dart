import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/charts/monthChart.dart';
import 'package:arraymeter/charts/todayChart.dart';
import 'package:arraymeter/charts/yearChart.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/screens/plantmanagement/addUpdateplant.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/marqueText.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';


// ignore: must_be_immutable
class ArrayData extends StatefulWidget {

  PlantModel plantModel;
  bool manageAble;
  final void Function(PlantModel plant) editPlant;
  final void Function(String meterNumber) deletePlant;
  DateTime ticketDate;

  ArrayData(this.plantModel, this.manageAble,
      {this.editPlant, this.deletePlant, this.ticketDate});
  @override
  ArrayDataState createState() => ArrayDataState();
}

class ArrayDataState extends State<ArrayData>
    with SingleTickerProviderStateMixin {
  DateTime _dateTime = DateTime.now();
  PlantStatus _plantStatus;

  BuildContext _context;
  bool _loding = true;

  TabController _controller;

  // ignore: missing_return
  Future<String> getTableData() async {
    Services.texts.meterNo = widget.plantModel.id;

    String url =
        Urls.ip + "api_meter_info.php?meter_id=" + widget.plantModel.id;

    String url1 =
        Urls.ip + "api_installer_info.php?meter_id=" + widget.plantModel.id;
    var data = await NetworkHelper.getServerData(url);
    var data1 = await NetworkHelper.getServerData(url1);

    Services.texts.installerName = data1[0][0]['name'];

    List actualData = data[0];

    Services.texts.state = actualData[1];
    Services.texts.plantName = actualData[11];
    Services.texts.plantAdress = actualData[4];
    Services.texts.capacityValue = actualData[5].toString() + " kW";
    Services.texts.projectId = actualData[12].toString();
    Services.texts.plantStartDate = actualData[10].toString();
    Services.texts.city = actualData[2].toString();
    Services.texts.zipCode = actualData[3].toString();

    double lifeEnergytoShow =
        actualData[16] != null ? double.parse(actualData[16]) : 0;

    Services.texts.lifeTimeEnergy =
        lifeEnergytoShow.toInt().toString() + " kWh";
    // lifeEnergytoShow = 1234001.0;

    if (lifeEnergytoShow >= 100000.0) {
      Services.texts.lifeTimeEnergy =
          (lifeEnergytoShow ~/ 1000).toInt().toString() + " MWh";
    }

    Services.texts.lifeTimeRevenueValue = "\$" +
        ((lifeEnergytoShow) * double.tryParse(widget.plantModel.feed))
            .toStringAsFixed(2)
            .toString();

    _plantStatus = widget.plantModel.plantStatus;
    Services.texts.lastCommunicationDate =
        widget.plantModel.lastCommunication != null
            ? DateFormat("MM-dd-yyyy")
                    .format(widget.plantModel.lastCommunication) +
                ',' +
                (widget.plantModel.lastCommunication.hour
                        .toString()
                        .padLeft(2, "0") +
                    ":" +
                    (widget.plantModel.lastCommunication.minute
                        .toString()
                        .padLeft(2, "0")))
            : "N.A";

    widget.plantModel.city = Services.texts.city;
    widget.plantModel.address = Services.texts.plantAdress;
    widget.plantModel.zipCode = Services.texts.zipCode;

    await _setDayProduction(_dateTime);
    await _setMonthProduction(_dateTime);
    await _setYearProduction(_dateTime);

    print("dateeeee:${widget.ticketDate}");
    if (widget.ticketDate != null) _controller.index = 1;

    _loding = false;

    setState(() {});
  }

  String heading = "Dashboard";

  _handleTabSelection() {
    if (_controller.index == 0)
      heading = "Dashboard";
    else
      heading = "Charts";

    setState(() {});
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    super.dispose();
  }

  @override
  void initState() {
    // setUp();
    _controller = TabController(vsync: this, length: 2);
    _controller.addListener(_handleTabSelection);
    getTableData();
    if (widget.manageAble) heading = "Plant Info";

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeRight,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);

    super.initState();
  }

  Widget _staticCard(String imagePath, String text1, String text2, int a) =>
      Container(
        width: Services.getWidth(context) * 0.5,
        height: 80.0,
        child: Card(
          elevation: 6.0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          color: Colors.white,
          child: Padding(
            padding: EdgeInsets.all(10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Image.asset(
                  imagePath,
                  width: a == 0 ? 40 : 50,
                  height: a == 0 ? 40 : 50,
                  fit: BoxFit.fill,
                ),
                Container(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                      Text(
                        text1,
                        style: TextStyle(
                            fontSize: a != 2 ? 14 : 12,
                            color: Services.colors.textColor,
                            fontFamily: Services.mont_med),
                        textAlign: TextAlign.right,
                      ),
                      Text(
                        text2.replaceAllMapped(reg, mathFunc),
                        style: TextStyle(
                          fontSize: a != 2 ? 14 : 12,
                          color: Services.colors.textColor,
                          fontFamily: Services.mont_med,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.right,
                      ),
                    ]))
              ],
            ),
          ),
        ),
      );

  Widget _tableRow(String a, int odd) => Container(
        height: 30,
        width: double.infinity,
        color: odd == 1 ? Services.colors.tableOddColor : Colors.white,
        alignment: Alignment(-1, 0),
        child: MarqueeWidget(
          child: Text("   $a",
              style: TextStyle(
                color: Services.colors.textColor,
                fontSize: Services.size <= Services.iphone5Screen ? 13 : 16,
              )),
        ),
      );

  Widget get tableListDesign {
    return Container(
        margin: EdgeInsets.all(10),
        color: Colors.white,
        child: Center(
            child: Container(
          decoration: Services.boxDecoration,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              if (!widget.manageAble)
                Container(
                  height: 40,
                  decoration: BoxDecoration(
                      border: Border(
                          bottom:
                              BorderSide(color: Services.colors.appBarColor))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: Services.getWidth(context) * 0.45,
                        child: Text(
                          '  Plant Status',
                          style: TextStyle(
                            color: Services.colors.textColor,
                            fontFamily: Services.mont_regular,
                            fontSize: 16,
                          ),
                        ),
                      ),
                      SizedBox(
                        child: _plantStatus != PlantStatus.idle
                            ? Image.asset(
                                _plantStatus == PlantStatus.noCommunication
                                    ? Images.bottomImages.noCommunication
                                    : _plantStatus == PlantStatus.noProduction
                                        ? Images.bottomImages.noProduction
                                        : Images.fleetOverViewImages.online,
                                height: 30,
                                width: 30,
                                fit: BoxFit.fill,
                              )
                            : Container(
                                width: 30,
                              ),
                      ),
                      SizedBox(
                        width: Services.getWidth(context) * 0.01,
                      ),
                      Container(
                        alignment: Alignment(-1, 0),
                        width: Services.getWidth(context) * 0.3,
                        child: MarqueeWidget(
                          direction: Axis.horizontal,
                          child: Text(
                            _plantStatus == PlantStatus.noCommunication
                                ? 'No Communication'
                                : _plantStatus == PlantStatus.noProduction
                                    ? "No Production"
                                    : _plantStatus == PlantStatus.online
                                        ? "Online"
                                        : "N.A",
                            style: TextStyle(
                              color: Services.colors.textColor,
                              fontFamily: Services.mont_regular,
                              fontSize: Services.size <= Services.iphone5Screen
                                  ? 13
                                  : 16,
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height:
                          MediaQuery.of(_context).size >= Size(432.0, 816.0) &&
                                  MediaQuery.of(_context).orientation ==
                                      Orientation.portrait
                              ? Services.getHieght(_context) * 0.45
                              : 270,
                      width: Services.size <= Services.iphone5Screen
                          ? Services.getWidth(_context) * 0.45
                          : Services.getWidth(_context) * 0.48,
                      child: _tableColumn(
                        !widget.manageAble
                            ? [
                                _tableRow("Plant Name", 1),
                                _tableRow("Serial Number", 0),
                                _tableRow('Installer Name', 1),
                                _tableRow('Plant Address', 0),
                                _tableRow('City', 1),
                                _tableRow('State', 0),
                                _tableRow('Zip Code', 1),
                                _tableRow('Plant Start Date', 0),
                                _tableRow('SDSI Warranty ID', 1),
                              ]
                            : [
                                _tableRow("Plant Name", 1),
                                _tableRow("Serial Number", 0),
                                _tableRow(Texts.capacity, 1),
                                _tableRow('Plant Address', 0),
                                _tableRow('City', 1),
                                _tableRow('State', 0),
                                _tableRow('Zip Code', 1),
                              ],
                      ),
                    ),
                    Container(
                      height:
                          MediaQuery.of(_context).size >= Size(432.0, 816.0) &&
                                  MediaQuery.of(_context).orientation ==
                                      Orientation.portrait
                              ? Services.getHieght(_context) * 0.45
                              : 270,
                      color: Services.colors.textColor,
                      width: 1,
                    ),
                    Container(
                      height:
                          MediaQuery.of(_context).size >= Size(432.0, 816.0) &&
                                  MediaQuery.of(_context).orientation ==
                                      Orientation.portrait
                              ? Services.getHieght(_context) * 0.45
                              : 270,

                      width: Services.getWidth(context) * 0.43,

//                          decoration:
//                          BoxDecoration(border: Border.all(color: Colors.green)),
                      child: _tableColumn(
                        !widget.manageAble
                            ? [
                                _tableRow(
                                    Services.notNullText(
                                        (Services.texts.plantName)),
                                    1),
                                _tableRow(Services.texts.meterNo, 0),
                                _tableRow(
                                    Services.notNullText(
                                        Services.texts.installerName),
                                    1),
                                _tableRow(
                                    Services.notNullText(
                                        (Services.texts.plantAdress)),
                                    0),
                                _tableRow(
                                    Services.notNullText((Services.texts.city)),
                                    1),
                                _tableRow(
                                    Services.notNullText(
                                        (Services.texts.state)),
                                    0),
                                _tableRow(
                                    Services.notNullText(
                                        (Services.texts.zipCode)),
                                    1),
                                _tableRow(
                                    Services.notNullText(
                                        (Services.texts.plantStartDate)),
                                    0),
                                _tableRow(
                                    Services.notNullText(
                                        (Services.texts.projectId)),
                                    1),
                              ]
                            : [
                                _tableRow(
                                    Services.notNullText(
                                        (Services.texts.plantName)),
                                    1),
                                _tableRow(Services.texts.meterNo, 0),
                                _tableRow(
                                    Services.notNullText(
                                        Services.texts.capacityValue),
                                    1),
                                Container(
                                    alignment: Alignment(-1, 0),
                                    height: 30,
                                    child: MarqueeWidget(
                                        direction: Axis.horizontal,
                                        child: Text(
                                            "   ${Services.texts.plantAdress}",
                                            style: TextStyle(
                                              color: Services.colors.textColor,
                                              fontSize: 16,
                                            )))),
                                _tableRow(
                                    Services.notNullText((Services.texts.city)),
                                    1),
                                _tableRow(
                                    Services.notNullText(
                                        (Services.texts.state)),
                                    0),
                                _tableRow(
                                    Services.notNullText(
                                        (Services.texts.zipCode)),
                                    1),
                              ],
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        )));
  }

  Widget get summeryTable {
    if (!widget.manageAble)
      return Card(
          elevation: 1.0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(1.0),
          ),
          color: Colors.white,
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Last Communication',
                      style: TextStyle(
                          fontSize:
                              Services.size <= Services.iphone5Screen ? 14 : 16,
                          color: Services.colors.textColor,
                          fontFamily: Services.mont_regular),
                    ),
                    Text(
                      Services.texts.lastCommunicationDate,
                      style: TextStyle(
                          fontSize:
                              Services.size <= Services.iphone5Screen ? 14 : 16,
                          color: Services.colors.textColor,
                          fontFamily: Services.mont_regular),
                    )
                  ],
                ),
              ),
              tableListDesign,
            ],
          ));
    else
      return tableListDesign;
  }

  Widget _cardRow(List<Widget> item) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: item,
      );

  Widget _tableColumn(List<Widget> item) => Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: item);

  Widget get siteSummery {
    return Container(
        child: Column(children: <Widget>[
      Container(
          color: Services.colors.scaffoldColor,
          child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                !widget.manageAble
                    ? Container(
                        padding: EdgeInsets.all(5),
                        height: 28,
                        child: Text(
                          'Energy',
                          style: TextStyle(
                              color: Services.colors.textColor,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              fontFamily: Services.mont_med),
                        ),
                        alignment: Alignment.bottomCenter,
                      )
                    : Container(
                        margin: EdgeInsets.only(right: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Text(
                              "Plant Details",
                              style: TextStyle(
                                  color: Services.colors.textColor,
                                  // fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  fontFamily: Services.mont_med),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Container(
                                height: 60,
                                width: 60,
                                child: IconButton(
                                    icon: Image.asset(Images.edit),
                                    onPressed: () async {
                                      widget.plantModel.state =
                                          Services.texts.state;

                                      await Navigator.push(
                                          _context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  AddOrUpdatePlant(
                                                    plant: widget.plantModel,
                                                    editPlant: widget.editPlant,
                                                  )));

                                      Navigator.pop(context);
                                    })),
                            Container(
                                height: 60,
                                width: 60,
                                child: IconButton(
                                    icon: Image.asset(Images.delete),
                                    onPressed: () async {
                                      bool isDeleted =
                                          await Services.deleteData(
                                              _context, "Plant");

                                      if (isDeleted) _deletePlant();
                                    }))
                          ],
                        ),
                      ),
                widget.manageAble ? Container() : _report(),
                summeryTable,
              ]))
    ]));
  }

  @override
  Widget build(BuildContext context) {
    _context = context;

    return OrientationBuilder(builder: (context, orientaion) {
      // orientaion == Orientation.portrait
      //      ? Services.getHieght(context) * 0.57
      //     : Services.getHieght(context);

      return !_loding
          ? MaterialApp(
              debugShowCheckedModeBanner: false,
              builder: (context, child) {
                return MediaQuery(
                  child: child,
                  data: MediaQuery.of(context).copyWith(textScaleFactor: 1),
                );
              },
              home: Scaffold(
                backgroundColor: Services.colors.scaffoldColor,
                appBar: orientaion == Orientation.portrait
                    ? AppBar(
                        shadowColor: Services.colors.textColor,
                        leading: IconButton(
                            icon: Icon(Icons.arrow_back),
                            onPressed: () => Navigator.pop(context)),
                        centerTitle: true,
                        backgroundColor: Services.colors.textColor,
                        actions: [
                          Container(
                            margin:
                                EdgeInsets.only(top: 10, bottom: 10, right: 5),
                            child: ClipRRect(
                                borderRadius: BorderRadius.circular(8.0),
                                child: Image.asset(
                                  "assets/logo.png",
                                  fit: BoxFit.fill,
                                  width: 100,
                                )),
                          )
                        ],
                        title: Column(
                          children: [
                            Text(
                              "ArrayMeter",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontFamily: Services.mont_regular),
                            ),
                            Text("$heading",
                                style: TextStyle(
                                    fontSize: 16,
                                    fontFamily: Services.mont_regular))
                          ],
                        ),
                        bottom: widget.manageAble
                            ? null
                            : PreferredSize(
                                preferredSize: Size.fromHeight(50),
                                child: Container(
                                  alignment: Alignment.center,
                                  width: Services.getWidth(context),
                                  color: Services.colors.scaffoldColor,
                                  child: Container(
                                    margin:
                                        EdgeInsets.symmetric(horizontal: 10),
                                    child: TabBar(
                                      controller: _controller,
                                      // indicatorSize: TabBarIndicatorSize.tab,
                                      indicatorColor: Colors.black,
                                      labelColor: Services.colors.textColor,
                                      labelStyle: TextStyle(
                                        color: Services.colors.textColor,
                                        fontFamily: Services.mont_med,
                                        fontSize: 18,
//                            fontFamily: Constants.mont_regular
                                      ),
                                      tabs: [
                                        Tab(
                                          child: Text('Plant Summary',
                                              style: TextStyle(
                                                fontSize: Services.size <=
                                                        Services.iphone5Screen
                                                    ? 16
                                                    : null,
                                              )),
                                        ),
                                        Tab(
                                            child: Text('Charts',
                                                style: TextStyle(
                                                  fontSize: Services.size <=
                                                          Services.iphone5Screen
                                                      ? 16
                                                      : null,
                                                ))),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                      )
                    : null,
                body: TabBarView(
                  controller: _controller,
                  physics: orientaion == Orientation.portrait
                      ? AlwaysScrollableScrollPhysics()
                      : NeverScrollableScrollPhysics(),
                  children: [
                    SingleChildScrollView(
                      child: siteSummery,
                    ),
                    DefaultTabController(
                      length: 3,
                      child: Scaffold(
                        appBar: AppBar(
                          backgroundColor: Colors.white,
                          automaticallyImplyLeading: false,
                          title: TabBar(
                            indicatorColor: Services.colors.textColor,
                            labelStyle:
                                TextStyle(fontFamily: Services.mont_med),
                            unselectedLabelStyle:
                                TextStyle(fontFamily: Services.mont_regular),
                            tabs: [
                              Tab(
                                child: Text(
                                  'Day',
                                  style: TextStyle(
                                    color: Services.colors.textColor,
                                    fontSize:
                                        Services.size <= Services.iphone5Screen
                                            ? 15
                                            : 18,
                                  ),
                                ),
                              ),
                              Tab(
                                  child: Text(
                                'Monthly',
                                style: TextStyle(
                                  color: Services.colors.textColor,
                                  fontSize:
                                      Services.size <= Services.iphone5Screen
                                          ? 15
                                          : 18,
                                ),
                              )),
                              Tab(
                                child: Text(
                                  'Yearly',
                                  style: TextStyle(
                                    color: Services.colors.textColor,
                                    fontSize:
                                        Services.size <= Services.iphone5Screen
                                            ? 15
                                            : 18,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        body: TabBarView(
                          children: [
                            TodayChart(ticketDate: widget.ticketDate ?? null),
                            MonthData(),
                            YearChart(),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          : Scaffold(
              backgroundColor: Services.colors.scaffoldColor,
              body: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                      height: 40,
                      width: 40,
                      child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                              Services.colors.appBarColor))),
                  Container(
                    height: 10,
                  ),
                  Text(
                      widget.manageAble
                          ? "Loading Plant info"
                          : "Loading Plant data",
                      style: TextStyle(
                        color: Services.colors.textColor,
                        fontSize: 18,
                      ))
                ],
              ),
            );
    });
  }

  _setDayProduction(DateTime value) async {
    String url = Urls.ip +
        Urls.apiDataPhp +
        "widget_id=daywidget&meter_id=" +
        Services.texts.meterNo +
        "&month_calendar=" +
        Services.backendDate(value);

    var data = await NetworkHelper.getServerData(url);

    // await  print("data:${data[0]["values"][0][1]}");

    Services.texts.today = DateFormat("MM-dd-yyyy").format(value);
    // "${value.month}-${value.day}-${value.year}";
    Services.texts.todayEnergy = data.isNotEmpty
        ? data[0]["values"][0][1]
                .toStringAsFixed(1)
                .replaceAllMapped(reg, mathFunc) +
            ' kWh'
        : "0 kWh";
  }

  _setMonthProduction(DateTime value) async {
    String url = Urls.ip +
        Urls.apiDataPhp +
        "widget_id=yearGen&meter_id=" +
        Services.texts.meterNo +
        "&month=" +
        value.year.toString();

    var data = await NetworkHelper.getServerData(url);

    Services.texts.month = "${Services.month(value.month)}-${value.year}";

    if (data != null) {
      print(data[value.month - 1][1]);
      Services.texts.monthEnergy = data[value.month - 1][1]
              .toStringAsFixed(0)
              .replaceAllMapped(reg, mathFunc) +
          " kWh";
      print(Services.texts.monthEnergy);
    } else
      Services.texts.monthEnergy = "0 kWh";
  }

  _setYearProduction(DateTime value) async {
    String url = Urls.ip +
        Urls.apiDataPhp +
        "widget_id=yearprowidget&meter_id=" +
        Services.texts.meterNo +
        "&month_calendar=" +
        Services.backendDate(value);

    var data = await NetworkHelper.getServerData(url);

    Services.texts.year = ("Year-${value.year}");

    if (data.isNotEmpty) {
      print(data[0]["values"][0][1].runtimeType);

      double yearEnergytoShow =
          double.tryParse(data[0]["values"][0][1].toString());
      Services.texts.yearEnergy = yearEnergytoShow.round().toString() + ' kWh';
      // yearEnergytoShow = 12300001.0;
      if (yearEnergytoShow >= 100000.0) {
        Services.texts.yearEnergy =
            (yearEnergytoShow / 1000).round().toString() + 'MWh';
      }
    } else
      Services.texts.yearEnergy = '0 kWh';
  }

  Widget _report() => Column(children: [
        _cardRow([
          InkWell(
              child: _staticCard('assets/Day-icon.png', Services.texts.today,
                  Services.texts.todayEnergy, 0),
              onTap: () => Services.showCalender(
                  context: context,
                  selectedDate: (value) async {
                    await _setDayProduction(value);

                    setState(() {});
                  },
                  initialDate: _dateTime,
                  type: 0)),
          InkWell(
              child: _staticCard('assets/Calendar-icon-new.png',
                  Services.texts.month, Services.texts.monthEnergy, 0),
              onTap: () => Services.showCalender(
                  context: context,
                  selectedDate: (value) async {
                    await _setMonthProduction(value);

                    setState(() {});
                  },
                  initialDate: _dateTime,
                  type: 1)),
        ]),
        _cardRow([
          InkWell(
              child: _staticCard('assets/earth-path-icon.png',
                  Services.texts.year, Services.texts.yearEnergy, 1),
              onTap: () => Services.showCalender(
                  context: context,
                  selectedDate: (value) async {
                    await _setYearProduction(value);

                    setState(() {});
                  },
                  initialDate: _dateTime,
                  type: 2)),
          _staticCard('assets/solar-panel-icon.png', 'Lifetime',
              Services.texts.lifeTimeEnergy, 1),
        ]),
        _cardRow([
          _staticCard('assets/revenue-icon.png', 'Savings',
              Services.texts.lifeTimeRevenueValue, 1),
          _staticCard('assets/plant-capacity.png', Texts.capacity,
              Services.texts.capacityValue, 1),
        ])
      ]);

  void _deletePlant() {
    String url = Urls.ip +
        Urls.apiFolder +
        "fc=deletePlant&plantId=" +
        Services.texts.meterNo;
    NetworkHelper.getServerData(url);

    widget.deletePlant(Services.texts.meterNo);
    Navigator.pop(context);
  }
}
