import 'dart:async';

import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/screens/main/arraymeter.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:arraymeter/services/marqueText.dart';
import 'package:intl/intl.dart';

class OfflinePlantView extends StatefulWidget {
  List<PlantModel> noProduction;
  List<PlantModel> noCommunication;

  OfflinePlantView({this.noProduction, this.noCommunication});
  @override
  _OfflinePlantViewState createState() => _OfflinePlantViewState();
}

class _OfflinePlantViewState extends State<OfflinePlantView> {
  int popupindexForNoComm = 0;
  int popupindexForNoPro = 0;
  final GlobalKey _textKey = GlobalKey();
  double _height;
  double _width;
  Size _size;
  bool manageAble = false;
  List<PlantModel> _noProduction;
  List<PlantModel> _noCommunication;
  int currentTab;
  @override
  void initState() {
    _noProduction = widget.noProduction;
    currentTab = _noProduction.isEmpty ? 1 : 0;
    _noCommunication = widget.noCommunication;
    WidgetsBinding.instance.addPostFrameCallback((_) => getSizeAndPosition());
    super.initState();
  }

  getSizeAndPosition() {
    if (widget.noProduction.isNotEmpty || widget.noCommunication.isNotEmpty) {
      RenderBox _cardBox = _textKey.currentContext.findRenderObject();
      _height = _cardBox.size.height;
      _width = _cardBox.size.width;
      print("card height:${_cardBox.size.width}");
      setState(() {});
    }
  }

  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Services.colors.scaffoldColor,
        body: SingleChildScrollView(
          child: DefaultTabController(
              length: 2,
              initialIndex: _noProduction.isEmpty
                  ? 1
                  : 0, //This is for Strange Behaviour of RenderObject ..null
              child: Column(
                children: [
                  Container(
                    child: TabBar(
                      indicatorSize: TabBarIndicatorSize.tab,
                      indicatorColor: Services.colors.textColor,
                      labelColor: Services.colors.textColor,
                      labelStyle: TextStyle(
                        color: Services.colors.textColor,
                        fontFamily: Services.mont_med,
                        fontSize: 16,
                      ),
                      unselectedLabelStyle: TextStyle(
                        color: Services.colors.textColor,
                        fontFamily: Services.mont_med,
                        fontSize: 16,
                      ),
                      tabs: [
                        Tab(text: 'No Production'),
                        Tab(text: 'No Communication')
                      ],
                      onTap: (index) {
                        setState(() {
                          currentTab = index;
                        });
                      },
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  searchFilterBar(),
                  SizedBox(
                    height: 5,
                  ),
                  Container(
                      height: Services.size <= Services.iphone5Screen
                          ? Services.getHieght(context) * 0.64
                          : (Services.size >= Size(432.0, 816.0)
                              ? Services.getHieght(context) * 0.75
                              : (Services.size > Services.minimumSize
                                  ? Services.getHieght(context) * 0.72
                                  : Services.getHieght(context) * 0.68)),
                      width: Services.getWidth(context),
                      child: TabBarView(children: [
                        Center(
                          child: offlinePlants(_noProduction),
                        ),
                        Center(
                          child: offlinePlants(_noCommunication),
                        )
                      ])),
                ],
              )),
        ));
  }

  Widget searchFilterBar() => Container(
        width: Services.getWidth(context),
        margin: EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              width: Services.getWidth(context) * 0.75,
              child: SomeFixedUi.searchUi(onSearchTextChange: (text) {
                Timer(Duration(milliseconds: 100), () {
                  if (currentTab == 0) {
                    _noProduction = widget.noProduction
                        .where((element) => (element.name
                                .toLowerCase()
                                .contains(text.toLowerCase()) ||
                            element.id
                                .toString()
                                .toLowerCase()
                                .contains(text.toLowerCase()) ||
                            element.city
                                .toString()
                                .toLowerCase()
                                .contains(text.toLowerCase())))
                        .toList();
                    setState(() {});
                  } else {
                    _noCommunication = widget.noCommunication
                        .where((element) => (element.name
                                .toString()
                                .toLowerCase()
                                .contains(text.toLowerCase()) ||
                            element.id
                                .toString()
                                .toLowerCase()
                                .contains(text.toLowerCase()) ||
                            element.city
                                .toString()
                                .toLowerCase()
                                .contains(text.toLowerCase())))
                        .toList();
                    setState(() {});
                  }
                });
              }),
            ),
            PopupMenuButton(
              elevation: 3.2,
              initialValue:
                  currentTab == 0 ? popupindexForNoPro : popupindexForNoComm,
              child: Image.asset(
                Images.filterImage,
                width: 40,
                height: 40,
              ),
              onSelected: (int value) {
                print("Tab: " + currentTab.toString());
                setState(() {
                  if (currentTab == 0) {
                    popupindexForNoPro = value;
                    switch (value) {
                      case 0:
                        _noProduction = widget.noProduction;
                        break;
                      case 1:
                        _noProduction = widget.noProduction
                            .where((element) => element.capacity <= 30)
                            .toList();
                        break;
                      case 2:
                        _noProduction = widget.noProduction
                            .where((element) =>
                                element.capacity > 30 && element.capacity <= 60)
                            .toList();
                        break;
                      case 3:
                        _noProduction = widget.noProduction
                            .where((element) => element.capacity >= 60)
                            .toList();
                        break;
                    }
                  } else {
                    popupindexForNoComm = value;
                    switch (value) {
                      case 0:
                        _noCommunication = widget.noCommunication;
                        break;
                      case 1:
                        _noCommunication = widget.noCommunication
                            .where((element) => element.capacity <= 30)
                            .toList();
                        break;
                      case 2:
                        _noCommunication = widget.noCommunication
                            .where((element) =>
                                element.capacity > 30 && element.capacity <= 60)
                            .toList();
                        break;
                      case 3:
                        _noCommunication = widget.noCommunication
                            .where((element) => element.capacity >= 60)
                            .toList();
                        break;
                    }
                  }
                });
                print("popIndex-NoCommu: " + popupindexForNoComm.toString());
                print("popIndex-NoPro: " + popupindexForNoPro.toString());
              },
              color: Services.colors.scaffoldColor,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0)),
              itemBuilder: (BuildContext context) {
                return [
                  PopupMenuItem(
                    value: 0,
                    child: Center(child: Text("All")),
                  ),
                  PopupMenuItem(
                    value: 1,
                    child: Center(child: Text("1-30 kW")),
                  ),
                  PopupMenuItem(
                    value: 2,
                    child: Center(child: Text("31-60 kW")),
                  ),
                  PopupMenuItem(
                    value: 3,
                    child: Center(child: Text(">60 kW")),
                  )
                ];
              },
            ),
          ],
        ),
      );

  Widget offlinePlants(List<PlantModel> _plants) => Container(
        height: _size >= Size(432.0, 816.0)
            ? Services.getHieght(context) * 0.75
            : Services.getHieght(context) * 0.67,
        child: GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            children: gridItems(_plants, context)),
      );

  List<Widget> gridItems(List<PlantModel> _plantList, BuildContext context) {
    List<Widget> items = [];

    for (PlantModel p in _plantList) {
      items.add(InkWell(
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ArrayData(
                        p,
                        manageAble,
                      )));
        },
        child: Stack(
          key: _plantList.indexOf(p) == 0 ? _textKey : null,
          children: [
            Image.asset(
              "assets/listcard_background.png",
              fit: BoxFit.fill,
            ),
            Positioned(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: _width != null ? _width / 1.5 : 150,
                    child: MarqueeWidget(
                      child: Text(
                        p.name,
                        style: TextStyle(
                          fontFamily: Services.mont_med,
                          color: Services.colors.textColor,
                          fontSize:
                              Services.size <= Services.iphone5Screen ? 14 : 16,
                        ),
                      ),
                    ),
                  ),
                  Text(
                      p.lastCommunication != null
                          ? DateFormat("MM-dd-yyyy").format(p.lastCommunication)
                          : "",
                      style: TextStyle(
                          fontFamily: Services.mont_regular,
                          color: Services.colors.textColor)),
                ],
              ),
              left: Services.getWidth(context) * 0.05,
              top: Services.getHieght(context) * 0.02,
            ),
            Positioned(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    width: Services.getWidth(context) * 0.27,
                    child: Text(
                      p.todayEnergy != null
                          ? p.todayEnergy.toStringAsFixed(1)
                          // .padLeft(6, '0')
                          : "",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontFamily: Services.digitalFont,
                          fontSize: 30,
                          color: Colors.white),
                    ),
                  ),
                  Text(" kWh",
                      style: TextStyle(
                          fontFamily: Services.mont_regular,
                          fontSize: _size > Services.minimumSize ? 15 : 13,
                          color: Colors.white))
                ],
              ),
              top: _height != null
                  ? MediaQuery.of(context).orientation == Orientation.landscape
                      ? _height / 1.4
                      : _height / 2.24
                  : 20,
              left: Services.getWidth(context) * 0.06,
            ),
            Positioned(
              child: Container(
                  child: CircleAvatar(
                      backgroundColor: Services.colors.textColor,
                      radius: 16,
                      child: CircleAvatar(
                          radius: 15,
                          backgroundColor:
                              Services.statusColor(p.plantStatus)))),
              top: MediaQuery.of(context).orientation == Orientation.landscape
                  ? Services.getWidth(context) * 0.02
                  : Services.getHieght(context) * 0.02,
              right: MediaQuery.of(context).orientation == Orientation.landscape
                  ? Services.getWidth(context) * 0.09
                  : Services.getWidth(context) * 0.03,
            ),
            Positioned(
              child: Text(
                p.id,
                style: TextStyle(
                  fontFamily: Services.mont_regular,
                  fontSize: 15,
                  color: Services.colors.textColor,
                ),
              ),
              bottom:
                  MediaQuery.of(context).orientation == Orientation.landscape
                      ? Services.getHieght(context) * 0.23
                      : Services.getHieght(context) * 0.05,
              left: Services.getWidth(context) * 0.05,
            ),
            Positioned(
              child: Column(
                children: [
                  Text(
                    "${p.capacity} kW",
                    style: TextStyle(
                        color: Services.colors.textColor,
                        fontFamily: Services.mont_regular,
                        fontSize: 12),
                  ),
                  Text(Texts.capacity,
                      style: TextStyle(
                          color: Services.colors.textColor,
                          fontFamily: Services.mont_regular,
                          fontSize: 12))
                ],
              ),
              bottom:
                  MediaQuery.of(context).orientation == Orientation.landscape
                      ? Services.getHieght(context) * 0.2
                      : Services.getHieght(context) * 0.03,
              right: MediaQuery.of(context).orientation == Orientation.landscape
                  ? Services.getWidth(context) * 0.09
                  : Services.getWidth(context) * 0.03,
            ),
          ],
        ),
      ));
    }

    return items;
  }
}
