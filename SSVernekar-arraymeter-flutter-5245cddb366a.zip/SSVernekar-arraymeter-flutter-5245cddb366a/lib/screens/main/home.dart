import 'dart:async';
import 'dart:io';

import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/screens/main/login.dart';
import 'package:arraymeter/screens/main/support.dart';
import 'package:arraymeter/screens/plantmanagement/plantList.dart';
import 'package:arraymeter/screens/ticketing/ticket%20summury.dart';
import 'package:arraymeter/screens/ticketing/ticketList.dart';
import 'package:arraymeter/screens/userManagement/edit_profile_details.dart';
import 'package:arraymeter/screens/userManagement/userList.dart';

import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'package:arraymeter/screens/main/offlinePlant.dart';
import '../../services/constants.dart';
import 'dashboard.dart';
import 'installerPants.dart';
import 'plantlist.dart';

// ignore: must_be_immutable
class HomePageView extends StatefulWidget {
  List<PlantModel> plants = [];

  HomePageView(this.plants);

  @override
  HomePageViewState createState() => HomePageViewState();
}

class HomePageViewState extends State<HomePageView> {
  int _index;
  List _installerPages = [];
  List _plantOwnerPages = [];
  int totalPlant;
  List _bottomPage = [];
  String title = "All Plants";
  bool _loading = false;
  double _estimateLoss;
  double _totalKW;
  double _todayProduction;
  double _monthlyProd;
  double _yearlyProd;
  double _lifeTimeProd;

  String allPlants = "All Plants";
  String noProduction = "No Production";
  String noCommunication = "No Communication";
  Map installerDetails = {
    "role": " ",
    "email": " ",
    "name": "",
    "Phone": "",
    "Address": "",
    "userId": ""
  };

  setUp() async {
    _estimateLoss = 0;
    _totalKW = 0;
    _todayProduction = 0;
    _monthlyProd = 0;
    _lifeTimeProd = 0;
    _todayProduction = 0;
    totalPlant = 0;
    _yearlyProd = 0;

    _allList = widget.plants;

    _noProduction = widget.plants
        .where((element) => element.plantStatus == PlantStatus.noProduction)
        .toList();

    _noCommunication = widget.plants
        .where((element) => element.plantStatus == PlantStatus.noCommunication)
        .toList();

    _online = widget.plants
        .where((element) => element.plantStatus == PlantStatus.online)
        .toList();
    _offline = widget.plants
        .where((element) => element.plantStatus != PlantStatus.online &&  element.plantStatus!=PlantStatus.idle)
        .toList();

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    //setting userDetails

    USerProfile.id = sharedPreferences.getStringList('userData')[0];
    USerProfile.role =
        Services.textTORole(sharedPreferences.getStringList('userData')[1]);

    USerProfile.email = sharedPreferences.getStringList('userData')[2];
    USerProfile.name = sharedPreferences.getStringList('userData')[3];
    USerProfile.orgId = sharedPreferences.getStringList('userData')[4];
    navbarItems = Services.bottomBarItems(pos: _index);
    //setting fleet overview details

    _noCommunication.forEach((element) {
      _estimateLoss += element.capacity;
    });
    _noProduction.forEach((element) {
      _estimateLoss += element.capacity;
    });

    _allList.forEach((element) {
      if (element.plantStatus != PlantStatus.idle) {
        _totalKW += element.capacity;
        totalPlant = _allList
            .where((element) => element.plantStatus != PlantStatus.idle)
            .toList()
            .length;
        _todayProduction += element.todayEnergy;
        _monthlyProd += element.monthlyEnergy;
        _yearlyProd += element.yearEnergy;
        _lifeTimeProd += element.lifeTimeEnergy;
      }
    });

    if (USerProfile.role == Role.plantOwner) {
      String url = Urls.ip +
          Urls.apiFolder +
          "fc=getInstallerinfo&UserId=" +
          USerProfile.orgId;
      var response = await NetworkHelper.getServerData(url);
      installerDetails = response;
    }
    setState(() {});
  }

  final GlobalKey<ScaffoldState> _skafoldKey = GlobalKey<ScaffoldState>();

  List<PlantModel> _allList = [];
  List<PlantModel> _noProduction = [];
  List<PlantModel> _noCommunication = [];
  List<PlantModel> _online = [];
  List<PlantModel> _offline = [];
  List<BottomNavigationBarItem> navbarItems = List<BottomNavigationBarItem>();
  List<PlantModel> _showingList = [];

  _refresh() async {
    List<PlantModel> _plants = [];

    //api of get plants has to be call
    String loginUrl =
        Urls.ip + Urls.apiFolder + "fc=getPlants&UserId=" + USerProfile.id;
    var data = await NetworkHelper.getServerData(loginUrl);
    if (data['plants'] != false)
      for (var plantData in data['plants']) {
        _plants.add(PlantModel.fromJson(plantData));
      }

    widget.plants = _plants;
    setUp();
  }

  Timer timer;

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  void initState() {
    _index = 0;
    setUp();
    _showingList = _allList;

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);

    timer = Timer.periodic(Duration(minutes: 5), (Timer t) => _refresh());
    navbarItems = Services.bottomBarItems(pos: _index);
    super.initState();
  }

  _drawerTile(
    String title,
    Function onPressed,
  ) =>
      GestureDetector(
        onTap: () => onPressed(),
        child: Container(
          height: 50,
          width: double.infinity,
          padding: EdgeInsets.only(top: 20),
          child: Text(
            title ?? "",
            style: TextStyle(color: Services.colors.textColor, fontSize: 17),
          ),
        ),
      );

  _addPlant(PlantModel newPlant) {
    newPlant.todayEnergy = 0.0;

    widget.plants.add(newPlant);

    setState(() {});
  }

  _updatePlant(PlantModel newPlant) {
    widget.plants[widget.plants.indexOf(newPlant)] = newPlant;
    setState(() {});
  }

  _deletePlant(String meterNumber) {
    widget.plants.removeWhere((element) => element.id == meterNumber);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    Services.size = MediaQuery.of(context).size;

    // print("enable tickets: ${USerProfile.ticketManagement}");
    // print("enable manage: ${USerProfile.ticketManagement}");

    _plantOwnerPages = [
      PlantListView(
        plantList: _showingList,
        title: title,
      ),
      TicketList(
        plants: _allList,
      ),
      Support(
        name: installerDetails['name'],
        email: installerDetails['email'],
        contact: installerDetails['Phone'],
        address: installerDetails['Address'],
      ),
      EditProfile()
    ];
    _installerPages = [
      InstallerDashBoard(
        totalPlants: totalPlant,
        noProduction: _noProduction.length,
        estimatedLoss: _estimateLoss,
        noCommunication: _noCommunication.length,
        online: _online.length,
        lifetimeP: _lifeTimeProd,
        monthlyP: _monthlyProd,
        todayP: _todayProduction,
        totalCapacity: _totalKW,
        yearlyP: _yearlyProd,
      ),
      InstallerPlantsView(
        plantList: _showingList,
        noProduction: _noProduction,
        noCommunication: _noCommunication,
        title: title,
        manageAble: false,
      ),
      TicketSummary(plants: _allList),
      UserList(_allList),
      PlantListToManage(
        _allList,
        addNewPlant: _addPlant,
        editPlant: _updatePlant,
        deletePlant: _deletePlant,
      ),
      EditProfile(),
      OfflinePlantView(
        noCommunication: _noCommunication,
        noProduction: _noProduction,
      ),
    ];
    int navBarLoc = _index;
    _bottomPage =
        USerProfile.role == Role.Installer ? _installerPages : _plantOwnerPages;

    return Scaffold(
      key: _skafoldKey,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        centerTitle: true,
        actions: [SomeFixedUi.appBarLogo()],
        title: Text(
          "ArrayMeter",
          style: TextStyle(fontSize: 18),
        ),

        // Column(
        //   children: [
        //
        //     Text("Plant-list", style: TextStyle(fontSize: 16))
        //   ],
        // )
        //
      ),
      body: Stack(
        children: [
          _loading
              ? Container(
                  color: Services.colors.scaffoldColor,
                )
              : _bottomPage[_index],
          MediaQuery.of(context).orientation == Orientation.landscape
              ? Container()
              : Align(
                  alignment: Alignment.bottomCenter,
                  child: BottomNavigationBar(
                      elevation: 8,
                      showSelectedLabels: false,
                      showUnselectedLabels: true,
                      type: BottomNavigationBarType.fixed,
                      items: navbarItems,
                      onTap: (indexValue) async {
                        setState(() {
                          navBarLoc = indexValue;
                          bool valid = (USerProfile.role == Role.Installer)
                              ? (USerProfile.ticketManagement == false)
                                  ? (indexValue == 3)
                                      ? false
                                      : true
                                  : true
                              : true;
                          if (valid)
                            navbarItems =
                                Services.bottomBarItems(pos: navBarLoc);
                          // print('HomeIndex: ' + navBarLoc.toString());
                          _loading = true;
                        });
                        Timer(Duration(milliseconds: 100), () {
                          if (USerProfile.role == Role.plantOwner) {
                            setState(() {
                              switch (indexValue) {
                                case 0:
                                  _showingList = _allList;
                                  _index = 0;
                                  title = allPlants;
                                  break;
                                case 1:
                                  //After ticketing System

                                  _index = 0;
                                  _showingList = _offline;
                                  title = "Offline Plants";

                                  // _showingList = _noProduction;
                                  // _index = 0;
                                  // title = noProduction;

                                  break;

                                case 2:
                                  //After ticketing System
                                  if (USerProfile.ticketManagement == true) {
                                    _index = 1;
                                  } else {
                                    SomeFixedUi.showAlert(
                                      context,
                                      "Currently you have no access to ticket section",
                                    );
                                  }
                                  // _index = 1;

                                  // _showingList = _noCommunication;
                                  // _index = 0;
                                  // title = noCommunication;

                                  break;
                                case 3:
                                  _skafoldKey.currentState.openEndDrawer();

                                  break;
                              }

                              _loading = false;
                            });
                          } else {
                            setState(() {
                              switch (indexValue) {
                                case 0:
                                  _index = 0;
                                  break;
                                case 1:
                                  _index = 1;
                                  _showingList = _allList;
                                  title = allPlants;

                                  break;
                                case 2:
                                  //After ticketing System
                                  _index = 6;
                                  _showingList = _offline;
                                  title = "Offline-Plants";

                                  // _index = 1;
                                  // _showingList = _noProduction;
                                  // title = noProduction;

                                  break;

                                case 3:
                                  //After ticketing System

                                  if (USerProfile.ticketManagement == true) {
                                    _index = 2;
                                  } else {
                                    SomeFixedUi.showAlert(
                                      context,
                                      "Currently you have no access to ticket section",
                                    );
                                  }

                                  // _index = 1;
                                  // _showingList = _noCommunication;
                                  // title = noCommunication;

                                  break;

                                case 4:
                                  _skafoldKey.currentState.openEndDrawer();
                                  break;
                              }
                            });

                            _loading = false;
                          }
                        });
                      }),
                )
        ],
      ),
      endDrawer: Drawer(
        child: Container(
          color: Services.colors.scaffoldColor,
          width: Services.getWidth(context) * 0.3,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 40.0, left: 0, bottom: 10),
                child: Container(
                  padding: EdgeInsets.only(left: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(USerProfile.name ?? "",
                          style: TextStyle(
                              color: Services.colors.textColor, fontSize: 20)),
                      Container(
                        height: 20,
                      ),
                      _drawerTile("My Profile", () {
                        setState(() {
                          _index = USerProfile.role == Role.Installer ? 5 : 3;
                        });

                        Navigator.pop(context);
                      }),
                    ],
                  ),
                ),
              ),
              Divider(
                color: Services.colors.textColor,
                thickness: 1,
              ),
              Container(
                padding: EdgeInsets.only(left: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    USerProfile.role == Role.Installer
                        // && USerProfile.management
                        ? _drawerTile("Manage Users", () {
                            Navigator.pop(context);
                            if (USerProfile.management == true) {
                              setState(() {
                                _index = 3;
                              });
                            } else {
                              SomeFixedUi.showAlert(context,
                                  "Currently You Have No Access on This Manage User Section");
                            }
                          })
                        : Container(),
                    USerProfile.role == Role.Installer
                        // && USerProfile.management

                        ? _drawerTile("Manage Plants", () {
                            Navigator.pop(context);
                            if (USerProfile.management == true) {
                              _index = 4;
                            } else {
                              SomeFixedUi.showAlert(context,
                                  "Currently You Have No Access on This Manage Plants Section");
                            }
                            setState(() {});
                          })
                        : Container(),
                    if (USerProfile.role == Role.plantOwner)
                      _drawerTile("Support", () {
                        setState(() {
                          _index = 2;
                        });
                        Navigator.pop(context);
                      }),
                    _drawerTile("Logout", () async {
                      SharedPreferences sp =
                          await SharedPreferences.getInstance();

                      await sp.clear();

                      if (USerProfile.role == Role.plantOwner &&
                          Platform.isAndroid) await Workmanager.cancelAll();

                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => LoginScreen()));
                    }),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
