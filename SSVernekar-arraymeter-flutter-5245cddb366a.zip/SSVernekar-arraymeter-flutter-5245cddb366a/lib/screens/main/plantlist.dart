import 'dart:async';

import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/marqueText.dart';

import 'arraymeter.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:intl/intl.dart';

// ignore: must_be_immutable
class PlantListView extends StatefulWidget {
  String title;
  List<PlantModel> plantList = [];

  PlantListView({this.title, this.plantList});

  @override
  _PlantListViewState createState() => _PlantListViewState();
}

class _PlantListViewState extends State<PlantListView> {
  List<PlantModel> _plantList = [];

  @override
  void initState() {
    _plantList = widget.plantList;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // resizeToAvoidBottomPadding: false,
      backgroundColor: Services.colors.scaffoldColor,
      body: Column(
        children: [
          Container(height: 8),
          Text(
            widget.title,
            style: Services.screenHeadingTextStyle,
          ),
          Container(height: 5),
          Container(
              width: Services.getWidth(context),
              margin: EdgeInsets.symmetric(horizontal: 20),
              height: 40,

              // decoration:  BoxDecoration(
              //     color: Colors.white,
              //     shape: BoxShape.rectangle,
              //     borderRadius: BorderRadius.all(
              //         Radius.circular(40.0)
              //
              //
              //
              //
              //
              //
              //
              //
              //     ),border: Border.all(width: 1,color: Services.colors.textColor)),

              child: SomeFixedUi.searchUi(onSearchTextChange: (searchTexts) {
                Timer(Duration(milliseconds: 100), () {
                  setState(() {
                    _plantList = widget.plantList
                        .where((element) =>
                            (element.name
                                    .toLowerCase()
                                    .contains(searchTexts.toLowerCase()) ||
                                element.id
                                    .toString()
                                    .toLowerCase()
                                    .contains(searchTexts.toLowerCase())) ||
                            element.city
                                .toString()
                                .toLowerCase()
                                .contains(searchTexts.toLowerCase()))
                        .toList();
                  });
                });
              })),
          Expanded(
            // height: Services.getHieght(context) * 0.6,
            child: ListView.builder(
                padding: EdgeInsets.only(bottom: 60),
                itemCount: _plantList.length,
                itemBuilder: (BuildContext context, index) {
                  return InkWell(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ArrayData(
                                    _plantList[index],
                                    false,
                                  )));
                    },
                    child: Center(
                      child: Stack(
                        children: [
                          Image.asset(
                            "assets/listcard_background.png",
                            width: Services.getWidth(context) * 0.8,
                            fit: BoxFit.fill,
                            height: 300,
                          ),
                          Positioned(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: Services.getWidth(context) * 0.55,
                                  child: MarqueeWidget(
                                    child: Text(
                                      _plantList[index].name != null
                                          ? "${_plantList[index].name}   "
                                          : "",
                                      style: TextStyle(
                                        fontFamily: Services.mont_med,
                                        color: Services.colors.textColor,
                                        fontSize: 24,
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                    _plantList[index].lastCommunication != null
                                        ? DateFormat("MM-dd-yyyy").format(
                                            _plantList[index].lastCommunication)
                                        : "null",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontFamily: Services.mont_regular,
                                        color: Services.colors.textColor))
                              ],
                            ),
                            left: Services.getWidth(context) * 0.08,
                            top: 20,
                          ),
                          Positioned(
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Container(
                                  width: Services.getWidth(context) * 0.4,
                                  child: Text(
                                    _plantList[index]
                                        .todayEnergy
                                        .toStringAsFixed(1),
                                    textAlign: TextAlign.right,
                                    style: TextStyle(
                                        fontFamily: Services.digitalFont,
                                        fontSize: 40,
                                        color: Colors.white),
                                  ),
                                ),
                                Text("  kWh",
                                    style: TextStyle(
                                        fontFamily: Services.mont_regular,
                                        fontSize: 17,
                                        color: Colors.white))
                              ],
                            ),
                            top: 135,
                            left: Services.getWidth(context) * 0.1,
                          ),
                          Positioned(
                            child: Container(
                                child: CircleAvatar(
                                    backgroundColor: Services.colors.textColor,
                                    radius: 25,
                                    child: CircleAvatar(
                                      radius: 24,
                                      backgroundColor: Services.statusColor(
                                          _plantList[index].plantStatus),
                                    ))),
                            top: 20,
                            right: 20,
                          ),
                          Positioned(
                            child: Text(
                              _plantList[index].id,
                              style: TextStyle(
                                fontFamily: Services.mont_regular,
                                fontSize: 17,
                                color: Services.colors.textColor,
                              ),
                            ),
                            bottom: 50,
                            left: Services.getWidth(context) * 0.08,
                          ),
                          Positioned(
                            child: Column(
                              children: [
                                Text(
                                  "${_plantList[index].capacity} kW",
                                  style: TextStyle(
                                      color: Services.colors.textColor,
                                      fontFamily: Services.mont_regular,
                                      fontSize: 16),
                                ),
                                Text(Texts.capacity,
                                    style: TextStyle(
                                        color: Services.colors.textColor,
                                        fontFamily: Services.mont_regular,
                                        fontSize: 15))
                              ],
                            ),
                            bottom: 30,
                            right: 20,
                          ),
                        ],
                      ),
                    ),
                  );
                }),
          )
        ],
      ),
    );
  }
}
