import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class Support extends StatelessWidget {
  String name, email, contact, address;
  Support({this.name, this.address, this.email, this.contact});

  TextStyle cardTextStyle = TextStyle(
      color: Services.colors.textColor,
      fontFamily: Services.mont_regular,
      fontSize: 18);

  Widget _row(key, value) {
    return Padding(
      padding: EdgeInsets.only(left: 20.0, bottom: 10),
      child: Row(children: [
        Container(
          width: 85,
          child: Text("$key", style: cardTextStyle),
        ),
        Text(":  "),
        Expanded(
          child: Text(
            value ?? "",
            style: cardTextStyle,
          ),
        )
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
          Card(
              margin: EdgeInsets.all(20),
              shape: RoundedRectangleBorder(
                side: BorderSide(color: Colors.green, width: 1.0),
                borderRadius: BorderRadius.circular(30.0),
              ),
              color: Colors.white,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                        padding: EdgeInsets.only(left: 20, top: 15, bottom: 5),
                        child: Text('Installer Details', style: cardTextStyle)),
                    Divider(
                      color: Colors.green,
                      thickness: 1,
                    ),
                    _row("Name", name),
                    _row("Contact", contact),
                    _row("Email", email),
                    // _row("Address", address),
                    Container(height: 10)
                  ])),
        ])));
  }
}
