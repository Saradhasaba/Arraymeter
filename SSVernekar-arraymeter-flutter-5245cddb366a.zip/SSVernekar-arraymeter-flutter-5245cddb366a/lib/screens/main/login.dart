import 'dart:io';

import 'package:arraymeter/NetworkModule/network.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/screens/main/password_recovery.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/notifications.dart';
import 'package:arraymeter/services/service.dart';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:workmanager/workmanager.dart';

import 'home.dart';

class LoginScreen extends StatefulWidget {
  @override
  LoginScreenState createState() => LoginScreenState();
}

class LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  SharedPreferences sP;
  BuildContext _context;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  int _getInitialDelay() {
    final _currentTime = DateTime.now();

    final notificationTime = DateTime(
        _currentTime.year, _currentTime.month, _currentTime.day + 1, 7, 0);

    final initialDelay = notificationTime.difference(_currentTime).inMinutes;

    return initialDelay;
  }

  // ignore: missing_return
  Future<List<PlantModel>> login() async {
    if (_emailController.text.trim().isNotEmpty &&
        _passwordController.text.isNotEmpty) {
      List<PlantModel> _plants = [];

      String loginUrl = Urls.ip +
          Urls.apiFolder +
          "email=" +
          _emailController.text +
          "&password=" +
          _passwordController.text +
          "&fc=login";

      var data = await NetworkHelper.getServerData(loginUrl);

      if (data['message'] != "Invalid Login!") {



        sP.setStringList("userData", [
          data['userId'],
          data['role'],
          data['email'],
          data['name'],
          data["orgId"],

        ]);

         USerProfile.ticketManagement=data['ticket']=="true"?true:false;
        USerProfile.management=data['management']=="true"?true:false;

        if (data['plants'] != false)
          for (var plantData in data['plants']) {
            _plants.add(PlantModel.fromJson(plantData));
          }

        return _plants;
      } else
        return showDialog(
            context: _context,
            builder: (context) {
              return AlertDialog(
                // backgroundColor: Services.colors.scaffoldColor,
                content: Text(
                  'Username or Password Does Not Match',
                  textAlign: TextAlign.center,
                ),
              );
            });
    } else
      _scaffoldKey.currentState.showSnackBar(new SnackBar(
          backgroundColor: Colors.white,
          content: new Text(
            'Please Enter email and password',
            style: TextStyle(color: Colors.red),
          )));
  }

  sp() async {
    sP = await SharedPreferences.getInstance();
  }

  @override
  void initState() {
    sp();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _context = context;
    return Scaffold(
        key: _scaffoldKey,
        body: SingleChildScrollView(
          child: Container(
            height: Services.getHieght(context),
            width: Services.getWidth(context),
            child: Stack(children: <Widget>[
              new Image.asset(
                'assets/landing-1.jpg',
                height: Services.getHieght(context),
                width: Services.getWidth(context),
                fit: BoxFit.cover,
              ),
              Center(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                    Container(
                      height: Services.getHieght(context) * 0.13,
                    ),
                    Container(
                      width: 160,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10.0),
                        child: new Image.asset(
                          'assets/logo.png',
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 10),
                      height: 282,
                      child: Card(
                        color: Color.fromRGBO(0, 50, 0, 140),
                        shadowColor: Colors.black,
                        elevation: 0,
                        margin: EdgeInsets.fromLTRB(15, 15, 5, 15),
                        shape: ContinuousRectangleBorder(
                            borderRadius: BorderRadius.circular(25.0)),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 25.0, right: 25),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  //email edit text
                                  width: Services.getWidth(context) * 0.73,
                                  margin: const EdgeInsets.only(top: 30.0),
                                  child: new TextFormField(
                                    controller: _emailController,
                                    keyboardType: TextInputType.emailAddress,
                                    autofocus: false,
                                    style: new TextStyle(
                                        fontFamily: Services.mont_regular,
                                        color: Services.colors.textColor),
                                    decoration: InputDecoration(
                                      hintText: 'Email',
                                      hintStyle: TextStyle(
                                          fontFamily: Services.mont_regular,
                                          color: Services.colors.textColor),
//                                    errorText: _validate_user ? 'Enter Usernme' : null,
                                      fillColor: Colors.white,
                                      filled: true,
                                      contentPadding: EdgeInsets.fromLTRB(
                                          25.0, 10.0, 20.0, 10.0),
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(32.0)),
                                    ),
                                  ),
                                ),
                                Container(height: 20),
                                Container(
                                  //password edit text
                                  width: Services.getWidth(context) * 0.73,

                                  child: new TextFormField(
                                    controller: _passwordController,
                                    autofocus: false,
                                    style: new TextStyle(
                                        fontFamily: 'Montserrat',
                                        color: Services.colors.textColor),
                                    obscureText: true,
                                    decoration: InputDecoration(
                                      hintText: 'Password',
                                      hintStyle: TextStyle(
                                          fontFamily: 'Montserrat',
                                          color: Services.colors.textColor),
//                                    errorText: _validate_pass ? 'Enter password' : null,
                                      fillColor: Colors.white,
                                      filled: true,
                                      contentPadding: EdgeInsets.fromLTRB(
                                          25.0, 10.0, 20.0, 10.0),
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(32.0)),
                                    ),
                                  ),
                                ),
                                Container(
                                    height: 45,
                                    width: 130,
                                    margin: const EdgeInsets.fromLTRB(
                                        10, 30, 10, 5),
                                    child: RaisedButton(
                                        textColor: Colors.white,
                                        color: Services.colors.appBarColor,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(30)),
                                        child: const Text('  Login  ',
                                            style: TextStyle(
                                                fontSize: 20,
                                                color: Colors.white)),
                                        onPressed: () async {
                                          var connectivityResult =
                                              await (Connectivity()
                                                  .checkConnectivity());

                                          if (connectivityResult ==
                                                  ConnectivityResult.mobile ||
                                              connectivityResult ==
                                                  ConnectivityResult.wifi) {
                                            await login().then((value) async {
                                              if (value != null) {
                                                // print(sP
                                                //     .getStringList("userData"));
//!= installer
                                                if (sP.getStringList(
                                                        "userData")[1] !=
                                                    "Installer") {

                                                  List<String> _plantIds = [];

                                                  value.forEach((element) {
                                                    _plantIds.add(element.id);
                                                  });
                                                  sP.setStringList(
                                                      "plantIds", _plantIds);
                                                  if (Platform.isAndroid) {
                                                    Workmanager.initialize(
                                                      callbackDispatcher,
                                                      isInDebugMode: false,
                                                    );

                                                    Workmanager.registerPeriodicTask(
                                                        "1", "notificationTask",
                                                        constraints:
                                                            Constraints(
                                                          networkType:
                                                              NetworkType
                                                                  .connected,
                                                        ),
                                                        frequency:
                                                            Duration(hours: 12),
                                                        initialDelay: Duration(
                                                            minutes:
                                                                _getInitialDelay())
                                                                );
                                                  } else
                                                    Workmanager.initialize(
                                                        callbackDispatcher,
                                                        isInDebugMode: false);
                                                }

                                                Navigator.pushReplacement(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            HomePageView(
                                                                value)));
                                              }
                                            });
                                          }

                                          //no internet
                                          else
                                            _scaffoldKey.currentState
                                                .showSnackBar(new SnackBar(
                                                    backgroundColor:
                                                        Colors.white,
                                                    content: new Text(
                                                        'Please check your internet connection',
                                                        style: TextStyle(
                                                            color:
                                                                Colors.red))));
                                        })),
                              ]),
                        ),
                      ),
                    ),
                  ])),
              Align(
                alignment: Alignment.bottomCenter,
                child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => PasswordRecovery()),
                      );
                    },
                    child: Container(
                      color: Colors.black12,
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        "Forgot Password",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontFamily: Services.mont_med),
                      ),
                    )),
              )
            ]),
          ),
        ));
  }

//forgot password
//   _launchURL() async {
//     String url = Urls.ip + "forgot_password.php";
//     if (await canLaunch(url)) {
//       await launch(url);
//     } else {
//       throw 'Could not launch $url';
//     }
//   }
// }

}
