import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class InstallerDashBoard extends StatelessWidget {
  int totalPlants, online, noProduction, noCommunication;
  double estimatedLoss, totalCapacity, todayP, monthlyP, yearlyP, lifetimeP;

  InstallerDashBoard(
      {this.noCommunication,
      this.online,
      this.noProduction,
      this.estimatedLoss,
      this.totalPlants,
      this.lifetimeP,
      this.monthlyP,
      this.todayP,
      this.totalCapacity,
      this.yearlyP});
  String monthlyUnit = "kWh";
  unitConversion() {
    if (monthlyP >= 100000.0) {
      monthlyP = monthlyP / 1000.0;
      monthlyUnit = "MWh";
    }
  }

  Widget _detailstable(String imagePath, double value, String text,
          BuildContext context, int fleet) =>
      Container(
        margin: EdgeInsets.only(bottom: 20),
        child: Row(
          children: [
            Image.asset(
              imagePath,
              height: Services.size >= Size(428.0, 816.0)
                  ? 70
                  : (Services.size > Services.minimumSize ? 60 : 50),
              width: Services.size >= Size(428.0, 816.0)
                  ? 70
                  : (Services.size > Services.minimumSize ? 60 : 50),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 30.0),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      fleet == 1
                          ? value
                              .toStringAsFixed(1)
                              .replaceAllMapped(reg, mathFunc)
                          : value.toInt().toString().padLeft(2, '0'),
                      style: TextStyle(
                          fontSize: Services.size >= Size(428.0, 816.0)
                              ? 50
                              : (Services.size > Services.minimumSize
                                  ? 44
                                  : 30),
                          color: Services.colors.textColor),
                    ),
                    Text(text,
                        style: TextStyle(
                            fontSize: Services.size <= Services.iphone5Screen
                                ? 12
                                : 16,
                            color: Services.colors.textColor))
                  ]),
            )
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    unitConversion();
    return Scaffold(
        backgroundColor: Services.colors.scaffoldColor,
        body: SingleChildScrollView(
          child: DefaultTabController(
            length: 2,
            child: Column(
              children: [
                Container(
                  child: TabBar(
                    indicatorSize: TabBarIndicatorSize.tab,
                    indicatorColor: Services.colors.textColor,
                    labelColor: Services.colors.textColor,
                    labelStyle: TextStyle(
                      color: Services.colors.textColor,
                      fontFamily: Services.mont_med,
                      fontSize: 18,
//                            fontFamily: Constants.mont_regular
                    ),
                    unselectedLabelStyle: TextStyle(
                      color: Services.colors.textColor,
                      fontFamily: Services.mont_med,
                      fontSize: 18,
//                            fontFamily: Constants.mont_regular
                    ),
                    tabs: [
                      Tab(
                        child: Text(
                          'Fleet Status',
                        ),
                      ),
                      Tab(
                          child: Text(
                        'Fleet Summary',
                      )),
                    ],
                  ),
                ),
                Container(
                  height: Services.size <= Services.iphone5Screen
                      ? Services.getHieght(context) * 0.64
                      : (Services.size >= Size(432.0, 816.0)
                          ? Services.getHieght(context) * 0.75
                          : (Services.size > Services.minimumSize
                              ? Services.getHieght(context) * 0.70
                              : Services.getHieght(context) * 0.68)),
                  width: Services.getWidth(context),
                  child: TabBarView(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.rectangle,
                            borderRadius:
                                BorderRadius.all(Radius.circular(40.0)),
                            border: Border.all(
                                width: 1, color: Services.colors.textColor)),
                        margin: EdgeInsets.only(top: 7, right: 10, left: 10),
                        padding: EdgeInsets.symmetric(
                            horizontal: 20,
                            vertical:
                                Services.size > Services.minimumSize ? 20 : 10),
                        width: Services.getWidth(context),
                        child: SingleChildScrollView(
                          child: Column(
                            children: [
                              _detailstable(
                                  Images.fleetOverViewImages.totalPlants,
                                  totalPlants.toDouble(),
                                  "Total Plants",
                                  context,
                                  0),
                              _detailstable(Images.fleetOverViewImages.online,
                                  online.toDouble(), "Online", context, 0),
                              _detailstable(
                                  Images.fleetOverViewImages.noProduction,
                                  noProduction.toDouble(),
                                  "No Production",
                                  context,
                                  0),
                              _detailstable(
                                  Images.fleetOverViewImages.noCommunication,
                                  noCommunication.toDouble(),
                                  "No Communication",
                                  context,
                                  0),
                              _detailstable(
                                  Images.fleetOverViewImages.estimateLoss,
                                  estimatedLoss,
                                  "Capacity Impacted (kW)",
                                  context,
                                  1),
                            ],
                          ),
                        ),
                      ),



                      Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.rectangle,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(40.0)),
                              border: Border.all(
                                  width: 1, color: Services.colors.textColor)),
                          margin: EdgeInsets.only(top: 10, right: 10, left: 10),
                          padding: EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: Services.size > Services.minimumSize
                                  ? 20
                                  : 7),
                          height: Services.getHieght(context) * 0.72,
                          width: Services.getWidth(context),
                          child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  _detailstable(
                                      Images.fleetSummaryImages.totalKW,
                                      totalCapacity,
                                      "Installed Capacity(kW)",
                                      context,
                                      1),
                                  _detailstable(
                                      Images.fleetSummaryImages.todayProduction,
                                      todayP,
                                      "Today's Production(kWh)",
                                      context,
                                      1),
                                  _detailstable(
                                      Images
                                          .fleetSummaryImages.monthlyProduction,
                                      monthlyP,
                                      "Monthly Production($monthlyUnit)",
                                      context,
                                      1),
                                  _detailstable(
                                      Images
                                          .fleetSummaryImages.yearlyProduction,
                                      yearlyP / 1000,
                                      "Yearly Production(MWh)",
                                      context,
                                      1),
                                  _detailstable(
                                      Images.fleetSummaryImages
                                          .lifeTimeProduction,
                                      lifetimeP / 1000,
                                      "LifeTime Production(MWh)",
                                      context,
                                      1),
                                ],
                              ))),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ));
  }
}
