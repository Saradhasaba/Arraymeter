import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../services/constants.dart';
import '../../services/service.dart';

class PasswordRecovery extends StatefulWidget {
  @override
  _PasswordRecoveryState createState() => _PasswordRecoveryState();
}

class _PasswordRecoveryState extends State<PasswordRecovery> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          actions: [SomeFixedUi.appBarLogo()],
          title: Text(
            "ArrayMeter",
            style: TextStyle(fontSize: 18),
          ),
        ),
        body: WebView(
          initialUrl: Urls.forgotPassword,
        ));
  }
}
