import 'dart:async';
import 'dart:ui';
import 'package:arraymeter/services/marqueText.dart';

import 'arraymeter.dart';
import 'package:arraymeter/models/PlantModel.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

// ignore: must_be_immutable
class InstallerPlantsView extends StatefulWidget {
  List<PlantModel> plantList;
  List<PlantModel> noProduction;
  List<PlantModel> noCommunication;
  String title;
  bool manageAble = false;
  final void Function(PlantModel plant) editPlant;
  final void Function(String index) deletePlant;

  InstallerPlantsView(
      {this.plantList,
      this.noProduction,
      this.noCommunication,
      this.title,
      this.manageAble,
      this.editPlant,
      this.deletePlant});

  @override
  _InstallerPlantsViewState createState() => _InstallerPlantsViewState();
}

class _InstallerPlantsViewState extends State<InstallerPlantsView> {
  List<PlantModel> _plantList;
  Size _size;
  int _priority = 0;
  final GlobalKey _textKey = GlobalKey();
  double _height;
  double _width;

  @override
  void initState() {
    _plantList = widget.plantList;
    WidgetsBinding.instance.addPostFrameCallback((_) => getSizeAndPosition());
    super.initState();
  }

  getSizeAndPosition() {
    if (_plantList.isNotEmpty) {
      RenderBox _cardBox = _textKey.currentContext.findRenderObject();
      _height = _cardBox.size.height;
      _width = _cardBox.size.width;
      print("card height:${_cardBox.size.width}");
      setState(() {});
    }
  }

  List<Widget> gridItems(List<PlantModel> _plantList, BuildContext context) {
    List<Widget> items = [];

    for (PlantModel p in _plantList) {
      items.add(InkWell(
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ArrayData(
                        p,
                        widget.manageAble,
                        editPlant: widget.editPlant,
                        deletePlant: widget.deletePlant,
                      )));
        },
        child: Stack(
          key: _plantList.indexOf(p) == 0 ? _textKey : null,
          children: [
            Image.asset(
              "assets/listcard_background.png",
              fit: BoxFit.fill,
            ),
            Positioned(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: _width != null ? _width / 1.5 : 150,
                    child: MarqueeWidget(
                      child: Text(
                        p.name,
                        style: TextStyle(
                          fontFamily: Services.mont_med,
                          color: Services.colors.textColor,
                          fontSize:
                              Services.size <= Services.iphone5Screen ? 14 : 16,
                        ),
                      ),
                    ),
                  ),
                  Text(
                      p.lastCommunication != null
                          ? DateFormat("MM-dd-yyyy").format(p.lastCommunication)
                          : "",
                      style: TextStyle(
                          fontFamily: Services.mont_regular,
                          color: Services.colors.textColor)),
                ],
              ),
              left: Services.getWidth(context) * 0.05,
              top: Services.getHieght(context) * 0.02,
            ),
            Positioned(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    width: Services.getWidth(context) * 0.27,
                    child: Text(
                      p.todayEnergy != null
                          ? p.todayEnergy.toStringAsFixed(1)
                          // .padLeft(6, '0')
                          : "",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                          fontFamily: Services.digitalFont,
                          fontSize: 30,
                          color: Colors.white),
                    ),
                  ),
                  Text(" kWh",
                      style: TextStyle(
                          fontFamily: Services.mont_regular,
                          fontSize: _size > Services.minimumSize ? 15 : 13,
                          color: Colors.white))
                ],
              ),
              top: _height != null
                  ? MediaQuery.of(context).orientation == Orientation.landscape
                      ? _height / 1.4
                      : _height / 2.24
                  : 20,
              left: Services.getWidth(context) * 0.06,
            ),
            Positioned(
              child: Container(
                  child: CircleAvatar(
                      backgroundColor: Services.colors.textColor,
                      radius: 16,
                      child: CircleAvatar(
                          radius: 15,
                          backgroundColor:
                              Services.statusColor(p.plantStatus)))),
              top: MediaQuery.of(context).orientation == Orientation.landscape
                  ? Services.getWidth(context) * 0.02
                  : Services.getHieght(context) * 0.02,
              right: MediaQuery.of(context).orientation == Orientation.landscape
                  ? Services.getWidth(context) * 0.09
                  : Services.getWidth(context) * 0.03,
            ),
            Positioned(
              child: Text(
                p.id,
                style: TextStyle(
                  fontFamily: Services.mont_regular,
                  fontSize: 15,
                  color: Services.colors.textColor,
                ),
              ),
              bottom:
                  MediaQuery.of(context).orientation == Orientation.landscape
                      ? Services.getHieght(context) * 0.23
                      : Services.getHieght(context) * 0.05,
              left: Services.getWidth(context) * 0.05,
            ),
            Positioned(
              child: Column(
                children: [
                  Text(
                    "${p.capacity} kW",
                    style: TextStyle(
                        color: Services.colors.textColor,
                        fontFamily: Services.mont_regular,
                        fontSize: 12),
                  ),
                  Text(Texts.capacity,
                      style: TextStyle(
                          color: Services.colors.textColor,
                          fontFamily: Services.mont_regular,
                          fontSize: 12))
                ],
              ),
              bottom:
                  MediaQuery.of(context).orientation == Orientation.landscape
                      ? Services.getHieght(context) * 0.2
                      : Services.getHieght(context) * 0.03,
              right: MediaQuery.of(context).orientation == Orientation.landscape
                  ? Services.getWidth(context) * 0.09
                  : Services.getWidth(context) * 0.03,
            ),
          ],
        ),
      ));
    }

    return items;
  }

  @override
  Widget build(BuildContext context) {
    _size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Services.colors.scaffoldColor,
      body: Column(
        children: [
          Container(height: 8),
          Text(
            widget.title,
            style: Services.screenHeadingTextStyle,
          ),
          Container(height: 5),
          Container(
            width: Services.getWidth(context),
            margin: EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                    width: Services.getWidth(context) * 0.75,
                    height: 40,
                    child:
                        SomeFixedUi.searchUi(onSearchTextChange: (searchTexts) {
                      Timer(Duration(milliseconds: 100), () {
                        setState(() {
                          _plantList = widget.plantList
                              .where((element) => (element.name
                                      .toLowerCase()
                                      .contains(searchTexts.toLowerCase()) ||
                                  element.id
                                      .toString()
                                      .toLowerCase()
                                      .contains(searchTexts.toLowerCase()) ||
                                  element.city
                                      .toString()
                                      .toLowerCase()
                                      .contains(searchTexts.toLowerCase())))
                              .toList();
                        });
                      });
                    })),
                PopupMenuButton(
                  elevation: 3.2,
                  initialValue: _priority,
                  onCanceled: () {
                    // print('You have not chossed anything');
                  },
                  child: Image.asset(
                    Images.filterImage,
                    height: 40,
                    width: 40,
                  ),
                  // tooltip: 'Filter plants by  priority',
                  onSelected: (int value) {
                    switch (value) {
                      case 0:
                        _plantList = widget.plantList;
                        break;
                      case 1:
                        _plantList = widget.plantList
                            .where((element) => element.capacity <= 30)
                            .toList();
                        break;
                      case 2:
                        _plantList = widget.plantList
                            .where((element) =>
                                element.capacity > 30 && element.capacity <= 60)
                            .toList();
                        break;
                      case 3:
                        _plantList = widget.plantList
                            .where((element) => element.capacity >= 60)
                            .toList();
                        break;
                    }

                    _priority = value;

                    setState(() {});
                  },
                  color: Services.colors.scaffoldColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  itemBuilder: (BuildContext context) {
                    return [
                      PopupMenuItem(
                        value: 0,
                        child: Center(child: Text("All")),
                      ),
                      PopupMenuItem(
                        value: 1,
                        child: Center(child: Text("1-30 kW")),
                      ),
                      PopupMenuItem(
                        value: 2,
                        child: Center(child: Text("31-60 kW")),
                      ),
                      PopupMenuItem(
                        value: 3,
                        child: Center(child: Text(">60 kW")),
                      )
                    ];
                  },
                )
              ],
            ),
          ),
          Container(height: 6),
          Expanded(
            // height: _size >= Size(432.0, 816.0)
            //     ? Services.getHieght(context) * 0.75
            //     : Services.getHieght(context) * 0.67,
            // : (_size > Services.minimumSize
            // ? Services.getHieght(context) * 0.67
            // : Services.getHieght(context) * 0.67),
            child: GridView.count(
                padding: EdgeInsets.only(bottom: 50),
                crossAxisCount: 2,
                shrinkWrap: true,
                children: gridItems(_plantList, context)),
          ),
        ],
      ),
    );
  }
}
