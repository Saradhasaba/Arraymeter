import 'dart:async';
import 'package:arraymeter/providers/providers.dart';
import 'package:arraymeter/screens/main/home.dart';
import 'package:arraymeter/screens/main/login.dart';
import 'package:arraymeter/services/constants.dart';
import 'package:arraymeter/services/service.dart';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'NetworkModule/network.dart';
import 'models/PlantModel.dart';
import 'services/service.dart';

void main() {
  runApp(SplashScreen());
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  var userId;
  bool internetStatus = true;
  bool circularLoader = false;
  Future<void> loginStatus() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    userId = sharedPreferences.getStringList('userData') != null
        ? sharedPreferences.getStringList('userData')[0]
        : null;

    if (internetStatus == true) {
      if (userId != null) {
        List<PlantModel> _plants = [];
        String orgId = sharedPreferences.getStringList('userData')[4];

        //api of get plants has to be call
        String loginUrl =
            Urls.ip + Urls.apiFolder + "fc=getPlants&UserId=" + userId;
        var data = await NetworkHelper.getServerData(loginUrl);

        USerProfile.ticketManagement = data['ticket'] == "true" ? true : false;
        USerProfile.management = data['management'] == "true" ? true : false;

        sharedPreferences.setStringList("userData", [
          userId,
          data['role'],
          data['email'],
          data['name'],
          orgId,
        ]);

        if (data['plants'] != false) {
          List<String> _plantIds = [];

          for (var plantData in data['plants']) {
            _plants.add(PlantModel.fromJson(plantData));
          }

          _plants.forEach((element) {
            _plantIds.add(element.id);
          });
          sharedPreferences.setStringList("plantIds", _plantIds);
        }

        runApp(MultiProvider(
          providers: [
            ChangeNotifierProvider(create: (context) => ProviderBlock())
          ],
          child: MaterialApp(
            title: 'Login Demo',
            home: HomePageView(_plants),
            builder: (context, child) {
              return MediaQuery(
                child: child,
                data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
              );
            },
            theme: ThemeData(
              fontFamily: Services.mont_regular,
              primaryColor: Services.colors.textColor,
            ),
          ),
        ));
      } else
        runApp(MultiProvider(
          providers: [
            ChangeNotifierProvider(create: (context) => ProviderBlock())
          ],
          child: MaterialApp(
            title: 'Login Demo',
            home: LoginScreen(),
            builder: (context, child) {
              return MediaQuery(
                child: child,
                data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
              );
            },
            theme: ThemeData(
              fontFamily: Services.mont_regular,
              primaryColor: Services.colors.textColor,
            ),
          ),
        ));
    }
  }

  Future<Timer> loadData() async {
    return new Timer(Duration(seconds: 1), loginStatus);
  }

  @override
  void initState() {
    checkInternet();
    Timer(Duration(seconds: 1), () {
      setState(() {
        circularLoader = false;
      });
    });
    loadData();
    super.initState();
  }

  Future<void> checkInternet() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile ||
        connectivityResult == ConnectivityResult.wifi) {
      setState(() {
        internetStatus = true;
      });
    } else {
      setState(() {
        internetStatus = false;
      });
    }
    print(internetStatus);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'White Screen',
      home: Scaffold(
        body: Container(
          color: Colors.white,
          child: (!internetStatus)
              ? Center(
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                      Text(
                        "No Internet Connection",
                        style: Services.cardTextStyle,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      if (circularLoader == false)
                        InkWell(
                          child: Text(
                            "Refresh",
                            style: TextStyle(
                                color: Colors.blueAccent,
                                fontSize: 16,
                                fontWeight: FontWeight.bold),
                          ),
                          onTap: () {
                            setState(() {
                              circularLoader = true;
                            });
                            initState();
                          },
                        ),
                      if (circularLoader == true) CircularProgressIndicator(),
                    ]))
              : Center(
                  child: Text(
                  "Loading...",
                  style: Services.cardTextStyle,
                )),
        ),
      ),
    );
  }
}
