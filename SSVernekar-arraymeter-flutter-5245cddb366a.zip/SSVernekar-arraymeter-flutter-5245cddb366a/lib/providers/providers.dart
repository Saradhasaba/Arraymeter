import 'package:arraymeter/models/PlantModel.dart';
import 'package:flutter/material.dart';

class ProviderBlock extends ChangeNotifier {
  double _production = 0;

  setCounter(double value) {
    _production = value;
    notifyListeners();
  }

  double get getCounter => _production;

  List<PlantModel> _allPlants = [];

  setPlants(List<PlantModel> value) {
    _allPlants = value;
    notifyListeners();
  }

  List<PlantModel> get getAllPlants => _allPlants;
}
