import 'dart:convert';

import 'package:http/http.dart' as http;

import '../services/constants.dart';
import '../services/service.dart';

class NetworkHelper {
  static Future<List> geatYearGraphData(int year) async {
    String url = Urls.ip +
        Urls.apiDataPhp +
        "widget_id=yearGen&meter_id=" +
        Services.texts.meterNo.toString() +
        "&month=" +
        year.toString();

    List values = await getServerData(url);

    return values;
  }

  static Future getServerData(String url) async {
    print(url);


   try {
      var severData = await http.get(url);
      if (severData.statusCode == 200) {
        // print("server response receved");

        var data = await json.decode(severData.body);


        return data;
      } else
        print("server error");
    }catch(e){
     print("server  error$e");


   }



  }

  static Future<List<Point>> getGData(DateTime calender, int dmy) async {
    String url = Urls.ip +
        Urls.apiDataPhp +
        "widget_id=monthGen&meter_id=10523994&month_calendar=09/07/2020";
    switch (dmy) {
      case 0:
        url = Urls.ip +
            Urls.apiDataPhp +
            "widget_id=hourwidget&meter_id=" +
            Services.texts.meterNo +
            "&month_calendar=" +
            Services.backendDate(calender);

        break;
      case 1:
        url = Urls.ip +
            Urls.apiDataPhp +
            "widget_id=monthGen&meter_id=" +
            Services.texts.meterNo +
            "&month_calendar=" +
            Services.backendDate(calender);

        break;
      case 2:
        url = Urls.ip +
            Urls.apiDataPhp +
            "widget_id=yearGen&meter_id=" +
            Services.texts.meterNo +
            "&year_calendar=" +
            Services.backendDate(calender);

        break;

      case 3:
        url = Urls.ip +
            Urls.apiDataPhp +
            "widget_id=minwidget&meter_id=" +
            Services.texts.meterNo +
            "&month_calendar=" +
            Services.backendDate(calender);

        break;
    }
    print(url);

    List values = [];
    List<Point> _points = [];

    var tableData = await http.get(url);

    var data = await json.decode(tableData.body);

    if (data == '' || data == null || data == 'null') return _points;

    if (data.isNotEmpty) {
      values = dmy != 1 ? data[0]['values'] : data['values'];

      values
          .forEach((e) => _points.add(Point(e[0].toString(), e[1].toString())));
    }

    return _points;
  }

  static Future sendDataToBackend(String url, Map<String, dynamic> body) async {
    // print(body);
    final http.Response response = await http.post(
      url,
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(body),
    );

    print(url);

    if (response.statusCode == 200) {
    } else {
      print(response.statusCode);
      throw Exception('Failed to create album.');
    }
    return response;
  }
}
